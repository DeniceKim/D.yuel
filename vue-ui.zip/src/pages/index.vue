<route lang="yaml">
meta:
  title: 홈
  layout: MainLayout
  layoutId: home       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: true        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <section class="gap">
    <h2>홈 메인</h2>
    <BaseCard>
      <template #header> 타이틀 </template>
      <div class="cardbody">
        Demo Content안에서 사용하는 아이템 부모요소에 class gap을 부여하면 상/하/좌/우 간격 20px -> 1.25rem 간격이 부여됨.<br />
        Demo Content안에서 사용하는 아이템 부모요소에 class gap__x을 부여하면 좌/우 간격만 20px -> 1.25rem 간격이 부여됨.<br />
        Demo Content안에서 사용하는 아이템 부모요소에 class gap__y을 부여하면 상/하 간격만 20px -> 1.25rem 간격이 부여됨.<br />
        예) &lt;section class="gap"&gt;<br />
        &lt;div class="gap"&gt;<br />
        &lt;div class="gap__x"&gt;<br />
        &lt;div class="gap__y"&gt;
      </div>
      <template #footer>
        <ul>
          <li>
            <router-link to="/guide">Demo 가이드 페이지</router-link>
          </li>
          <li>
            <router-link to="/guide/demo/swiper">Demo Pure Swiper(a11y 미 적용 상태)</router-link>
          </li>
        </ul>
      </template>
    </BaseCard>
  </section>

  <section>
    <BaseCard>
      <template #header> 타이틀 </template>
      <div class="cardbody">
        Contents 부모요소에 class 가 없으면 좌/우 간격은 기본 0이 되어 가로 사이즈 100% 유지.
      </div>
      <template #footer>
        Demo Page
      </template>
    </BaseCard>
  </section>

  <section>
    <h2>Demo Swiper</h2>
    <SwiperCarousel
      :slides="demoSlides"
      :autoplay="{ delay: 2200, pauseOnInteraction: true }"
      pagination
      pagination-type="bullets"
      navigation
      controls
      keyboard
      :initial-slide="0"
      aria-label="기본 캐러셀"
    />
  </section>
</template>
<script setup lang="ts">
import BaseCard from '@/components/BaseCard.vue'
import SwiperCarousel from '@/components/SwiperCarousel.vue'


// 데모용 데이터
const demoSlides = Array.from({ length: 7 }, (_, i) => ({
  title: `Slide ${i + 1}`,
  desc: '기본 데모 카드',
}))

// 높이가 제각각인 슬라이드 (fade 높이 관찰 확인)
const mixedHeightSlides = [
  { title: 'A', desc: '짧은 텍스트' },
  { title: 'B', desc: '중간 길이 텍스트\n줄바꿈 포함' },
  {
    title: 'C',
    desc: '아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트',
  },
  { title: 'D', desc: '이미지/콘텐츠가 더 길다고 가정' },
  { title: 'E', desc: '끝' },
]

// progressbar 테스트용 (조금 더 높은 카드)
const tallSlides = Array.from({ length: 5 }, (_, i) => ({
  title: `Tall ${i + 1}`,
  desc: '높은 카드',
}))
</script>
