<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Components Demo</h2>
  <ul>
    <li v-for="it in links" :key="it.to">
      <router-link :to="it.to">
        {{ it.label }}
      </router-link>
    </li>
  </ul>
</template>
<script setup lang="ts">
const links = [
  { to: '/guide/button', label: 'Button' },
  { to: '/guide/card', label: 'Card' },
  { to: '/guide/modal', label: 'Modal' },
  { to: '/guide/input', label: 'Input' },
  { to: '/guide/checkbox', label: 'Checkbox' },
  { to: '/guide/radio', label: 'Radio' },
  { to: '/guide/select', label: 'Select' },
  { to: '/guide/switch', label: 'Switch' },
  { to: '/guide/tooltip', label: 'Tooltip' },
  { to: '/guide/avatar', label: 'Avatar' },
  { to: '/guide/badge', label: 'Badge' },
  { to: '/guide/tabs', label: 'Tabs' },
  { to: '/guide/accordion', label: 'Accordion' },
  { to: '/guide/toast', label: 'Toast' },
  { to: '/guide/spinner', label: 'Spinner' },
  { to: '/guide/progressbar', label: 'ProgressBar' },
  { to: '/guide/pagination', label: 'Pagination' },
  { to: '/guide/breadcrumb', label: 'Breadcrumb' },
  { to: '/guide/sidebar', label: 'Sidebar' },
  { to: '/guide/navbar', label: 'Navbar' },
  { to: '/guide/swiper', label: 'Swiper' },
]
</script>
