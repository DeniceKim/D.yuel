<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Button</h2>
  <div style="display: flex; gap: 8px; flex-wrap: wrap">
    <BaseButton>Primary</BaseButton>
    <BaseButton class="c-btn--ghost"> Ghost </BaseButton>
    <button class="c-btn" disabled>Native</button>
  </div>
</template>
<script setup lang="ts">
import BaseButton from '@/components/BaseButton.vue'
</script>
