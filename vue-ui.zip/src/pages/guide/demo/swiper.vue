<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Swiper – All Options Showcase</h2>

  <!-- 0. 기본(슬라이드, bullets, autoplay) -->
  <h3>0) 기본 (slide + bullets + autoplay)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="{ delay: 2200, pauseOnInteraction: true }"
    pagination
    pagination-type="bullets"
    navigation
    controls
    keyboard
    :initial-slide="0"
    aria-label="기본 캐러셀"
  />

  <!-- 1. 네비게이션만 (재생/정지 숨김) -->
  <h3 style="margin-top: 40px">1) 네비게이션만 (controls=false, autoplay=false)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="false"
    navigation
    :controls="false"
    pagination
    aria-label="네비게이션만"
  />

  <!-- 2. 페이징 타입: fraction -->
  <h3 style="margin-top: 40px">2) Pagination: fraction</h3>
  <SwiperCarousel
    :slides="demoSlides"
    pagination
    pagination-type="fraction"
    navigation
    :slides-per-view="2"
    :space-between="12"
    aria-label="프랙션 페이지네이션"
  />

  <!-- 3. 페이징 타입: progressbar (첫 슬라이드부터 채움) -->
  <h3 style="margin-top: 40px">3) Pagination: progressbar</h3>
  <SwiperCarousel
    :slides="tallSlides"
    pagination
    pagination-type="progressbar"
    navigation
    :slides-per-view="1"
    :space-between="8"
    aria-label="프로그레스바 페이지네이션"
  />

  <!-- 4. 여러 장 보기 + 간격 + 가운데 정렬 -->
  <h3 style="margin-top: 40px">4) 여러 장 보기 + 간격 + 가운데 정렬</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :slides-per-view="3"
    :space-between="16"
    centered
    navigation
    pagination
    aria-label="여러장/간격/센터"
  />

  <!-- 5. Breakpoints (반응형) -->
  <h3 style="margin-top: 40px">5) Breakpoints (반응형)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :breakpoints="{
      480: { slidesPerView: 2, spaceBetween: 10 },
      768: { slidesPerView: 3, spaceBetween: 14 },
      1024: { slidesPerView: 4, spaceBetween: 16 },
    }"
    pagination
    navigation
    aria-label="반응형 브레이크포인트"
  />

  <!-- 6. Free mode (자유 스크럽) -->
  <h3 style="margin-top: 40px">6) Free Mode</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :free-mode="true"
    :slides-per-view="2"
    :space-between="12"
    navigation
    pagination
    aria-label="프리모드"
  />

  <!-- 7. 키보드 이동 + 초기 인덱스 -->
  <h3 style="margin-top: 40px">7) Keyboard + Initial Slide</h3>
  <SwiperCarousel
    :slides="demoSlides"
    keyboard
    navigation
    pagination
    :initial-slide="2"
    aria-label="키보드/초기슬라이드"
  />

  <!-- 8. 터치 비활성(접근성/스크롤 존중) -->
  <h3 style="margin-top: 40px">8) 터치 이동 비활성 (allowTouchMove=false)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :allow-touch-move="false"
    navigation
    pagination
    aria-label="터치 비활성"
  />

  <!-- 9. Fade – 부드러운 전환 -->
  <h3 style="margin-top: 40px">9) Fade – 부드러운 전환 (smooth)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    effect="fade"
    fade-mode="smooth"
    :autoplay="{ delay: 2500 }"
    :controls="true"
    pagination
    aria-label="페이드 스무스"
    style="--fade-ease: ease-in-out; --fade-speed: 400ms"
  />

  <!-- 10. Fade – 즉시 표시(전환 없음) -->
  <h3 style="margin-top: 40px">10) Fade – 즉시 표시 (instant)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    effect="fade"
    fade-mode="instant"
    :autoplay="false"
    :controls="true"
    pagination
    aria-label="페이드 인스턴트"
  />

  <!-- 11. Autoplay + 접근성: 일시정지 버튼 강제 노출 -->
  <h3 style="margin-top: 40px">11) Autoplay + 접근성 (항상 Pause 노출)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="{ delay: 1800 }"
    :require-pause-for-autoplay="true"
    :controls="false"
    pagination
    navigation
    aria-label="접근성 자동재생"
  />

  <!-- 12. 모든 기능 조합 가변 테스트 -->
  <h3 style="margin-top: 40px">12) 모든 기능 조합 (stress)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    :slides-per-view="2"
    :space-between="12"
    :breakpoints="{
      600: { slidesPerView: 2, spaceBetween: 12 },
      900: { slidesPerView: 3, spaceBetween: 16 },
    }"
    centered
    navigation
    pagination
    pagination-type="bullets"
    keyboard
    :free-mode="false"
    :autoplay="{ delay: 2200, pauseOnInteraction: true }"
    :require-pause-for-autoplay="true"
    :initial-slide="1"
    aria-label="풀옵션 콤보"
    style="--swiper-gap: 12px; --swiper-speed: 350ms"
  />

  <!-- 13. 스타일 변수 커스텀(도트/라운드/속도) -->
  <h3 style="margin-top: 40px">13) 전역 변수 커스텀 (로컬 인스턴스만)</h3>
  <div
    style="
      --swiper-dot-size: 12px;
      --swiper-dot-color: #94a3b8;
      --swiper-dot-active: #ef4444;
      --swiper-radius: 16px;
      --swiper-speed: 500ms;
    "
  >
    <SwiperCarousel
      :slides="demoSlides"
      navigation
      pagination
      aria-label="스타일 변수 커스텀 인스턴스"
    />
  </div>
</template>

<script setup lang="ts">
import SwiperCarousel from '@/components/SwiperCarousel.vue'

// 데모용 데이터
const demoSlides = Array.from({ length: 7 }, (_, i) => ({
  title: `Slide ${i + 1}`,
  desc: '기본 데모 카드',
}))

// 높이가 제각각인 슬라이드 (fade 높이 관찰 확인)
const mixedHeightSlides = [
  { title: 'A', desc: '짧은 텍스트' },
  { title: 'B', desc: '중간 길이 텍스트\n줄바꿈 포함' },
  {
    title: 'C',
    desc: '아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트',
  },
  { title: 'D', desc: '이미지/콘텐츠가 더 길다고 가정' },
  { title: 'E', desc: '끝' },
]

// progressbar 테스트용 (조금 더 높은 카드)
const tallSlides = Array.from({ length: 5 }, (_, i) => ({
  title: `Tall ${i + 1}`,
  desc: '높은 카드',
}))
</script>

<style lang="scss" scoped>
</style>
