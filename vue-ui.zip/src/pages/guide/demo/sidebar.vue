<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Sidebar</h2>
  <BaseSidebar />
</template>
<script setup lang="ts">
import BaseSidebar from '@/components/BaseSidebar.vue'
</script>
