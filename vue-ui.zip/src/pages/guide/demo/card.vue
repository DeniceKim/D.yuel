<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Card</h2>
  <BaseCard><template #header> 헤더 </template>본문<template #footer> 푸터 </template></BaseCard>
</template>
<script setup lang="ts">
import BaseCard from '@/components/BaseCard.vue'
</script>
