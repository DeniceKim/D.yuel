<route lang="yaml">
meta:
  title: 전체메뉴
  layout: MenuLayout
  layoutId: menu       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: true        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <section class="top__noti gap__x">
    <h2>전체메뉴 Main</h2>
    <p>전체메뉴 메인 페이지입니다.</p>
  </section>
</template>
