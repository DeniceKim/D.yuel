<template>
  <router-view />
</template>

<script setup lang="ts">
// 전역 UI는 레이아웃으로 이동
</script>
