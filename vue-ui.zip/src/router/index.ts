import { createRouter, createWebHistory } from 'vue-router'
// vite-plugin-pages가 생성하는 가상 모듈 (pages/ 기반 자동 라우팅)
import generatedRoutes from 'virtual:generated-pages'
// vite-plugin-vue-layouts로 meta.layout을 반영해 레이아웃 주입
import { setupLayouts } from 'virtual:generated-layouts'

/**
 * 경로 문자열에서 파일명(확장자 제외) 추출
 * 예) '/src/pages/benefit/B01/B01.vue' -> 'B01'
 */
function extractFileName(componentPath: unknown): string {
  if (typeof componentPath !== 'string') return ''
  const last = componentPath.split('/').pop() || ''
  return last.replace(/\.\w+$/, '') // 확장자 제거
}

/**
 * generatedRoutes에 실제 파일명(meta.fileName)을 주입
 * - MainLayout 등에서 data-page에 그대로 쓰기 위함
 */
const routes = setupLayouts(
  generatedRoutes.map((r) => {
    // vite-plugin-pages는 문자열 경로를 component로 들고 있음(빌드 전)
    // 문자열일 때만 안전하게 파일명 추출
    // (Vite 최적화 단계에 따라 함수가 될 수도 있으므로 체크)
    const comp = r.component
    const fileName = extractFileName(comp)
    r.meta = { ...(r.meta || {}), fileName }
    return r
  }),
)

const router = createRouter({
  // 배포 서브디렉터리 대응
  history: createWebHistory(import.meta.env.BASE_URL),

  routes,

  // 스크롤 복원/앵커/기본 상단 이동
  scrollBehavior(to, from, savedPosition) {
    // 1) 브라우저 뒤로/앞으로: 원래 위치로
    if (savedPosition) return savedPosition

    // 2) 해시가 있으면 해당 앵커로 (스무스)
    if (to.hash) {
      return {
        el: to.hash,
        behavior: 'smooth',
      }
    }

    // 3) 기본: 상단으로
    return { top: 0 }
  },
})

// 문서 타이틀 갱신 + 메인 포커스 이동(접근성)
router.afterEach((to) => {
  const baseTitle = 'Bank'
  const pageTitle = (to.meta?.title as string) || ''
  document.title = pageTitle ? `${pageTitle} · ${baseTitle}` : baseTitle

  // Drawer(또는 오버레이) 열림 시에는 메인 포커스 이동을 건너뜀
  // - useDrawer에서 body에 is-modal-open 클래스를 토글하므로 이를 신호로 사용
  if (document.body.classList.contains('is-modal-open')) return

  // 메인 영역 포커스 이동 (키보드/스크린리더 접근성)
  // 페이지 레이아웃 템플릿에 id="main" 존재 권장
  queueMicrotask(() => {
    const main = document.getElementById('main')
    if (!main) return
    const hadTabIndex = main.hasAttribute('tabindex')
    if (!hadTabIndex) main.setAttribute('tabindex', '-1') // 임시로 포커서블
    main.focus({ preventScroll: true })
    if (!hadTabIndex) main.removeAttribute('tabindex')    // 원복
  })

  // (선택) 라우트 변경 안내를 aria-live로 알리고 싶다면:
  // const live = document.getElementById('route-announcer')
  // if (live) live.textContent = pageTitle || '페이지가 변경되었습니다'
})

export default router
