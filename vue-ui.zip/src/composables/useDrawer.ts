import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'

/**
 * 공통 Drawer 제어 훅
 * - inert/aria-hidden/tabindex를 #app에 적용
 * - 열 때 첫 포커스 이동, 닫을 때 트리거로 포커스 복귀
 * - ESC로 닫기
 */
export function useDrawer(rootSelector: string = '#app') {
  const drawerOpen = ref(false)
  const router = useRouter()
  let openerEl: HTMLElement | null = null

  function setInert(v: boolean) {
    const root = document.querySelector(rootSelector) as HTMLElement | null
    if (!root) return
    if (v) {
      root.setAttribute('inert', '')
      root.setAttribute('aria-hidden', 'true')
      root.setAttribute('tabindex', '-1')
    } else {
      root.removeAttribute('inert')
      root.removeAttribute('aria-hidden')
      root.removeAttribute('tabindex')
    }
    document.body.classList.toggle('is-modal-open', v) // 선택: 스크롤 잠금
  }

  function focusFirstInDrawer() {
    const first = document.querySelector(
      '.c-drawer [tabindex], .c-drawer button, .c-drawer a, .c-drawer input, .c-drawer select, .c-drawer textarea'
    ) as HTMLElement | null
    first?.focus()
  }

  function openMenu() {
    openerEl = (document.activeElement as HTMLElement) || null
    drawerOpen.value = true
    setInert(true)
    queueMicrotask(focusFirstInDrawer)
  }

  function closeMenu() {
    drawerOpen.value = false
    setInert(false)
    openerEl?.focus()
    openerEl = null
  }

  function goBack() {
    window.history.length > 1 ? router.back() : router.push('/')
  }

  function onKeydown(e: KeyboardEvent) {
    if (e.key === 'Escape' && drawerOpen.value) {
      e.preventDefault()
      closeMenu()
    }
  }

  onMounted(() => {
    document.addEventListener('keydown', onKeydown)
  })
  onBeforeUnmount(() => {
    setInert(false)
    document.removeEventListener('keydown', onKeydown)
  })

  return {
    drawerOpen,
    openMenu,
    closeMenu,
    goBack,
    setInert, // 필요 시 외부에서 직접 호출 가능
  }
}
