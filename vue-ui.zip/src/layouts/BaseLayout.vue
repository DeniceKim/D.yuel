<template>
  <BaseNavbar
    v-if="showNavbar"
    :title="(route.meta.title as string) || ''"
    :show-back="route.path !== '/'"
    @open-menu="openMenu"
    @back="goBack"
  />
  <BaseTabbar v-if="showTabbar" />

  <main id="main" class="l-container" :data-layout="layoutId" :data-page="pageName">
    <slot />
  </main>

  <BaseDrawer v-if="showDrawer" :open="drawerOpen" side="right" @close="closeMenu">
    <BaseSidebar />
  </BaseDrawer>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { useLayoutParts } from '@/composables/useLayoutParts'

import BaseNavbar from '@/components/BaseNavbar.vue'
import BaseTabbar from '@/components/BaseTabbar.vue'
import BaseDrawer from '@/components/BaseDrawer.vue'
import BaseSidebar from '@/components/BaseSidebar.vue'

const route = useRoute()
const {
  showNavbar, showTabbar, showDrawer,
  layoutId, pageName,
  drawerOpen, openMenu, closeMenu, goBack,
} = useLayoutParts()
</script>

<style lang="scss">
@use '@/assets/scss/layout/layout' as *;
</style>
