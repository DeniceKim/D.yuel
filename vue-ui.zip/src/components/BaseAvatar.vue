<template>
  <div class="c-avatar">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/avatar' as *;
</style>
