<template>
  <nav class="c-sidebar" aria-label="컴포넌트/페이지 메뉴">
    <p class="c-sidebar__section">Pages</p>
    <ul>
      <li><RouterLink to="/"> 홈 </RouterLink></li>
      <li><RouterLink to="/guide"> 가이드 </RouterLink></li>
      <li><RouterLink to="/dashboard"> 대시보드 </RouterLink></li>
      <li><RouterLink to="/intro"> 소개 </RouterLink></li>
    </ul>
    <p class="c-sidebar__section">Guide / Demos</p>
    <ul>
      <li v-for="it in demo" :key="it.to">
        <RouterLink :to="it.to">
          {{ it.label }}
        </RouterLink>
      </li>
    </ul>
  </nav>
</template>
<script setup lang="ts">
const demo = [
  { to: '/guide/demo/button', label: 'Button' },
  { to: '/guide/demo/card', label: 'Card' },
  { to: '/guide/demo/tabs', label: 'Tabs' },
  { to: '/guide/demo/sidebar', label: 'Sidebar' },
  { to: '/guide/demo/navbar', label: 'Navbar' },
  { to: '/guide/demo/swiper', label: 'Swiper' },
]
</script>
<style scoped lang="scss">
@use '../assets/scss/components/sidebar' as *;
</style>
