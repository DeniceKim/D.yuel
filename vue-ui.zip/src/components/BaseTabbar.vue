<template>
  <nav class="c-tabbar" aria-label="하단 주메뉴">
    <router-link
      v-for="item in items"
      :key="item.to"
      :to="item.to"
      class="c-tabbar__item"
      :aria-label="item.label"
      :aria-current="isActive(item.to) ? 'page' : undefined"
    >
      <span class="c-tabbar__inner" aria-hidden="true">
        <img :src="getIconSrc(item.icon, isActive(item.to))" alt="" />
        <span>{{ item.label }}</span>
      </span>
    </router-link>
  </nav>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
const route = useRoute()

/**
 * 아이콘 파일은 /src/assets/images/icon/ 경로 하위에 위치해야 합니다.
 * 예)
 *  - icon-tabbar-home.svg
 *  - icon-tabbar-home-active.svg
 *
 * Vite 5 권장 옵션:
 *  - as 대신 query/import 사용
 *  - eager:true 로 즉시 로드(런타임 비동기 X)
 */
const iconMap = import.meta.glob('/src/assets/images/icon/*.svg', {
  eager: true,
  query: '?url',
  import: 'default',
}) as Record<string, string>

/** 탭 항목 정의 */
const items = [
  { to: '/',         label: '홈',     icon: 'icon-tabbar-home',    exact: true },
  { to: '/finance',  label: '금융',   icon: 'icon-tabbar-finance' },
  { to: '/product',  label: '상품',   icon: 'icon-tabbar-product' },
  { to: '/benefit',  label: '혜택',   icon: 'icon-tabbar-benefit' },
  { to: '/menu',     label: '전체메뉴', icon: 'icon-tabbar-menu'   },
]

/** 현재 경로 활성화 여부 */
function isActive(path: string) {
  return path === '/' ? route.path === '/' : route.path.startsWith(path)
}

/** 활성 상태에 따라 -active 아이콘 자동 선택 */
function getIconSrc(base: string, active: boolean) {
  const file = active ? `${base}-active.svg` : `${base}.svg`
  return iconMap[`/src/assets/images/icon/${file}`] ?? ''
}
</script>

<style scoped lang="scss">
@use '../assets/scss/components/tabbar' as *;
</style>
