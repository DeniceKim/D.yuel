<template>
  <header class="l-header">
    <div class="c-navbar">
      <!-- 뒤로가기 -->
      <button
        v-if="showBack"
        class="c-navbar__btn"
        aria-label="뒤로가기"
        @click="$emit('back')"
      >
        <!-- 테마에 따라 자동으로 -white.svg 교체 -->
        <img :src="backIcon" alt="" aria-hidden="true" />
      </button>

      <!-- 로고 -->
      <div v-else class="c-navbar__logo">
        <img src="@/assets/images/symbol/shinhan.svg" alt="쏠 페이" />
      </div>

      <!-- 타이틀 -->
      <h1 class="c-navbar__title" :title="title">
        {{ title }}
      </h1>

      <!-- 액션 -->
      <div class="c-navbar__actions">
        <button class="c-navbar__btn" aria-label="테마 전환" @click="onToggleTheme">
          {{ themeIcon }}
        </button>

        <button class="c-navbar__btn" aria-label="전체 메뉴" @click="$emit('open-menu')">
          <!-- 테마에 따라 자동으로 -white.svg 교체 -->
          <img :src="menuIcon" alt="" aria-hidden="true" />
        </button>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { getTheme, toggleTheme } from '@/utils/theme'

interface Props {
  title?: string
  showBack?: boolean
}
withDefaults(defineProps<Props>(), { title: 'Bank App', showBack: false })

/* ===========================
 * 아이콘 매핑: 동일 경로/파일명에서 다크모드일 때만 -white.svg 선택
 *   - Vite의 권장 문법(Deprecation 대비): query + import:'default'
 *   - /src 절대경로 패턴을 사용해 경로 키 일관성 보장
 * =========================== */
const iconMap = import.meta.glob('/src/assets/images/icon/*.svg', {
  eager: true,
  query: '?url',
  import: 'default',
}) as Record<string, string>

/* ===========================
 * 현재 테마 상태 + 토글 아이콘
 * =========================== */
const currentTheme = ref<'light' | 'dark'>('light')
const themeIcon = ref('🌙')

onMounted(() => {
  const t = getTheme()
  currentTheme.value = t === 'dark' ? 'dark' : 'light'
  themeIcon.value = currentTheme.value === 'dark' ? '☀️' : '🌙'
})

function onToggleTheme() {
  const next = toggleTheme()
  currentTheme.value = next
  themeIcon.value = next === 'dark' ? '☀️' : '🌙'
}

/* ===========================
 * 공용 아이콘 해석 함수
 *   - name: 확장자/접두경로 제외한 파일 베이스명 (예: 'icon-setting', 'icon-arrow-left')
 *   - 라이트: name.svg, 다크: name-white.svg (없으면 기존 파일로 폴백)
 * =========================== */
function resolveIcon(name: string) {
  const base = `/src/assets/images/icon/${name}.svg`
  const white = `/src/assets/images/icon/${name}-white.svg`
  return currentTheme.value === 'dark'
    ? (iconMap[white] || iconMap[base] || '')
    : (iconMap[base] || iconMap[white] || '')
}

/* ===========================
 * 테마에 따라 동적 URL 제공
 * =========================== */
const backIcon = computed(() => resolveIcon('icon-arrow-left'))
const menuIcon = computed(() => resolveIcon('icon-setting'))
</script>

<style scoped lang="scss">
@use '../assets/scss/components/navbar' as *;
</style>
