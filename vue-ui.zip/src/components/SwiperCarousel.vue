<template>
  <div
    class="c-swiper"
    :class="[{ fade: effect === 'fade' }]"
    :style="rootVars"
    aria-label="갤러리"
  >

    <!-- Controls (Play / Pause) – 자동재생이면 항상 표시(requirePauseForAutoplay=true) -->
    <div v-if="controls || (requirePauseForAutoplay && !!autoplay)" class="c-swiper__controls">
      <button class="c-btn small" type="button" @click="onNavClick('prev')" aria-label="이전">
        ⟨
      </button>
      <button v-if="!isPlaying" class="c-btn small" type="button" @click="play" aria-label="재생">
        ▶︎
      </button>
      <button v-else class="c-btn small" type="button" @click="pause" aria-label="일시정지">
        ⏸︎
      </button>
      <button class="c-btn small" type="button" @click="onNavClick('next')" aria-label="다음">
        ⟩
      </button>
    </div>

    <!-- Pagination -->
    <div
      v-if="pagination && slidesLen > 0"
      class="c-swiper__pagination"
      :data-type="paginationType"
      role="tablist"
      aria-label="페이지 네비게이션"
    >
      <!-- Bullets -->
      <template v-if="paginationType === 'bullets'">
        <button
          v-for="dot in slidesLen"
          :key="'dot-' + dot"
          type="button"
          class="dot"
          role="tab"
          :id="dotId(dot - 1)"
          :aria-controls="slideId(dot - 1)"
          :class="{ active: activeRealIndex === dot - 1 }"
          :aria-selected="activeRealIndex === dot - 1"
          :aria-label="`${dot} / ${slidesLen}`"
          :tabindex="dotTabIndex(dot - 1)"
          @click="onDotClick(dot - 1)"
          @keyup.enter.prevent="onDotClick(dot - 1)"
          @keyup.space.prevent="onDotClick(dot - 1)"
        />
      </template>

      <!-- Fraction -->
      <template v-else-if="paginationType === 'fraction'">
        <span class="fraction" aria-live="polite">
          <b>{{ activeRealIndex + 1 }}</b> / {{ slidesLen }}
        </span>
      </template>

      <!-- Progressbar -->
      <template v-else-if="paginationType === 'progressbar'">
        <span class="progress" aria-hidden="true">
          <i :style="{ width: progressPct + '%' }"></i>
        </span>
      </template>
    </div>

    <!-- Navigation -->
    <button
      v-if="navigation"
      class="c-btn nav prev"
      type="button"
      aria-label="이전 슬라이드"
      @click="onNavClick('prev')"
      @keyup.enter.prevent="onNavClick('prev')"
      @keyup.space.prevent="onNavClick('prev')"
    >
      ‹
    </button>
    
    <!-- Viewport / Track -->
    <div
      ref="viewport"
      class="c-swiper__viewport"
      role="region"
      aria-roledescription="carousel"
      :aria-label="ariaLabel"
      :style="viewportVars"
      @pointerdown="onPointerDown"
      @pointerup="onPointerUp"
      @pointercancel="onPointerUp"
      @pointerleave="onPointerUp"
      @pointermove="onPointerMove"
    >
      <!-- 시각숨김: 슬라이드 변경 공지 -->
      <p id="swiper-status" class="u-sr-only" aria-live="polite">
        {{ activeRealIndex + 1 + ' / ' + slidesLen }}
      </p>

      <div
        ref="track"
        class="c-swiper__track"
        :class="{ 'is-animating': isAnimating, 'is-dragging': isDragging }"
        role="listbox"
        aria-labelledby="swiper-status"
        tabindex="0"
        :style="trackVars"
        @keydown.prevent.stop="keyboard ? onKeydown($event) : null"
        @transitionend="onTransitionEnd"
      >
        <div
          v-for="(item, idx) in renderSlides"
          :key="idx"
          class="c-slide"
          :id="slideId(absToReal(idx))"
          :class="{ 'is-active': absToReal(idx) === activeRealIndex }"
          role="option"
          :aria-label="`슬라이드 ${absToReal(idx) + 1} / ${slidesLen}`"
          :aria-selected="absToReal(idx) === activeRealIndex"
          :aria-hidden="isFade ? absToReal(idx) !== activeRealIndex : undefined"
          :data-real="absToReal(idx)"
          :style="[slideVars, fadeSlideVars(idx)]"
        >
          <slot name="slide" :item="item" :index="absToReal(idx)">
            <div class="c-card">
              <div class="c-card__header">Slide {{ absToReal(idx) + 1 }}</div>
              <div class="c-card__footer">설명</div>
            </div>
          </slot>
        </div>
      </div>
    </div>

    <button
      v-if="navigation"
      class="c-btn nav next"
      type="button"
      aria-label="다음 슬라이드"
      @click="onNavClick('next')"
      @keyup.enter.prevent="onNavClick('next')"
      @keyup.space.prevent="onNavClick('next')"
    >
      ›
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, watch, nextTick, toRefs } from 'vue'

type BreakpointConfig = { slidesPerView?: number; spaceBetween?: number }
type AutoplayConfig = { delay?: number; pauseOnInteraction?: boolean }

const props = withDefaults(
  defineProps<{
    slides?: any[]
    slidesPerView?: number
    spaceBetween?: number
    centered?: boolean
    speed?: number
    pagination?: boolean
    paginationType?: 'bullets' | 'fraction' | 'progressbar'
    navigation?: boolean
    controls?: boolean
    keyboard?: boolean
    freeMode?: boolean
    allowTouchMove?: boolean
    initialSlide?: number
    breakpoints?: Record<number, BreakpointConfig>
    autoplay?: boolean | AutoplayConfig
    ariaLabel?: string
    pauseOnMouseEnter?: boolean
    effect?: 'slide' | 'fade'
    fadeMode?: 'smooth' | 'instant'
    /** 접근성: 자동재생 시 반드시 일시정지 컨트롤 노출 */
    requirePauseForAutoplay?: boolean
  }>(),
  {
    slides: () => Array.from({ length: 5 }, (_, i) => ({ n: i + 1 })),
    slidesPerView: 1,
    spaceBetween: 8,
    centered: false,
    speed: 300,
    pagination: true,
    paginationType: 'bullets',
    navigation: true,
    controls: true,
    keyboard: true,
    freeMode: false,
    allowTouchMove: true,
    initialSlide: 0,
    breakpoints: () => ({}),
    autoplay: false,
    ariaLabel: '이미지 캐러셀',
    pauseOnMouseEnter: true,
    effect: 'slide',
    fadeMode: 'smooth',
    requirePauseForAutoplay: true,
  }
)

const { pagination, paginationType, navigation, controls, keyboard, effect } = toRefs(props)

const viewport = ref<HTMLElement | null>(null)
const track = ref<HTMLElement | null>(null)

/** IDs for aria-controls */
const slideId = (real: number) => `swiper-slide-${real}`
const dotId = (real: number) => `swiper-dot-${real}`

/** Responsive / sizing */
const width = ref(0)
type BK = keyof BreakpointConfig
function pickResponsive<T extends BK>(key: T, base: number) {
  const bp = Object.keys(props.breakpoints || {})
    .map((n) => Number(n))
    .sort((a, b) => a - b)
  let value = base
  for (const w of bp) {
    if (width.value >= w) {
      const v = (props.breakpoints as any)[w]?.[key]
      if (typeof v === 'number') value = v
    }
  }
  return value
}
const perViewProp = computed(() =>
  Math.max(1, pickResponsive('slidesPerView', props.slidesPerView))
)
const gapProp = computed(() => Math.max(0, pickResponsive('spaceBetween', props.spaceBetween)))
const isFade = computed(() => effect.value === 'fade')
const perView = computed(() => (isFade.value ? 1 : perViewProp.value))
const gap = computed(() => (isFade.value ? 0 : gapProp.value))

/** Slides */
const coreSlides = computed(() => props.slides ?? [])
const slidesLen = computed(() => coreSlides.value.length)
const renderSlides = computed(() => {
  const c = coreSlides.value
  return [...c, ...c, ...c]
})

/** Indexing / middle deck */
const currentIndexAbs = ref(0)
const middleStart = computed(() => slidesLen.value)
const middleEnd = computed(() => slidesLen.value * 2 - 1)
function clampToMiddle(abs: number) {
  if (abs > middleEnd.value) return abs - slidesLen.value
  if (abs < middleStart.value) return abs + slidesLen.value
  return abs
}
function absToReal(abs: number) {
  return ((abs % slidesLen.value) + slidesLen.value) % slidesLen.value
}
const activeRealIndex = computed(() => absToReal(currentIndexAbs.value))

/** Sizes / position */
const slideWidth = ref(0)
const translate = ref(0)
const isAnimating = ref(false)
const isDragging = ref(false)
const slideStep = computed(() => slideWidth.value + gap.value)

function measure() {
  if (!viewport.value || slidesLen.value === 0) return
  width.value = viewport.value.clientWidth
  slideWidth.value = isFade.value
    ? width.value
    : (width.value - gap.value * (perView.value - 1)) / perView.value
  translate.value = positionFor(currentIndexAbs.value)
}
function positionFor(absIndex: number) {
  if (isFade.value) return 0
  const base = absIndex * slideStep.value
  return props.centered ? base - (width.value - slideWidth.value) / 2 : base
}

/** CSS vars */
const rootVars = computed(
  () =>
    ({
      '--swiper-gap': `${gap.value}px`,
      '--swiper-speed': `${props.speed}ms`,
    } as Record<string, string>)
)

const trackHeight = ref(0)
const trackVars = computed(() => {
  if (isFade.value) {
    return {
      '--track-width': `${width.value}px`,
      '--track-x': '0px',
      '--track-height': `${trackHeight.value}px`,
    }
  }
  return {
    '--track-width': `${renderSlides.value.length * slideStep.value - gap.value}px`,
    '--track-x': `${-translate.value}px`,
  }
})
const viewportVars = computed(() =>
  isFade.value ? { '--track-height': `${trackHeight.value}px` } : {}
)
const slideVars = computed(() => ({ '--slide-width': `${slideWidth.value}px` }))

const fadeSlideVars = (absIndex: number) => {
  if (!isFade.value) return {}
  const real = absToReal(absIndex)
  const active = activeRealIndex.value
  const speed = props.fadeMode === 'instant' ? '0ms' : `${props.speed}ms`
  return {
    '--fade-width': `${slideWidth.value}px`,
    '--fade-opacity': real === active ? '1' : '0',
    '--fade-pointer': real === active ? 'auto' : 'none',
    '--fade-speed': speed,
    '--fade-ease': 'ease',
  }
}

/** Movement */
function animateTo(absIndex: number) {
  isAnimating.value = true
  currentIndexAbs.value = absIndex
  if (!isFade.value) translate.value = positionFor(absIndex)
}
function snapTo(absIndex: number) {
  const target = clampToMiddle(absIndex)
  isAnimating.value = false
  currentIndexAbs.value = target
  if (!isFade.value) translate.value = positionFor(target)
}

/** Progress (첫 슬라이드도 채움) */
const progressPct = ref(0)
function updateProgress() {
  if (!slidesLen.value) {
    progressPct.value = 0
    return
  }
  const real = activeRealIndex.value
  const pct = ((real + 1) / Math.max(1, slidesLen.value)) * 100
  progressPct.value = Math.max(2, Math.min(100, pct))
}

function onTransitionEnd() {
  if (slidesLen.value === 0) return
  const clamped = clampToMiddle(currentIndexAbs.value)
  if (clamped !== currentIndexAbs.value) snapTo(clamped)
  updateProgress()
  nextTick().then(observeActiveSlideHeight)
}

/** Public nav */
function goNext() {
  if (slidesLen.value) animateTo(currentIndexAbs.value + 1)
}
function goPrev() {
  if (slidesLen.value) animateTo(currentIndexAbs.value - 1)
}
function goTo(realIndex: number) {
  if (!slidesLen.value) return
  const target =
    middleStart.value + (((realIndex % slidesLen.value) + slidesLen.value) % slidesLen.value)
  animateTo(target)
}

/** Pause on interaction */
function maybePauseOnInteraction() {
  const conf = typeof props.autoplay === 'object' ? props.autoplay : {}
  const pause = conf.pauseOnInteraction ?? true
  if (pause) stopAutoplay()
}

/** Handlers */
function onNavClick(dir: 'prev' | 'next') {
  maybePauseOnInteraction()
  dir === 'prev' ? goPrev() : goNext()
  focusTrackSoon()
}
function onDotClick(realIndex: number) {
  maybePauseOnInteraction()
  goTo(realIndex)
  focusTrackSoon()
}
function dotTabIndex(realIndex: number) {
  return activeRealIndex.value === realIndex ? 0 : -1
}

/** Keyboard */
function onKeydown(e: KeyboardEvent) {
  maybePauseOnInteraction()
  if (e.key === 'ArrowRight') goNext()
  else if (e.key === 'ArrowLeft') goPrev()
  else if (e.key === 'Home') goTo(0)
  else if (e.key === 'End') goTo(slidesLen.value - 1)
}

/** Drag / Swipe */
let startX = 0
let startTranslate = 0
let pointerId: number | null = null
const THRESHOLD = 0.18
function normalizeDuringDrag() {
  if (isFade.value) return
  const leftGuard = positionFor(middleStart.value - 1)
  const rightGuard = positionFor(middleEnd.value + 1)
  const span = slidesLen.value * slideStep.value
  while (translate.value < leftGuard) {
    translate.value += span
    startTranslate += span
    currentIndexAbs.value += slidesLen.value
  }
  while (translate.value > rightGuard) {
    translate.value -= span
    startTranslate -= span
    currentIndexAbs.value -= slidesLen.value
  }
  updateProgress()
}
function onPointerDown(e: PointerEvent) {
  if (!props.allowTouchMove) return
  if (pointerId !== null) return
  pointerId = e.pointerId
  ;(e.target as Element).setPointerCapture(pointerId)
  isDragging.value = true
  isAnimating.value = false
  startX = e.clientX
  startTranslate = translate.value
  maybePauseOnInteraction()
}
function onPointerMove(e: PointerEvent) {
  if (!isDragging.value || e.pointerId !== pointerId) return
  if (isFade.value) return
  const dx = e.clientX - startX
  translate.value = startTranslate - dx
  normalizeDuringDrag()
}
function onPointerUp(e: PointerEvent) {
  if (e.pointerId !== pointerId) return
  ;(e.target as Element).releasePointerCapture(pointerId!)
  isDragging.value = false
  if (!isFade.value) {
    normalizeDuringDrag()
    const movedSlides = (translate.value - startTranslate) / slideStep.value
    if (!props.freeMode) {
      if (Math.abs(movedSlides) > THRESHOLD) movedSlides > 0 ? goNext() : goPrev()
      else animateTo(currentIndexAbs.value)
    } else {
      snapTo(Math.round(translate.value / slideStep.value))
    }
  }
  pointerId = null
}

/** Autoplay + Controls */
let autoTimer: number | null = null
const isPlaying = ref(false)
function play() {
  const conf = typeof props.autoplay === 'object' ? props.autoplay : {}
  const delay = conf.delay ?? 3000
  stopAutoplay()
  autoTimer = window.setInterval(() => {
    if (isDragging.value) return
    goNext()
  }, delay)
  isPlaying.value = true
}
function stopAutoplay() {
  if (autoTimer) window.clearInterval(autoTimer)
  autoTimer = null
  isPlaying.value = false
}
function pause() {
  stopAutoplay()
}

/** Reduced motion & visibility */
function prefersReducedMotion() {
  return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}
function onVisibilityChange() {
  if (document.hidden) stopAutoplay()
}
function focusTrackSoon() {
  requestAnimationFrame(() => {
    track.value?.focus?.()
  })
}

/** Fade height observer */
let ro: ResizeObserver | null = null
let observedEl: Element | null = null
function observeActiveSlideHeight() {
  if (!track.value || !isFade.value) return
  const real = activeRealIndex.value
  const el = track.value.querySelector(`.c-slide[data-real="${real}"]`) as HTMLElement | null
  if (!el) return
  if (ro && observedEl) ro.unobserve(observedEl)
  if (!ro) {
    ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const h = Math.ceil(entry.contentRect.height)
        if (h !== trackHeight.value) trackHeight.value = h
      }
    })
  }
  ro.observe(el)
  observedEl = el
  const h = Math.ceil(el.getBoundingClientRect().height)
  if (h !== trackHeight.value) trackHeight.value = h
}

/** Lifecycle */
function onResize() {
  measure()
  updateProgress()
  nextTick().then(observeActiveSlideHeight)
}

onMounted(async () => {
  await nextTick()
  measure()
  const startAbs =
    middleStart.value + Math.min(props.initialSlide, Math.max(0, slidesLen.value - 1))
  snapTo(startAbs)
  window.addEventListener('resize', onResize, { passive: true })
  document.addEventListener('visibilitychange', onVisibilityChange)
  // 접근성: reduced motion 사용자는 자동재생 시작하지 않음
  if (!prefersReducedMotion() && props.autoplay) play()
  updateProgress()
  observeActiveSlideHeight()
})
onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  document.removeEventListener('visibilitychange', onVisibilityChange)
  stopAutoplay()
  if (ro && observedEl) ro.unobserve(observedEl)
})

watch(
  () => [
    props.slidesPerView,
    props.spaceBetween,
    props.centered,
    props.breakpoints,
    slidesLen.value,
    effect.value,
    props.fadeMode,
  ],
  async () => {
    await nextTick()
    measure()
    const target = middleStart.value + activeRealIndex.value
    snapTo(target)
    updateProgress()
    observeActiveSlideHeight()
  }
)

defineExpose({ goNext, goPrev, goTo, play, pause })
</script>

<style scoped lang="scss">
@use '@/assets/scss/components/swiper' as *;
</style>
