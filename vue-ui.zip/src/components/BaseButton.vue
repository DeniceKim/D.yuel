<template>
  <button class="c-btn c-btn__primary">
    <slot />
  </button>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/button' as *;
</style>
