<template>
  <div class="c-toast">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/toast' as *;
</style>
