<template>
  <div class="c-accordion">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/accordion' as *;
</style>
