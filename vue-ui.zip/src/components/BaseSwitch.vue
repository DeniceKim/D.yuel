<template>
  <div class="c-switch">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/switch' as *;
</style>
