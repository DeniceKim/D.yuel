<template>
  <div class="c-select">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/select' as *;
</style>
