<template>
  <div class="c-tabs">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/tabs' as *;
</style>
