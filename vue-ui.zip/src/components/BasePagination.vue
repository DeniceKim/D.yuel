<template>
  <div class="c-pagination">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/pagination' as *;
</style>
