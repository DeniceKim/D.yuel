<template>
  <div class="c-input">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/input' as *;
</style>
