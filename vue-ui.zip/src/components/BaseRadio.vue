<template>
  <div class="c-radio">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/radio' as *;
</style>
