<template>
  <div class="c-checkbox">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/checkbox' as *;
</style>
