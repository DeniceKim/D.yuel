## Sass `legacy-js-api` 경고 정리

경고 메시지 예시
```
More info: https://sass-lang.com/d/legacy-js-api
Deprecation [legacy-js-api]: The legacy JS API is deprecated and will be removed in Dart Sass 2.0.0.
```

원인
- Dart Sass의 레거시 JS API(`render`, `renderSync`) 사용 경고입니다. Vite가 `sass` 패키지를 사용할 때 표시될 수 있습니다.

이 리포지토리의 해결 상태
- `sass` 의존성 제거 → Vite가 자동으로 `sass-embedded`를 사용하도록 유도
- Vite 시작 전에 무음 처리:
  - `vite.config.ts` 상단: `process.env.SASS_SILENCE_DEPRECATIONS = 'legacy-js-api'`
  - `.env*` 파일: `SASS_SILENCE_DEPRECATIONS=legacy-js-api`

로컬에서 반드시 해줄 작업
1) 개발 서버 종료
2) 클린 설치
```
rm -rf node_modules pnpm-lock.yaml
pnpm i
```
3) 실행
```
pnpm dev
```

여전히 보인다면
- 워크스페이스 내 다른 도구(별도 Sass 컴파일 스크립트, VS Code 확장 등)가 `sass.render*` API를 직접 사용 중인지 확인합니다.
- `pnpm why sass`로 `sass`가 하위 의존성에 끌려오는지 확인하고, 있다면 해당 패키지 업데이트/대체를 검토합니다.

