// Drop Dart Sass legacy JS API deprecation lines from console output.
// This is a non-invasive workaround for environments where sass-embedded
// cannot load a platform binary and falls back to the legacy JS API.
const target = 'legacy-js-api'

const wrap = (stream) => {
  const write = stream.write.bind(stream)
  stream.write = (chunk, enc, cb) => {
    try {
      const str = Buffer.isBuffer(chunk) ? chunk.toString(enc || 'utf8') : String(chunk)
      if (str.includes(target)) return true // swallow deprecation line
    } catch {}
    return write(chunk, enc, cb)
  }
}

wrap(process.stderr)
wrap(process.stdout)
