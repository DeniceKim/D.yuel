# 퍼블리싱 Demo UI 폴더 구조

```html
📦src
 ┣ 📂assets
 ┃ ┣ 📂images
 ┃ ┣ 📂scss
 ┃ ┃ ┣ 📂base
 ┃ ┃ ┃ ┣ 📜_functions.scss
 ┃ ┃ ┃ ┣ 📜_mixin.scss
 ┃ ┃ ┃ ┣ 📜_reset.scss
 ┃ ┃ ┃ ┣ 📜_tokens.scss
 ┃ ┃ ┃ ┣ 📜_utilities.scss
 ┃ ┃ ┃ ┗ 📜_variables.scss
 ┃ ┃ ┣ 📂components
 ┃ ┃ ┃ ┣ 📜_accordion.scss
 ┃ ┃ ┃ ┣ 📜_avatar.scss
 ┃ ┃ ┃ ┣ 📜_badge.scss
 ┃ ┃ ┃ ┣ 📜_breadcrumb.scss
 ┃ ┃ ┃ ┣ 📜_button.scss
 ┃ ┃ ┃ ┣ 📜_card.scss
 ┃ ┃ ┃ ┣ 📜_checkbox.scss
 ┃ ┃ ┃ ┣ 📜_drawer.scss
 ┃ ┃ ┃ ┣ 📜_input.scss
 ┃ ┃ ┃ ┣ 📜_navbar.scss
 ┃ ┃ ┃ ┣ 📜_pagination.scss
 ┃ ┃ ┃ ┣ 📜_progressbar.scss
 ┃ ┃ ┃ ┣ 📜_radio.scss
 ┃ ┃ ┃ ┣ 📜_select.scss
 ┃ ┃ ┃ ┣ 📜_sidebar.scss
 ┃ ┃ ┃ ┣ 📜_spinner.scss
 ┃ ┃ ┃ ┣ 📜_swiper.scss
 ┃ ┃ ┃ ┣ 📜_switch.scss
 ┃ ┃ ┃ ┣ 📜_tabbar.scss
 ┃ ┃ ┃ ┣ 📜_tabs.scss
 ┃ ┃ ┃ ┣ 📜_toast.scss
 ┃ ┃ ┃ ┗ 📜_tooltip.scss
 ┃ ┃ ┣ 📂guide
 ┃ ┃ ┃ ┗ 📜_guide.scss
 ┃ ┃ ┣ 📂layout
 ┃ ┃ ┃ ┗ 📜_layout.scss
 ┃ ┃ ┣ 📂main
 ┃ ┃ ┃ ┗ 📜_main.scss
 ┃ ┃ ┣ 📂page
 ┃ ┃ ┃ ┗ 📜_theme.scss
 ┃ ┃ ┣ 📜.DS_Store
 ┃ ┃ ┗ 📜index.scss
 ┣ 📂components
 ┃ ┣ 📜BaseAccordion.vue
 ┃ ┣ 📜BaseAvatar.vue
 ┃ ┣ 📜BaseBadge.vue
 ┃ ┣ 📜BaseBreadcrumb.vue
 ┃ ┣ 📜BaseButton.vue
 ┃ ┣ 📜BaseCard.vue
 ┃ ┣ 📜BaseCheckbox.vue
 ┃ ┣ 📜BaseDrawer.vue
 ┃ ┣ 📜BaseInput.vue
 ┃ ┣ 📜BaseModal.vue
 ┃ ┣ 📜BaseNavbar.vue
 ┃ ┣ 📜BasePagination.vue
 ┃ ┣ 📜BaseProgressBar.vue
 ┃ ┣ 📜BaseRadio.vue
 ┃ ┣ 📜BaseSelect.vue
 ┃ ┣ 📜BaseSidebar.vue
 ┃ ┣ 📜BaseSpinner.vue
 ┃ ┣ 📜BaseSwitch.vue
 ┃ ┣ 📜BaseTabbar.vue
 ┃ ┣ 📜BaseTabs.vue
 ┃ ┣ 📜BaseToast.vue
 ┃ ┣ 📜BaseTooltip.vue
 ┃ ┗ 📜SwiperCarousel.vue
 ┣ 📂composables
 ┃ ┣ 📜useDrawer.ts
 ┃ ┣ 📜useLayoutParts.ts
 ┃ ┗ 📜usePageName.ts
 ┣ 📂data
 ┃ ┣ 📜index.ts
 ┃ ┗ 📜pms.json
 ┣ 📂layouts
 ┃ ┣ 📜BaseLayout.vue
 ┃ ┣ 📜BenefitsLayout.vue
 ┃ ┣ 📜FinanceLayout.vue
 ┃ ┣ 📜GuideLayout.vue
 ┃ ┣ 📜MainLayout.vue
 ┃ ┣ 📜MenuLayout.vue
 ┃ ┣ 📜PageLayout.vue
 ┃ ┗ 📜ProductLayout.vue
 ┣ 📂pages
 ┃ ┣ 📂benefit
 ┃ ┃ ┣ 📂B01
 ┃ ┃ ┃ ┗ 📜B01.vue
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📂finance
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📂guide
 ┃ ┃ ┣ 📂demo
 ┃ ┃ ┃ ┣ 📜accordion.vue
 ┃ ┃ ┃ ┣ 📜avatar.vue
 ┃ ┃ ┃ ┣ 📜badge.vue
 ┃ ┃ ┃ ┣ 📜breadcrumb.vue
 ┃ ┃ ┃ ┣ 📜button.vue
 ┃ ┃ ┃ ┣ 📜card.vue
 ┃ ┃ ┃ ┣ 📜checkbox.vue
 ┃ ┃ ┃ ┣ 📜data.vue
 ┃ ┃ ┃ ┣ 📜demo.vue
 ┃ ┃ ┃ ┣ 📜input.vue
 ┃ ┃ ┃ ┣ 📜modal.vue
 ┃ ┃ ┃ ┣ 📜navbar.vue
 ┃ ┃ ┃ ┣ 📜pagination.vue
 ┃ ┃ ┃ ┣ 📜progressbar.vue
 ┃ ┃ ┃ ┣ 📜radio.vue
 ┃ ┃ ┃ ┣ 📜select.vue
 ┃ ┃ ┃ ┣ 📜sidebar.vue
 ┃ ┃ ┃ ┣ 📜spinner.vue
 ┃ ┃ ┃ ┣ 📜swiper.vue
 ┃ ┃ ┃ ┣ 📜switch.vue
 ┃ ┃ ┃ ┣ 📜tabs.vue
 ┃ ┃ ┃ ┣ 📜toast.vue
 ┃ ┃ ┃ ┗ 📜tooltip.vue
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📂intro
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📂menu
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📂product
 ┃ ┃ ┗ 📜index.vue
 ┃ ┣ 📜.DS_Store
 ┃ ┣ 📜DashBoard.vue
 ┃ ┣ 📜ErrorPage.vue
 ┃ ┗ 📜index.vue
 ┣ 📂router
 ┃ ┣ 📂modules
 ┃ ┃ ┣ 📜demo.ts
 ┃ ┃ ┣ 📜error.ts
 ┃ ┃ ┣ 📜guide.ts
 ┃ ┃ ┗ 📜main.ts
 ┃ ┗ 📜index.ts
 ┣ 📂utils
 ┃ ┣ 📜commonUtils.ts
 ┃ ┗ 📜theme.ts
 ┣ 📜App.vue
 ┣ 📜env.d.ts
 ┗ 📜main.ts

 📦vue-ui
 ┣ 📜.env
 ┣ 📜.env.development
 ┣ 📜.env.production
 ┣ 📜.eslintrc.cjs
 ┣ 📜.prettierrc.json
 ┣ 📜README.md
 ┣ 📜index.html
 ┣ 📜package.json
 ┣ 📜pnpm-workspace.yaml
 ┣ 📜tsconfig.json
 ┣ 📜vite.config.ts
```

# 기본 레이아웃 구조
```vue
## 전체 페이지의 라우터는 폴더 및 파일을 생성하면 자동으로 연결되는 구조.

## 레이아웃 class 공통
**l-* 로 시작하는 Prefix 제공**  

index.html
<div id="app" class="l-wrap"></div>

## 기본 레이아웃         
header, main, footer의 구조를 가지며 l-* 시작하는 Prefix 제공         

// 레이아웃의 상단영역 (컨포넌트 호출)
<header class="l-header"></header>       
// 레이아웃의 하단탭바 메뉴 (하단이 주어진 경우 선택)  (컨포넌트 호출)              
<nav class="c-tabbar" aria-label="하단 주메뉴">                     
// 레이아웃의 본문영역   
<main id="main" class="l-container" data-layout="레이아웃 Name" data-page="폴더-파일명">  
// 레이아웃의 하단영역 (하단이 주어진 경우 선택)              
<footer class="l-footer"></footer>   


## 레이아웃
layouts>BaseLayout.vue

// 공통 레이아웃 호출하여 각 필요 레이아웃 부분에 사용 여부 결정

<template>
  <BaseNavbar
    v-if="showNavbar"
    :title="(route.meta.title as string) || ''"
    :show-back="route.path !== '/'"
    @open-menu="openMenu"
    @back="goBack"
  />
  <BaseTabbar v-if="showTabbar" />

  <main id="main" class="l-container" :data-layout="layoutId" :data-page="pageName">
    <slot />
  </main>

  <BaseDrawer v-if="showDrawer" :open="drawerOpen" side="right" @close="closeMenu">
    <BaseSidebar />
  </BaseDrawer>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { useLayoutParts } from '@/composables/useLayoutParts'   # 

import BaseNavbar from '@/components/BaseNavbar.vue'
import BaseTabbar from '@/components/BaseTabbar.vue'
import BaseDrawer from '@/components/BaseDrawer.vue'
import BaseSidebar from '@/components/BaseSidebar.vue'

const route = useRoute()
const {
  showNavbar, showTabbar, showDrawer,
  layoutId, pageName,
  drawerOpen, openMenu, closeMenu, goBack,
} = useLayoutParts()
</script>

<style lang="scss">
@use '@/assets/scss/layout/layout' as *;
</style>

// :data-page="pageName" 이 부분에서 할당된 값은 각 페이지에서 생성한 폴더명-파일명 으로 자동 부여됨. 
composables>usePageName.ts
// 예시)data-page="demo-button" 케밥 케이스(Kebab case) 형식으로 선언


layouts>MainLayout.vue 등
<template>
  <!-- 공용 레이아웃 쉘로 감싸고, 내부에 이 레이아웃 전용 내용이 있으면 <template #default>에 작성 -->
  <BaseLayout>
    <!-- 이 레이아웃은 별도 UI 없이 라우팅 출력만 사용 -->
    <router-view />
  </BaseLayout>
</template>

<script setup lang="ts">
// 공용 레이아웃 쉘만 임포트하면 끝
import BaseLayout from './BaseLayout.vue'
</script>

// 사용여부는 페이지 라우터에서 결정
pages>index.vue

<route lang="yaml">
meta:
  title: 홈
  layout: MainLayout   # 해당 레이아웃 선택
  layoutId: home       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: true         # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>
```

---

# 📖 SwiperCarousel 컴포넌트 기능 가이드

## 0. 기본 사용
**기본 슬라이드 전환 + Bullets + Autoplay**

- `effect="slide"` (기본값)
- `pagination` 활성화 (bullets)
- `autoplay` 활성화 (delay 지정 가능)

```vue
<SwiperCarousel
  :autoplay="{ delay: 2200, pauseOnInteraction: true }"
  pagination
  pagination-type="bullets"
  navigation
  controls
  aria-label="기본 캐러셀"
/>
```

---

## 1. 네비게이션 버튼만
**Autoplay와 Controls(Play/Pause) 없이** 좌/우 버튼만 제공

```vue
<SwiperCarousel
  :autoplay="false"
  navigation
  :controls="false"
  pagination
  aria-label="네비게이션만"
/>
```

---

## 2. Pagination: Fraction
**현재 / 전체** 형태의 페이지네비게이션

```vue
<SwiperCarousel
  :slides-per-view="2"
  :space-between="12"
  pagination
  pagination-type="fraction"
  navigation
  aria-label="프랙션 페이지네이션"
/>
```

---

## 3. Pagination: Progressbar
**진행률 바 형태** 페이지네이션  
→ 첫 슬라이드에서도 0%가 아닌 **채워진 상태**로 시작

```vue
<SwiperCarousel
  pagination
  pagination-type="progressbar"
  navigation
  aria-label="프로그레스바 페이지네이션"
/>
```

---

## 4. 여러 장 보기 + 간격 + 가운데 정렬
- `slides-per-view` : 동시에 보이는 슬라이드 수
- `space-between` : 슬라이드 간격(px)
- `centered` : 현재 슬라이드를 중앙 정렬

```vue
<SwiperCarousel
  :slides-per-view="3"
  :space-between="16"
  centered
  navigation
  pagination
  aria-label="여러장/간격/센터"
/>
```

---

## 5. Breakpoints (반응형)
화면 너비에 따라 `slidesPerView`와 `spaceBetween` 값을 조정

```vue
<SwiperCarousel
  :breakpoints="{
    480:  { slidesPerView: 2, spaceBetween: 10 },
    768:  { slidesPerView: 3, spaceBetween: 14 },
    1024: { slidesPerView: 4, spaceBetween: 16 }
  }"
  pagination
  navigation
  aria-label="반응형 브레이크포인트"
/>
```

---

## 6. Free Mode (자유 스크럽)
슬라이드 단위가 아닌 **자유로운 스크롤**로 이동

```vue
<SwiperCarousel
  :free-mode="true"
  :slides-per-view="2"
  :space-between="12"
  navigation
  pagination
  aria-label="프리모드"
/>
```

---

## 7. Keyboard + Initial Slide
- `keyboard` : 키보드 화살표로 이동 가능
- `initial-slide` : 처음에 보여줄 슬라이드 index 지정

```vue
<SwiperCarousel
  keyboard
  navigation
  pagination
  :initial-slide="2"
  aria-label="키보드/초기슬라이드"
/>
```

---

## 8. 터치 이동 비활성
모바일/터치 환경에서 **스와이프 제스처 비활성화**  
(세로 스크롤 존중, 접근성 강화)

```vue
<SwiperCarousel
  :allow-touch-move="false"
  navigation
  pagination
  aria-label="터치 비활성"
/>
```

---

## 9. Fade 효과 – 부드러운 전환
- `effect="fade"`
- `fade-mode="smooth"` (기본) → 크로스페이드 전환
- CSS 변수로 속도/이징 제어 가능

```vue
<SwiperCarousel
  effect="fade"
  fade-mode="smooth"
  :autoplay="{ delay: 2500 }"
  :controls="true"
  pagination
  aria-label="페이드 스무스"
  style="--fade-ease: ease-in-out; --fade-speed: 400ms"
/>
```

---

## 10. Fade 효과 – 즉시 표시
- `fade-mode="instant"` → 전환 없이 바로 표시

```vue
<SwiperCarousel
  effect="fade"
  fade-mode="instant"
  :autoplay="false"
  :controls="true"
  pagination
  aria-label="페이드 인스턴트"
/>
```

---

## 11. Autoplay + 접근성 (항상 Pause 버튼 노출)
- `require-pause-for-autoplay=true` → WCAG 준수
- 자동재생 켜면 항상 **일시정지 버튼** 노출

```vue
<SwiperCarousel
  :autoplay="{ delay: 1800 }"
  :require-pause-for-autoplay="true"
  :controls="false"
  pagination
  navigation
  aria-label="접근성 자동재생"
/>
```

---

## 12. 풀옵션 콤보 (Stress Test)
여러 기능을 **동시에 조합**해서 테스트

```vue
<SwiperCarousel
  :slides-per-view="2"
  :space-between="12"
  :breakpoints="{
    600: { slidesPerView: 2, spaceBetween: 12 },
    900: { slidesPerView: 3, spaceBetween: 16 }
  }"
  centered
  navigation
  pagination
  pagination-type="bullets"
  keyboard
  :free-mode="false"
  :autoplay="{ delay: 2200, pauseOnInteraction: true }"
  :require-pause-for-autoplay="true"
  :initial-slide="1"
  aria-label="풀옵션 콤보"
  style="--swiper-gap: 12px; --swiper-speed: 350ms"
/>
```

---

## 13. 스타일 변수 커스텀
각 인스턴스별로 **전역 CSS 변수**를 덮어쓰기 가능

```vue
<div
  style="
    --swiper-dot-size:12px;
    --swiper-dot-color:#94a3b8;
    --swiper-dot-active:#ef4444;
    --swiper-radius:16px;
    --swiper-speed:500ms;
  "
>
  <SwiperCarousel
    navigation
    pagination
    aria-label="스타일 커스텀"
/>
</div>
```

---

# 📌 접근성(A11y) 고려사항
- **Play/Pause 컨트롤**: autoplay 사용 시 항상 제공  
- **Dot 네비게이션**: roving tabindex → 현재 슬라이드만 Tab 이동 가능  
- **ARIA 라이브 영역**: `aria-live="polite"`으로 슬라이드 변경 알림  
- **Fade 모드**: 보이지 않는 슬라이드에 `aria-hidden="true"` 적용  
- **터치 제스처**: `touch-action: pan-y pinch-zoom` → 세로 스크롤 존중  


# 📑 SwiperCarousel API Reference

## Props

| 속성명 | 타입 | 기본값 | 설명 |
|--------|------|--------|------|
| `slides` | `Array<any>` | `[ {n:1}, {n:2}, ... ]` | 슬라이드 데이터 배열. 슬롯(`v-slot:slide`)을 통해 커스텀 렌더링 가능 |
| `slidesPerView` | `number` | `1` | 동시에 보이는 슬라이드 개수 |
| `spaceBetween` | `number` | `8` | 슬라이드 간격(px) |
| `centered` | `boolean` | `false` | 현재 활성 슬라이드를 중앙에 배치 |
| `speed` | `number` | `300` | 전환 애니메이션 속도(ms) |
| `pagination` | `boolean` | `true` | 페이지네이션 표시 여부 |
| `paginationType` | `'bullets' \| 'fraction' \| 'progressbar'` | `'bullets'` | 페이지네이션 형태 선택 |
| `navigation` | `boolean` | `true` | 좌/우 네비게이션 버튼 표시 여부 |
| `controls` | `boolean` | `true` | 재생/정지/이전/다음 컨트롤 표시 여부 |
| `keyboard` | `boolean` | `true` | 키보드 이동 허용 (←, →, Home, End) |
| `freeMode` | `boolean` | `false` | 슬라이드 단위가 아닌 자유 스크롤 모드 |
| `allowTouchMove` | `boolean` | `true` | 터치/드래그 스와이프 허용 여부 |
| `initialSlide` | `number` | `0` | 첫 렌더링 시 시작할 슬라이드 index |
| `breakpoints` | `Record<number, { slidesPerView?: number; spaceBetween?: number }>` | `{}` | 반응형 설정. 화면 너비에 따라 `slidesPerView`/`spaceBetween` 값 변경 |
| `autoplay` | `boolean \| { delay?: number; pauseOnInteraction?: boolean }` | `false` | 자동재생 설정. `delay`(ms), `pauseOnInteraction` 옵션 가능 |
| `ariaLabel` | `string` | `'이미지 캐러셀'` | 캐러셀 영역에 대한 접근성 레이블 |
| `pauseOnMouseEnter` | `boolean` | `true` | 마우스 hover 시 자동재생 일시정지 |
| `effect` | `'slide' \| 'fade'` | `'slide'` | 슬라이드 전환 효과 |
| `fadeMode` | `'smooth' \| 'instant'` | `'smooth'` | Fade 효과 시 전환 방식 (부드럽게 / 즉시) |
| `requirePauseForAutoplay` | `boolean` | `true` | autoplay 사용 시 **항상 일시정지 버튼** 노출 (WCAG 준수) |

---

## Slots

| 슬롯명 | 설명 |
|--------|------|
| `slide` | 개별 슬라이드 커스텀 렌더링. `:item`, `:index` 전달 |

예시:

```vue
<SwiperCarousel :slides="items">
  <template #slide="{ item, index }">
    <article class="custom-slide">
      <h4>{{ index + 1 }}. {{ item.title }}</h4>
      <p>{{ item.desc }}</p>
    </article>
  </template>
</SwiperCarousel>
```

---

## Exposed Methods

| 메서드 | 설명 |
|--------|------|
| `goNext()` | 다음 슬라이드로 이동 |
| `goPrev()` | 이전 슬라이드로 이동 |
| `goTo(index: number)` | 특정 index로 이동 |
| `play()` | autoplay 시작 |
| `pause()` | autoplay 일시정지 |

---

## CSS Variables

| 변수명 | 설명 |
|--------|------|
| `--swiper-gap` | 슬라이드 간격 |
| `--swiper-speed` | 전환 속도(ms) |
| `--swiper-radius` | 슬라이드 카드 radius |
| `--swiper-dot-size` | pagination dot 크기 |
| `--swiper-dot-gap` | pagination dot 간격 |
| `--swiper-dot-color` | dot 기본 색상 |
| `--swiper-dot-active` | dot 활성 색상 |
| `--fade-speed` | fade 전환 속도 |
| `--fade-ease` | fade easing 함수 |

---

