// ✅ [추가/수정] extendRoute에서 항상 "폴더-파일" 형식으로 meta.fileName 주입
// ✅ [추가/수정] Windows 경로(\)를 '/'로 정규화하여 안전 처리
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import Pages from 'vite-plugin-pages'
import Layouts from 'vite-plugin-vue-layouts'
import path from 'node:path'

// Ensure Dart Sass deprecation notices for legacy JS API are silenced
// even if .env loading happens later in the toolchain.
process.env.SASS_SILENCE_DEPRECATIONS ||= 'legacy-js-api'

export default defineConfig({
  plugins: [
    vue(),
    Pages({
      dirs: 'src/pages',
      extensions: ['vue'],
      routeBlockLang: 'yaml',
      extendRoute(route) {
        const comp = route.component as string | undefined
        if (!comp) return route

        // 경로 구분자 통일
        const norm = comp.replace(/\\/g, '/')

        // '/pages/' 뒤쪽만 사용
        const idx = norm.lastIndexOf('/pages/')
        const sub = idx >= 0 ? norm.slice(idx + '/pages/'.length) : norm

        // 예: 'benefit/B01/B01.vue' → ['benefit','B01','B01.vue']
        const segs = sub.split('/').filter(Boolean)

        // 마지막 요소 = 파일명(.vue 제거), 그 앞 = 폴더명
        const file = (segs[segs.length - 1] || '').replace(/\.vue$/, '')
        const folder = segs.length > 1 ? segs[segs.length - 2] : ''

        // 루트 index.vue는 'index', 그 외는 '폴더-파일'
        const fileName = folder ? `${folder}-${file}` : file

        // meta.fileName 주입
        route.meta = { ...(route.meta || {}), fileName }
        return route
      },
    }),
    Layouts({
      layoutsDirs: 'src/layouts',
      defaultLayout: 'MainLayout',
    }),
  ],
  resolve: {
    alias: { '@': path.resolve(__dirname, 'src') },
  },
  css: {
    preprocessorOptions: {
      scss: {
        // (참고) 전역 SCSS 함수/토큰 자동 주입
        additionalData: `
          @use "@/assets/scss/base/functions" as fn;
          @use "@/assets/scss/base/tokens" as *;
        `,
      },
    },
  },
  server: {
    host: '0.0.0.0',
    port: 8000,
    open: true,
  },
})
