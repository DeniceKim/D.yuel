import pms from './pms.json'; export { pms };
