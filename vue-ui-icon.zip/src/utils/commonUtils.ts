/**
 * ======================
 * 환경 감지 (OS/브라우저/디바이스)
 * ======================
 */
export function detectEnvironment(): void {
  const userAgent: string = navigator.userAgent.toLowerCase();
  const htmlElement: HTMLElement = document.documentElement;

  // OS
  if (userAgent.includes("windows")) htmlElement.classList.add("os_windows");
  else if (userAgent.includes("macintosh") || userAgent.includes("mac os x")) htmlElement.classList.add("os_mac");
  else if (userAgent.includes("android")) htmlElement.classList.add("os_android");
  else if (userAgent.includes("iphone") || userAgent.includes("ipad") || userAgent.includes("ios")) htmlElement.classList.add("os_ios");

  // Device
  if (/mobile|android|iphone|ipad|ios/i.test(userAgent)) htmlElement.classList.add("mobile");
  else htmlElement.classList.add("pc");

  // Browser + version
  if (userAgent.includes("chrome") && !userAgent.includes("edg")) {
    const v = userAgent.match(/chrome\/(\d+)/)?.[1];
    if (v) htmlElement.classList.add("chrome", `ver_${v}`);
  } else if (userAgent.includes("firefox")) {
    const v = userAgent.match(/firefox\/(\d+)/)?.[1];
    if (v) htmlElement.classList.add("firefox", `ver_${v}`);
  } else if (userAgent.includes("safari") && !userAgent.includes("chrome")) {
    const v = userAgent.match(/version\/(\d+)/)?.[1];
    if (v) htmlElement.classList.add("safari", `ver_${v}`);
  } else if (userAgent.includes("edg")) {
    const v = userAgent.match(/edg\/(\d+)/)?.[1];
    if (v) htmlElement.classList.add("edge", `ver_${v}`);
  } else if (userAgent.includes("opera") || userAgent.includes("opr")) {
    const v = userAgent.match(/opr\/(\d+)/)?.[1];
    if (v) htmlElement.classList.add("opera", `ver_${v}`);
  }
}

/**
 * 옵션 타입
 */
type ScrollOpts = {
  /** ✅ 헤더 선택자(기본 .l-header) */
  headerSelector?: string;
  /** ✅ 헤더에 붙일 그림자 클래스명(기본 is-shadow) */
  headerShadowClass?: string;
};

/**
 * ======================
 * 스크롤 이벤트 초기화
 * body class: top, end, scrolldown, scrollup, fstop
 * ----------------------
 * ✅ 변경점
 * - 헤더를 초기 1회만 찾던 것을, 매 스크롤에서 "못 찾았으면 재탐색" 하도록 변경
 * - 헤더 선택자와 그림자 클래스명을 옵션으로 주입 가능
 * - passive 옵션과 rAF로 과도한 연산 방지
 * ======================
 */
export const initializeScrollEvents = (opts: ScrollOpts = {}): (() => void) => {
  const {
    headerSelector = '.l-header',     // ✅ 기본 .l-header
    headerShadowClass = 'is-shadow',  // ✅ 기본 is-shadow
  } = opts;

  let previousScrollTop = window.scrollY;
  let isScrolling: ReturnType<typeof setTimeout>;
  let ticking = false;

  let header: HTMLElement | null = null;
  const resolveHeader = () => (header ||= document.querySelector<HTMLElement>(headerSelector));

  const _update = () => {
    const currentScrollTop = window.scrollY;
    const body = document.body;
    const windowHeight = window.innerHeight;
    const docHeight = document.documentElement.scrollHeight;

    // 상단 감지
    if (currentScrollTop === 0) {
      body.classList.add('top');
      resolveHeader()?.classList.remove(headerShadowClass);
    } else {
      body.classList.remove('top');
      resolveHeader()?.classList.add(headerShadowClass);
    }

    // 방향 감지
    if (currentScrollTop > previousScrollTop) {
      body.classList.remove('scrollup');
      body.classList.add('scrolldown');
    } else {
      body.classList.remove('scrolldown');
      body.classList.add('scrollup');
    }

    // 하단 감지
    if (currentScrollTop + windowHeight >= docHeight) {
      body.classList.add('end');
    } else {
      body.classList.remove('end');
    }

    // 멈춤 감지
    body.classList.remove('fstop');
    clearTimeout(isScrolling);
    isScrolling = setTimeout(() => body.classList.add('fstop'), 150);

    previousScrollTop = currentScrollTop;
    ticking = false;
  };

  const handleScroll = () => {
    if (!ticking) {
      ticking = true;
      // ✅ 성능: 스크롤 처리 rAF로 모아서 실행
      requestAnimationFrame(_update);
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });

  return () => {
    window.removeEventListener('scroll', handleScroll);
  };
};

/**
 * ======================
 * textarea 포커스 시 상단으로 이동 (iOS 키패드 대응)
 * ----------------------
 * ✅ 변경점
 * - 헤더 선택자를 옵션으로 통일(.l-header 기본)
 * ======================
 */
export const initializeTextareaFocusHandler = (
  defaultOffset: number = 20,
  headerSelector: string = '.l-header', // ✅ 통일
): (() => void) => {
  const handleFocus = (event: FocusEvent): void => {
    const target = event.target as HTMLElement;
    if (!target || target.tagName.toLowerCase() !== 'textarea') return;

    const header = document.querySelector<HTMLElement>(headerSelector);
    const headerHeight = header ? header.offsetHeight : defaultOffset;
    const targetTop = target.getBoundingClientRect().top + window.scrollY;
    const scrollToPosition = targetTop - headerHeight - defaultOffset;

    window.scrollTo({ top: scrollToPosition, behavior: 'smooth' });
  };

  document.addEventListener('focusin', handleFocus);
  return () => document.removeEventListener('focusin', handleFocus);
};

/**
 * ======================
 * "Top 버튼" 및 Floating 버튼 관리
 * ======================
 */
export const scrollToTopAction = (): void => {
  const btmGroup = document.querySelector<HTMLDivElement>('.btm_group');
  const floating = document.querySelector<HTMLDivElement>('.subscribe');
  const tabbarButtons = document.querySelectorAll<HTMLButtonElement>('[data-nav-type="tabbar"] button');
  const chatbotBtn = document.querySelector<HTMLButtonElement>('[data-btn-type="chatbot"]');

  let scrollTimer: ReturnType<typeof setTimeout> | null = null;

  const onScroll = (): void => {
    const scrollTop = window.scrollY;
    const windowHeight = window.innerHeight;
    const documentHeight = document.body.scrollHeight;
    const bottomGroupHeight = btmGroup ? btmGroup.offsetHeight : 0;
    const scrollEndThreshold = documentHeight - windowHeight - bottomGroupHeight;

    floating?.classList.toggle('is-show', scrollTop !== 0);

    document.body.classList.toggle('end', scrollTop >= scrollEndThreshold);
    document.body.classList.toggle('fstop', scrollTop >= scrollEndThreshold);

    document.querySelectorAll<HTMLDivElement>('.cnt_body').forEach((el) => {
      const elementTop = el.getBoundingClientRect().top + scrollTop;
      el.classList.toggle('top', scrollTop >= elementTop - 44);
    });

    if (chatbotBtn) {
      chatbotBtn.classList.remove('is-show');
      if (scrollTimer) clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        if (scrollTop > 0) chatbotBtn.classList.add('is-show');
      }, 500);
    }
  };

  const onTopButtonClick = (event: MouseEvent): void => {
    const target = event.target as HTMLElement;
    if (target.matches('.btn[data-btn-type="topbutton"]')) {
      event.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const onTabbarButtonClick = (): void => {
    document.querySelectorAll<HTMLDivElement>('.cnt_body').forEach((el) => el.classList.remove('top'));
  };

  document.addEventListener('scroll', onScroll, { passive: true });
  document.addEventListener('click', onTopButtonClick);
  tabbarButtons.forEach((btn) => btn.addEventListener('click', onTabbarButtonClick));
};

/**
 * ======================
 * 선택된 항목을 중앙으로 스크롤 (가로 스크롤 전용)
 * ======================
 */
export function xScrollToCenter(container: HTMLElement | null, item: HTMLElement | null): void {
  if (!container || !item) return;
  const containerRect = container.getBoundingClientRect();
  const itemRect = item.getBoundingClientRect();
  const left =
    container.scrollLeft +
    (itemRect.left - containerRect.left) -
    container.clientWidth / 2 +
    item.clientWidth / 2;

  container.scrollTo({ left, behavior: "smooth" });
}
