export type ThemeMode = 'light' | 'dark'

const KEY = 'theme.mode'

export function getTheme(): ThemeMode {
  const saved = (localStorage.getItem(KEY) as ThemeMode) || 'light'
  return saved
}

export function applyTheme(mode: ThemeMode) {
  const html = document.documentElement
  if (mode === 'dark') html.setAttribute('data-theme', 'dark')
  else html.setAttribute('data-theme', 'light')
  localStorage.setItem(KEY, mode)
}

export function toggleTheme() {
  const next = getTheme() === 'dark' ? 'light' : 'dark'
  applyTheme(next)
  return next
}

export function initTheme() {
  const saved = getTheme()
  applyTheme(saved)
}
