/**
 * 인라인 SVG 로더 유틸리티
 * - Vite의 import.meta.glob를 사용해 images 폴더 하위의 모든 SVG 파일을 raw 문자열로 불러옵니다.
 * - 기본값(colorize=true)일 때 모든 fill="#xxxxxx"를 fill="currentColor"로 치환하여
 *   CSS의 color 속성으로 아이콘 색을 쉽게 제어할 수 있습니다.
 *
 * 사용 예시(Vue SFC):
 *
 *  <script setup lang="ts">
 *  import { getInlineIcon } from '@/utils/inlineSvg'
 *  </script>
 *  <template>
 *    <!-- 1) 파일명(확장자 없이)으로 불러오기: /src/assets/images/** 에서 첫 매칭 사용 -->
 *    <span class="icon" v-html="getInlineIcon('icon-tabbar-home')" />
 *
 *    <!-- 2) images 하위 상대경로로 불러오기(확장자 생략 가능) -->
 *    <span class="icon" v-html="getInlineIcon('icon/icon-tabbar-home.svg')" />
 *    <span class="icon" v-html="getInlineIcon('icon/icon-tabbar-home')" />
 *
 *    <!-- 3) 원본 색 유지(치환 비활성화) -->
 *    <span class="icon" v-html="getInlineIcon('illustrations/empty-state', { colorize: false })" />
 *  </template>
 *
 *  <style scoped>
 *  // colorize=true일 때 SVG는 currentColor(부모 color)를 상속합니다.
 *  .icon { color: #0f172a; width: 24px; height: 24px; display: inline-flex; }
 *  .icon :where(svg) { width: 100%; height: 100%; display: block; }
 *  </style>
 */

// Raw SVG cache for ALL images under assets/images (Vite inlines them at build time)
const rawSvgs = import.meta.glob('@/assets/images/**/*.svg', {
  eager: true,
  query: '?raw',
  import: 'default',
}) as Record<string, string>

// Build a secondary lookup by base filename (without extension)
const byBase = new Map<string, string>()
for (const fullPath in rawSvgs) {
  const name = fullPath.split('/').pop() || ''
  const base = name.replace(/\.svg$/i, '')
  if (!base) continue
  // Last-in wins; if you prefer priority for certain folders, adjust here
  byBase.set(base, fullPath)
}

/** Replace any hardcoded hex fills with currentColor */
export function toCurrentColor(svg: string): string {
  return svg.replace(/fill=\"#(?:[0-9a-fA-F]{3,8})\"/g, 'fill="currentColor"')
}

/**
 * Get inline SVG markup by base name (without extension)
 * @param base e.g. 'icon-tabbar-home'
 * @param opts.colorize if true (default), convert hex fills to currentColor
 */
export function getInlineIcon(pathOrBase: string, opts: { colorize?: boolean } = {}): string {
  const { colorize = true } = opts
  let key: string | undefined
  if (pathOrBase.includes('/')) {
    // Treat as path relative to @/assets/images
    const rel = pathOrBase.startsWith('@/assets/images/') ? pathOrBase : `@/assets/images/${pathOrBase.replace(/^\/+/, '')}`
    key = rel.endsWith('.svg') ? rel : `${rel}.svg`
  } else {
    // Treat as base name without extension
    const mapped = byBase.get(pathOrBase)
    key = mapped ? mapped : undefined
  }
  if (!key) return ''
  const raw = rawSvgs[key]
  if (!raw) return ''
  return colorize ? toCurrentColor(raw) : raw
}

/**
 * Helper to build a map getter for a given directory (future use)
 */
export function makeInlineGetter(glob: Record<string, string>) {
  return (pathOrBase: string, { colorize = true } = {}) => {
    const key = pathOrBase.endsWith('.svg') ? pathOrBase : `${pathOrBase}.svg`
    const svg = glob[key]
    if (!svg) return ''
    return colorize ? toCurrentColor(svg) : svg
  }
}
