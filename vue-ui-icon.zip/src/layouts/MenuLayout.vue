<template>
  <!-- 공용 레이아웃 쉘로 감싸고, 내부에 이 레이아웃 전용 내용이 있으면 <template #default>에 작성 -->
  <BaseLayout>
    <!-- 이 레이아웃은 별도 UI 없이 라우팅 출력만 사용 -->
    <router-view />
  </BaseLayout>
</template>

<script setup lang="ts">
// 공용 레이아웃 쉘만 임포트하면 끝
import BaseLayout from './BaseLayout.vue'
</script>
