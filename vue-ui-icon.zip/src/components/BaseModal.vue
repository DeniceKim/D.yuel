<template>
  <teleport to="body">
    <div v-if="modelValue" class="c-drawer__backdrop" @click="$emit('update:modelValue', false)" />
    <div
      v-if="modelValue"
      class="c-card"
      role="dialog"
      aria-modal="true"
      aria-label="공지"
      style="position: fixed; left: 16px; right: 16px; top: 20%; z-index: 90"
    >
      <header class="c-card__header">
        <slot name="title"> 알림 </slot>
      </header>
      <div class="c-card__body">
        <slot />
      </div>
      <footer class="c-card__footer">
        <slot name="footer" />
      </footer>
    </div>
  </teleport>
</template>
<script setup lang="ts">
defineProps<{ modelValue: boolean }>()
defineEmits(['update:modelValue'])
</script>
<style scoped lang="scss">
@use '../assets/scss/components/card' as *;
@use '../assets/scss/components/drawer' as *; /* backdrop 재사용 */
</style>
