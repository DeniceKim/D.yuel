<template>
  <div class="c-accordion" :data-level="level">
    <ul class="c-accordion__list" role="list">
      <li
        v-for="(item, idx) in items"
        :key="getId(item)"
        class="c-accordion__item"
        :class="{ 'is-open': isOpen(getId(item)) }"
      >
        <div
          class="c-accordion__header"
          role="heading"
          :aria-level="Math.min(6, ariaBaseLevel + level)"
        >
          <!-- Header slot allows full control over label rendering -->
          <button
            type="button"
            class="c-accordion__toggle"
            :id="headerId(getId(item))"
            :aria-expanded="isOpen(getId(item))"
            :aria-controls="panelId(getId(item))"
            :disabled="isDisabled(item)"
            @click="onToggle(item, idx)"
            @keydown="onHeaderKeydown(idx, $event)"
            :ref="(el) => setToggleRef(el, idx)"
          >
            <slot name="header" :item="item" :is-open="isOpen(getId(item))">
              {{ getLabel(item) }}
            </slot>
          </button>
        </div>

        <div
          v-show="isOpen(getId(item))"
          class="c-accordion__panel"
          role="region"
          :id="panelId(getId(item))"
          :aria-labelledby="headerId(getId(item))"
          :hidden="!isOpen(getId(item))"
        >
          <!-- Default slot for body/content -->
          <slot :item="item" :is-open="isOpen(getId(item))">
            <div class="c-accordion__content">
              {{ getContent(item) }}
            </div>
          </slot>

          <!-- Recursive children -->
          <BaseAccordion
            v-if="getChildren(item)?.length"
            :items="getChildren(item) || []"
            :multiple="multiple"
            :open-first="openFirstAllLevels"
            :open-first-all-levels="openFirstAllLevels"
            :initial-open-ids="initialOpenIds"
            :id-key="idKey"
            :label-key="labelKey"
            :children-key="childrenKey"
            :content-key="contentKey"
            :level="level + 1"
            :path-prefix="idPath(getId(item))"
            :aria-base-level="ariaBaseLevel"
            @change="forwardChange"
          />
        </div>
      </li>
    </ul>
  </div>
</template>
<script setup lang="ts">
defineOptions({ name: 'BaseAccordion' })
import { onMounted, ref, watch } from 'vue'

type Key = string | number

interface GenericItem {
  [key: string]: any
}

const props = withDefaults(
  defineProps<{
    items?: GenericItem[]
    multiple?: boolean
    // 초기 로드시 첫 번째 아이템을 열기 (현재 레벨에 적용)
    openFirst?: boolean
    // 모든 레벨에서 첫 번째 아이템 열기 (재귀 적용)
    openFirstAllLevels?: boolean
    // 지정한 id 목록을 열기 (트리 전역)
    initialOpenIds?: Key[]
    // 키 필드명 커스터마이즈
    idKey?: string
    labelKey?: string
    childrenKey?: string
    contentKey?: string
    disabledKey?: string
    // 재귀 깊이 (내부용)
    level?: number
    // a11y heading base level
    ariaBaseLevel?: number
    // unique id path prefix from ancestors
    pathPrefix?: string
  }>(),
  {
    multiple: false,
    openFirst: false,
    openFirstAllLevels: false,
    initialOpenIds: () => [],
    idKey: 'id',
    labelKey: 'label',
    childrenKey: 'children',
    contentKey: 'content',
    disabledKey: 'disabled',
    level: 0,
    ariaBaseLevel: 3,
    pathPrefix: '',
    items: () => [],
  }
)

const emit = defineEmits<{
  (e: 'change', payload: { id: Key; open: boolean; item: GenericItem; level: number }): void
}>()

// 현재 레벨에서 열린 항목 id 집합
const openSet = ref<Set<Key>>(new Set())

function getId(item: GenericItem): Key {
  return item[props.idKey] as Key
}
function getLabel(item: GenericItem): string {
  return String(item[props.labelKey] ?? '')
}
function getChildren(item: GenericItem): GenericItem[] | undefined {
  return item[props.childrenKey] as GenericItem[] | undefined
}
function getContent(item: GenericItem): any {
  return item[props.contentKey]
}
function isDisabled(item: GenericItem): boolean {
  return !!item[props.disabledKey]
}

function isOpen(id: Key) {
  return openSet.value.has(id)
}

function closeAll() {
  openSet.value.clear()
}

function onToggle(item: GenericItem, index: number) {
  if (isDisabled(item)) return
  const id = getId(item)
  const willOpen = !isOpen(id)

  if (!props.multiple) {
    closeAll()
  }

  if (willOpen) {
    openSet.value.add(id)
  } else {
    openSet.value.delete(id)
  }

  emit('change', { id, open: willOpen, item, level: props.level })
}

// 초기 오픈 처리: 모든 레벨 또는 현재 레벨의 첫 번째
onMounted(() => {
  if (!props.items?.length) return

  // 1) initialOpenIds 우선 적용 (현재 레벨 아이템 중 일치하는 id)
  let matched = 0
  if (props.initialOpenIds?.length) {
    for (const it of props.items) {
      const id = getId(it)
      if (props.initialOpenIds.includes(id)) {
        if (!props.multiple && matched >= 1) break
        openSet.value.add(id)
        matched++
      }
    }
  }

  // 2) 매치가 없고 첫번째 열기 옵션이 켜져 있으면 적용
  if (matched === 0) {
    const shouldOpenFirst = props.openFirstAllLevels || (props.openFirst && props.level === 0)
    if (shouldOpenFirst) {
      const first = props.items[0]
      if (first) openSet.value.add(getId(first))
    }
  }
})

// 외부에서 initialOpenIds가 바뀌면 동기화(닫힌 상태 초기화 방지)
watch(
  () => props.initialOpenIds,
  (ids) => {
    // 동적으로 외부에서 초기 오픈 id가 바뀌면 현재 레벨 재계산
    const next = new Set<Key>()
    let matched = 0
    if (ids?.length) {
      for (const it of props.items) {
        const id = getId(it)
        if (ids.includes(id)) {
          if (!props.multiple && matched >= 1) break
          next.add(id)
          matched++
        }
      }
    }
    if (matched === 0) {
      const shouldOpenFirst = props.openFirstAllLevels || (props.openFirst && props.level === 0)
      if (shouldOpenFirst && props.items?.[0]) {
        next.add(getId(props.items[0]))
      }
    }
    openSet.value = next
  }
)

// 이벤트 전달 (자식에서 올라오는 change를 그대로 재방출)
function forwardChange(evt: { id: Key; open: boolean; item: GenericItem; level: number }) {
  emit('change', evt)
}

// 접근성: id path는 조상 경로를 포함해 전역 고유성 보장
function idPath(id: Key): string {
  const base = props.pathPrefix ? props.pathPrefix + '-' : ''
  return `${base}${String(id)}`
}

function headerId(id: Key) {
  return `acc-header-${idPath(id)}`
}
function panelId(id: Key) {
  return `acc-panel-${idPath(id)}`
}

// 같은 레벨 내 헤더 간 키보드 이동(Arrow/Home/End)
const toggleRefs = ref<Array<HTMLElement | null>>([])
function setToggleRef(el: any, index: number) {
  toggleRefs.value[index] = (el as HTMLElement | null)
}
function onHeaderKeydown(index: number, e: KeyboardEvent) {
  const { key } = e
  if (key === 'Enter' || key === ' ') {
    e.preventDefault()
    // Space/Enter 토글
    const item = props.items[index]
    if (item) onToggle(item, index)
    return
  }
  if (key === 'ArrowRight' || key === 'ArrowLeft') {
    e.preventDefault()
    const item = props.items[index]
    if (!item) return
    const open = isOpen(getId(item))
    if (key === 'ArrowRight' && !open) onToggle(item, index)
    if (key === 'ArrowLeft' && open) onToggle(item, index)
    return
  }
  if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Home' || key === 'End') {
    e.preventDefault()
    const refs = toggleRefs.value
    if (!refs.length) return
    let next = index
    if (key === 'ArrowDown') next = Math.min(refs.length - 1, index + 1)
    else if (key === 'ArrowUp') next = Math.max(0, index - 1)
    else if (key === 'Home') next = 0
    else if (key === 'End') next = refs.length - 1
    refs[next]?.focus()
  }
}

// programmatic API (current level)
function open(id: Key) {
  if (!props.multiple) closeAll()
  openSet.value.add(id)
}
function close(id: Key) {
  openSet.value.delete(id)
}
function toggleById(id: Key) {
  isOpen(id) ? close(id) : open(id)
}
function openAll() {
  if (!props.multiple) {
    if (props.items[0]) open(getId(props.items[0]))
    return
  }
  for (const it of props.items) openSet.value.add(getId(it))
}
function closeAllItems() {
  closeAll()
}
function getOpenIds(): Key[] {
  return Array.from(openSet.value)
}

defineExpose({ open, close, toggle: toggleById, openAll, closeAll: closeAllItems, getOpenIds })

</script>
<style scoped lang="scss">
@use '../assets/scss/components/accordion' as *;
</style>
