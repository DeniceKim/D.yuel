<template>
  <aside
    class="c-sidebar"
    :class="{ 'is-collapsed': collapsed, 'is-overlay': overlay }"
    :style="rootStyle"
    :aria-label="ariaLabel || '사이드바'"
  >
    <header class="c-sidebar__header">
      <slot name="header">
        <button v-if="collapsible" class="c-sidebar__toggle" type="button" @click="toggle()" aria-label="사이드바 토글">
          {{ collapsed ? '▶' : '◀' }}
        </button>
        <strong class="c-sidebar__title"><slot name="title">Menu</slot></strong>
      </slot>
    </header>

    <div class="c-sidebar__body">
      <!-- Sections rendering (props), fallback to default demo links when empty -->
      <template v-if="sections?.length">
        <section v-for="(sec, si) in sections" :key="si" class="c-sidebar__section">
          <p v-if="sec.title" class="c-sidebar__section-title">{{ sec.title }}</p>
          <ul class="c-sidebar__list" role="list">
            <li v-for="it in sec.items" :key="String(it.to || it.label)">
              <component :is="linkTag(it)" :to="it.to" :href="it.href" class="c-sidebar__link">
                <span v-if="it.icon" class="c-sidebar__icon" aria-hidden="true">{{ it.icon }}</span>
                <span class="c-sidebar__label">{{ it.label }}</span>
              </component>
            </li>
          </ul>
        </section>
      </template>

      <template v-else>
        <p class="c-sidebar__section-title">Pages</p>
        <ul class="c-sidebar__list">
          <li><RouterLink class="c-sidebar__link" to="/"> 홈 </RouterLink></li>
          <li><RouterLink class="c-sidebar__link" to="/guide"> 가이드 </RouterLink></li>
          <li><RouterLink class="c-sidebar__link" to="/dashboard"> 대시보드 </RouterLink></li>
          <li><RouterLink class="c-sidebar__link" to="/intro"> 소개 </RouterLink></li>
        </ul>
        <p class="c-sidebar__section-title">Guide / Demos</p>
        <ul class="c-sidebar__list">
          <li v-for="it in demo" :key="it.to">
            <RouterLink class="c-sidebar__link" :to="it.to"> {{ it.label }} </RouterLink>
          </li>
        </ul>
      </template>
    </div>

    <footer class="c-sidebar__footer">
      <slot name="footer" />
    </footer>
  </aside>
  
</template>
<script setup lang="ts">
import { computed } from 'vue'

interface NavItem { label: string; to?: string; href?: string; icon?: string }
interface Section { title?: string; items: NavItem[] }

const props = withDefaults(
  defineProps<{ sections?: Section[]; collapsible?: boolean; modelValue?: boolean; width?: number | string; collapsedWidth?: number | string; overlay?: boolean; ariaLabel?: string }>(),
  { sections: () => [], collapsible: true, modelValue: false, width: 240, collapsedWidth: 56, overlay: false }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: boolean): void; (e: 'toggle', v: boolean): void }>()

const collapsed = computed(() => !!props.modelValue)
const overlay = computed(() => !!props.overlay)
const rootStyle = computed(() => {
  const w = typeof props.width === 'number' ? `${props.width}px` : props.width
  const cw = typeof props.collapsedWidth === 'number' ? `${props.collapsedWidth}px` : props.collapsedWidth
  return { '--sb-width': w, '--sb-width-collapsed': cw } as any
})

function toggle() {
  const next = !collapsed.value
  emit('update:modelValue', next)
  emit('toggle', next)
}

function linkTag(it: NavItem) {
  return it.href ? 'a' : 'RouterLink'
}

const demo = [
  { to: '/guide/demo/button', label: 'Button' },
  { to: '/guide/demo/card', label: 'Card' },
  { to: '/guide/demo/tabs', label: 'Tabs' },
  { to: '/guide/demo/sidebar', label: 'Sidebar' },
  { to: '/guide/demo/navbar', label: 'Navbar' },
  { to: '/guide/demo/swiper', label: 'Swiper' },
  { to: '/guide/demo/accordion', label: 'Accordion' },
  { to: '/guide/demo/table', label: 'Table' },
  { to: '/guide/demo/switch', label: 'Switch' },
  { to: '/guide/demo/checkbox', label: 'Checkbox' },
  { to: '/guide/demo/radio', label: 'Radio' },
  { to: '/guide/demo/input', label: 'Input' },
]
</script>
<style scoped lang="scss">
@use '../assets/scss/components/sidebar' as *;
</style>
