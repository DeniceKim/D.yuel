<template>
  <div
    class="c-btn-group"
    :class="{ 'is-vertical': vertical, 'is-justified': justified }"
    role="group"
    :aria-label="ariaLabel || undefined"
  >
    <slot />
  </div>
</template>
<script setup lang="ts">
withDefaults(
  defineProps<{
    vertical?: boolean
    justified?: boolean
    ariaLabel?: string
  }>(),
  { vertical: false, justified: false }
)
</script>
<style scoped lang="scss">
@use '../assets/scss/components/button-group' as *;
</style>

