<template>
  <component
    :is="tagName"
    class="c-btn"
    :class="[
      sizeClass,
      `c-btn--type-${type}`,
      `c-btn--variant-${variant}`,
      { 'is-block': block, 'is-round': round, 'is-circle': circle, 'is-strong': strong, 'is-loading': loading, 'is-disabled': isDisabled }
    ]"
    :type="tagName === 'button' ? nativeType : undefined"
    :disabled="tagName === 'button' ? isDisabled : undefined"
    :href="tagName === 'a' ? href : undefined"
    :target="tagName === 'a' ? target : undefined"
    :rel="tagName === 'a' ? rel : undefined"
    :aria-disabled="tagName === 'a' ? String(isDisabled) : undefined"
    :aria-busy="loading || undefined"
    @click="onClick"
    @pointerdown="onPointerDown"
  >
    <span v-if="loading" class="c-btn__spinner" aria-hidden="true" />
    <span v-if="$slots.prefix" class="c-btn__prefix"><slot name="prefix" /></span>
    <span class="c-btn__label"><slot /></span>
    <span v-if="$slots.suffix" class="c-btn__suffix"><slot name="suffix" /></span>
    <span class="c-btn__ripples" aria-hidden="true"></span>
  </component>
</template>
<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    type?: 'default' | 'primary' | 'secondary' | 'info' | 'success' | 'warning' | 'error'
    variant?: 'solid' | 'ghost' | 'dashed' | 'text'
    size?: 'sm' | 'md' | 'lg'
    block?: boolean
    round?: boolean
    circle?: boolean
    strong?: boolean
    loading?: boolean
    disabled?: boolean
    nativeType?: 'button' | 'submit' | 'reset'
    href?: string
    target?: string
    rel?: string
  }>(),
  { type: 'default', variant: 'solid', size: 'md', block: false, round: false, circle: false, strong: false, loading: false, disabled: false, nativeType: 'button' }
)

const tagName = computed(() => (props.href ? 'a' : 'button'))
const isDisabled = computed(() => props.disabled || props.loading)
const sizeClass = computed(() => (props.size === 'sm' ? 'c-btn--sm' : props.size === 'lg' ? 'c-btn--lg' : 'c-btn--md'))

function onClick(e: Event) {
  if (isDisabled.value) {
    e.preventDefault()
    e.stopPropagation()
    return
  }
}

function onPointerDown(e: PointerEvent) {
  if (isDisabled.value) return
  const el = (e.currentTarget as HTMLElement) || null
  if (!el) return
  try {
    const startX = e.clientX
    const startY = e.clientY
    const rect = el.getBoundingClientRect()
    const radius = Math.max(rect.width, rect.height)
    const baseX = startX - rect.left - radius / 2
    const baseY = startY - rect.top - radius / 2
    const wrap = (el.querySelector('.c-btn__ripples') as HTMLElement) || el

    let cancelled = false
    const move = (ev: PointerEvent) => {
      const dx = Math.abs(ev.clientX - startX)
      const dy = Math.abs(ev.clientY - startY)
      if (dx > 8 || dy > 8) {
        cancelled = true
        cleanup()
      }
    }
    const spawn = (cls: string, extra?: number) => {
      const s = document.createElement('span')
      s.className = `c-btn__ripple ${cls}`.trim()
      const size = extra ? radius + extra : radius
      const x = baseX - (extra ? extra / 2 : 0)
      const y = baseY - (extra ? extra / 2 : 0)
      s.style.width = s.style.height = `${size}px`
      s.style.left = `${x}px`
      s.style.top = `${y}px`
      wrap.appendChild(s)
      const remove = () => { s.removeEventListener('animationend', remove); s.remove() }
      s.addEventListener('animationend', remove)
      setTimeout(() => { try { s.remove() } catch {} }, 1200)
    }
    const up = () => {
      cleanup()
      if (cancelled) return
      spawn('c-btn__ripple--core')
      spawn('c-btn__ripple--wave', Math.round(radius * 0.2))
    }
    const cleanup = () => {
      document.removeEventListener('pointermove', move)
      document.removeEventListener('pointerup', up)
      document.removeEventListener('pointercancel', up)
    }

    document.addEventListener('pointermove', move, { passive: true })
    document.addEventListener('pointerup', up, { passive: true })
    document.addEventListener('pointercancel', up, { passive: true })
  } catch {}
}
</script>
<style scoped lang="scss">
@use '../assets/scss/components/button' as *;
</style>
