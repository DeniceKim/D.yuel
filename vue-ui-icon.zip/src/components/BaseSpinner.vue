<template>
  <div class="c-spinner">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/spinner' as *;
</style>
