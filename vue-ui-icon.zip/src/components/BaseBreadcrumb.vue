<template>
  <div class="c-breadcrumb">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/breadcrumb' as *;
</style>
