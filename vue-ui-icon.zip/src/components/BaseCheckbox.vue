<template>
  <label class="c-checkbox" :class="classes">
    <input
      class="c-checkbox__input"
      type="checkbox"
      :id="id"
      :name="name"
      :checked="checked"
      :disabled="disabled"
      :aria-checked="checked"
      @change="onChange"
    />
    <span class="c-checkbox__control" aria-hidden="true" />
    <span v-if="$slots.default || label" class="c-checkbox__label"><slot>{{ label }}</slot></span>
  </label>
</template>
<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: boolean
    disabled?: boolean
    label?: string
    id?: string
    name?: string
    variant?: 'default' | 'box'
  }>(),
  { modelValue: false, disabled: false, variant: 'default' }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: boolean): void; (e: 'change', v: boolean): void }>()

const checked = computed(() => !!props.modelValue)
const classes = computed(() => ({ 'is-checked': checked.value, 'is-disabled': props.disabled, 'is-box': props.variant === 'box' }))

function onChange(e: Event) {
  if (props.disabled) return
  const next = (e.target as HTMLInputElement).checked
  emit('update:modelValue', next)
  emit('change', next)
}
</script>
<style scoped lang="scss">
@use '../assets/scss/components/checkbox' as *;
</style>
