<template>
  <nav class="c-tabbar" aria-label="하단 주메뉴">
    <router-link
      v-for="item in items"
      :key="item.to"
      :to="item.to"
      class="c-tabbar__item"
      :aria-label="item.label"
      :aria-current="isActive(item.to) ? 'page' : undefined"
      @pointerdown="onPress"
      @pointerup="onRelease"
      @pointercancel="onRelease"
      @pointerleave="onRelease"
    >
      <span class="c-tabbar__inner" aria-hidden="true">
        <span class="c-tabbar__icon-svg" v-html="getIconInline(item.icon)"></span>
        <span>{{ item.label }}</span>
      </span>
    </router-link>
  </nav>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { getInlineIcon as getIconInline } from '@/utils/inlineSvg' // 공통 유틸: SVG를 raw로 불러와 currentColor로 정규화하여 반환
const route = useRoute()

/** 탭 항목 정의 */
const items = [
  { to: '/',         label: '홈',     icon: 'icon-tabbar-home',    exact: true },
  { to: '/finance',  label: '금융',   icon: 'icon-tabbar-finance' },
  { to: '/product',  label: '상품',   icon: 'icon-tabbar-product' },
  { to: '/benefit',  label: '혜택',   icon: 'icon-tabbar-benefit' },
  { to: '/menu',     label: '전체메뉴', icon: 'icon-tabbar-menu'   },
]

/** 현재 경로 활성화 여부 */
function isActive(path: string) {
  return path === '/' ? route.path === '/' : route.path.startsWith(path)
}

// pressed visual state
function onPress(e: PointerEvent) {
  const el = e.currentTarget as HTMLElement | null
  if (!el) return
  el.classList.add('is-pressed')
}
function onRelease(e: PointerEvent) {
  const el = e.currentTarget as HTMLElement | null
  if (!el) return
  el.classList.remove('is-pressed')
}
</script>

<style scoped lang="scss">
@use '../assets/scss/components/tabbar' as *;
</style>
