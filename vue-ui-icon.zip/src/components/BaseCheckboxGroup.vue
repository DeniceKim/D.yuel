<template>
  <div class="c-checkbox-group" role="group" :aria-label="ariaLabel">
    <BaseCheckbox
      v-for="opt in options"
      :key="String(opt.value)"
      :model-value="modelSet.has(opt.value)"
      :disabled="disabled || !!opt.disabled"
      :variant="variant"
      @update:modelValue="(v) => onToggle(opt.value, v)"
    >
      <span>{{ opt.label }}</span>
    </BaseCheckbox>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import BaseCheckbox from './BaseCheckbox.vue'

type Key = string | number | boolean
interface Option { label: string; value: Key; disabled?: boolean }

const props = withDefaults(
  defineProps<{ options: Option[]; modelValue: Key[]; disabled?: boolean; variant?: 'default' | 'box'; ariaLabel?: string }>(),
  { options: () => [], modelValue: () => [], disabled: false, variant: 'default' }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: Key[]): void; (e: 'change', v: Key[]): void }>()

const modelSet = computed(() => new Set(props.modelValue))

function onToggle(val: Key, on: boolean) {
  const arr = new Set(modelSet.value)
  if (on) arr.add(val)
  else arr.delete(val)
  const next = Array.from(arr)
  emit('update:modelValue', next)
  emit('change', next)
}
</script>
<style scoped>
.c-checkbox-group { display: flex; gap: 12px; flex-wrap: wrap; }
</style>

