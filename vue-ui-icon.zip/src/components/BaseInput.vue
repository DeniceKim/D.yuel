<template>
  <label class="c-input" :class="classes">
    <span v-if="label" class="c-input__label">{{ label }}</span>
    <div class="c-input__wrapper">
      <span v-if="$slots.prefix" class="c-input__prefix"><slot name="prefix" /></span>
      <input
        ref="inputRef"
        class="c-input__field"
        :type="type"
        :value="modelValue"
        :placeholder="placeholder"
        :disabled="disabled"
        :readonly="readonly"
        :name="name"
        :id="id"
        :aria-invalid="invalid || undefined"
        :aria-describedby="describedby"
        @input="onInput"
        @change="onChange"
      />
      <button v-if="clearable && !!modelValue && !readonly && !disabled" class="c-input__clear" type="button" @click="onClear" aria-label="clear">×</button>
      <span v-if="$slots.suffix" class="c-input__suffix"><slot name="suffix" /></span>
    </div>
    <small v-if="hint" class="c-input__hint">{{ hint }}</small>
  </label>
</template>
<script setup lang="ts">
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: string | number | null
    type?: string
    placeholder?: string
    disabled?: boolean
    readonly?: boolean
    invalid?: boolean
    label?: string
    hint?: string
    id?: string
    name?: string
    describedby?: string
    size?: 'sm' | 'md' | 'lg'
    clearable?: boolean
  }>(),
  { type: 'text', disabled: false, readonly: false, invalid: false, size: 'md', clearable: false }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: any): void; (e: 'change', v: any): void; (e: 'clear'): void }>()

const inputRef = ref<HTMLInputElement | null>(null)
const classes = computed(() => ({ 'is-disabled': props.disabled, 'is-invalid': props.invalid, 'is-sm': props.size==='sm', 'is-lg': props.size==='lg' }))

function onInput(e: Event) {
  emit('update:modelValue', (e.target as HTMLInputElement).value)
}
function onChange(e: Event) {
  emit('change', (e.target as HTMLInputElement).value)
}
function onClear() {
  emit('update:modelValue', '')
  emit('clear')
  inputRef.value?.focus()
}

defineExpose({ focus: () => inputRef.value?.focus() })
</script>
<style scoped lang="scss">
@use '../assets/scss/components/input' as *;
</style>
