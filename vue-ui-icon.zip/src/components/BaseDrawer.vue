<template>
  <teleport to="body">
    <!-- Backdrop -->
    <div v-if="open" class="c-drawer__backdrop" @click="$emit('close')" />

    <!-- Drawer Panel -->
    <div
      ref="panel"
      :class="['c-drawer', sideClass, { 'is-open': open }]"
      role="dialog"
      aria-modal="true"
      :aria-labelledby="headingId"
      :style="drawerStyle"
      @keydown="onKeydown"
    >
      <header class="c-drawer__header">
        <h2 :id="headingId" class="c-drawer__title">
          <slot name="header">
            <strong>전체 메뉴</strong>
          </slot>
        </h2>
        <button class="c-btn c-btn--ghost" type="button" aria-label="닫기" @click="$emit('close')">
          ✕
        </button>
      </header>

      <div class="c-drawer__body">
        <slot />
      </div>
    </div>
  </teleport>
</template>

<script setup lang="ts">
import { computed, ref, watch, onBeforeUnmount } from 'vue'

interface Props {
  open: boolean
  side?: 'left' | 'right'
  /** ESC 키로 닫기 허용 */
  closeOnEsc?: boolean
  /** 패널 너비(px 또는 CSS width) */
  width?: number | string
}
const props = withDefaults(defineProps<Props>(), {
  side: 'right',
  closeOnEsc: true,
})
const emit = defineEmits<{
  (e: 'close'): void
}>()

const sideClass = computed(() => (props.side === 'right' ? 'is-right' : 'is-left'))

/** 접근성: 고유 heading id */
const headingId = `drawer-title-${Math.random().toString(36).slice(2, 8)}`

/** DOM refs */
const panel = ref<HTMLElement | null>(null)

/** CSS var style for width control */
const drawerStyle = computed(() => {
  if (props.width == null) return undefined
  const v = typeof props.width === 'number' ? `${props.width}px` : props.width
  return { '--drawer-width': v } as any
})

/** 이전 포커스 노드 저장 (닫을 때 포커스 복귀) */
let previousActive: Element | null = null

/** 배경(#app) SR/탭 제외 */
function setAppHidden(hidden: boolean) {
  const app = document.querySelector('#app') as HTMLElement | null
  if (!app) return
  if (hidden) {
    app.setAttribute('aria-hidden', 'true')
    app.setAttribute('tabindex', '-1')
    // inert 지원 브라우저에서 인터랙션 차단 (폴리필 없으면 무시됨)
    try {
      ;(app as any).inert = true
    } catch {
      app.setAttribute('inert', '')
    }
  } else {
    app.removeAttribute('aria-hidden')
    app.removeAttribute('tabindex')
    try {
      ;(app as any).inert = false
    } catch {
      app.removeAttribute('inert')
    }
  }
}

/** 바디 스크롤 잠금 (중첩 안전) */
function lockScroll() {
  document.body.classList.add('is-modal-open')
}
function unlockScroll() {
  document.body.classList.remove('is-modal-open')
}

/** 포커스 가능한 요소 수집 */
function getFocusable(container: HTMLElement) {
  const selectors = [
    'a[href]',
    'area[href]',
    'button:not([disabled])',
    'input:not([disabled]):not([type="hidden"])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    'summary',
    '[tabindex]:not([tabindex="-1"])',
    '[contenteditable="true"]',
  ].join(',')
  const nodes = Array.from(container.querySelectorAll<HTMLElement>(selectors))
  return nodes.filter((el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length))
}

/** 드로어 오픈 시 포커스 진입 */
function focusFirst() {
  if (!panel.value) return
  const focusables = getFocusable(panel.value)
  ;(focusables[0] ?? panel.value).focus({ preventScroll: true })
}

/** ESC/Tab 트랩 */
function onKeydown(e: KeyboardEvent) {
  if (!panel.value) return
  if (e.key === 'Escape' && props.closeOnEsc) {
    e.stopPropagation()
    e.preventDefault()
    emit('close')
    return
  }
  if (e.key !== 'Tab') return

  const focusables = getFocusable(panel.value)
  if (focusables.length === 0) {
    // 포커스 트랩: 패널에 포커스 유지
    e.preventDefault()
    panel.value.focus({ preventScroll: true })
    return
  }
  const first = focusables[0]
  const last = focusables[focusables.length - 1]
  const active = document.activeElement as HTMLElement | null

  if (!e.shiftKey && active === last) {
    e.preventDefault()
    first.focus()
  } else if (e.shiftKey && active === first) {
    e.preventDefault()
    last.focus()
  }
}

/** 상태 감시 */
watch(
  () => props.open,
  (isOpen) => {
    if (isOpen) {
      previousActive = document.activeElement
      setAppHidden(true)
      lockScroll()
      // 다음 프레임에 포커스 이동(레이아웃 준비 후)
      requestAnimationFrame(focusFirst)
      // 패널 자체에도 tabindex 부여해 포커스 가능한 컨테이너 보장
      panel.value?.setAttribute('tabindex', '-1')
    } else {
      setAppHidden(false)
      unlockScroll()
      // 포커스 복귀
      if (previousActive instanceof HTMLElement) {
        previousActive.focus({ preventScroll: true })
      }
      panel.value?.removeAttribute('tabindex')
    }
  },
  { immediate: true }
)

/** 안전 정리 */
onBeforeUnmount(() => {
  setAppHidden(false)
  unlockScroll()
})
</script>

<style scoped lang="scss">
@use '../assets/scss/components/drawer' as *;
</style>
