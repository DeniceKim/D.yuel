<template>
  <div class="c-progressbar">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/progressbar' as *;
</style>
