<template>
  <div class="c-table" :data-sticky-header="stickyHeader" :class="containerClasses">
    <div class="c-table__viewport" :style="viewportStyle" ref="viewportRef">
      <table class="c-table__inner">
        <colgroup>
          <col
            v-for="col in normalizedColumns"
            :key="String(col.key)"
            :data-col-key="String(col.key)"
            :style="colStyle(col)"
          />
        </colgroup>
        <caption v-if="caption" class="visually-hidden">{{ caption }}</caption>
        <thead>
          <tr>
            <th
              v-for="(col, ci) in normalizedColumns"
              :key="String(col.key)"
              scope="col"
              :class="thClass(ci, col)"
              :data-col-key="String(col.key)"
              :style="thStyle(ci, col)"
              :aria-sort="sortKey === col.key ? (sortOrder === 'asc' ? 'ascending' : 'descending') : 'none'"
              @click="headerClick(col)"
              @keydown.enter.prevent="headerClick(col)"
              @keydown.space.prevent="headerClick(col)"
              :tabindex="col.sortable ? 0 : undefined"
            >
              <span class="c-table__th-label">
                <slot name="header" :column="col">{{ col.header }}</slot>
              </span>
              <span v-if="col.sortable" class="c-table__sort" :data-order="sortIndicatorOrder(col)" aria-hidden="true"></span>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, ri) in sortedRows" :key="getRowKey(row, ri)">
            <td
              v-for="(col, ci) in normalizedColumns"
              :key="String(col.key)"
              :class="tdClass(ci, col)"
              :data-col-key="String(col.key)"
              :style="tdStyle(ci, col)"
            >
              <slot :name="`cell-${String(col.key)}`" :row="row" :column="col" :value="row[col.key]">
                {{ formatCell(row[col.key], col) }}
              </slot>
            </td>
          </tr>
          <tr v-if="!rows || rows.length === 0">
            <td class="c-table__empty" :colspan="normalizedColumns.length">
              <slot name="empty">데이터가 없습니다.</slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  
</template>
<script setup lang="ts">
import { computed, onMounted, onBeforeUnmount, ref, nextTick } from 'vue'

type Key = string | number

interface ColumnDef {
  key: Key
  header?: string
  width?: number | string // px number or css width
  align?: 'left' | 'center' | 'right'
  sticky?: boolean
  sortable?: boolean
  // optional accessor for sorting (default: row[key])
  sortAccessor?: (row: any) => any
  formatter?: (value: any, row: any) => any
}

const props = withDefaults(
  defineProps<{
    columns: ColumnDef[]
    rows: any[]
    caption?: string
    // 스크롤 높이 지정 시 thead 고정
    maxHeight?: number | string
    stickyHeader?: boolean
    // 첫번째 열 고정
    stickyFirstColumn?: boolean
    // 추가 고정 열 (key 배열)
    stickyColumns?: Key[]
    // 기본 열 너비(px) - width 미지정 시 적용(고정 열 left 계산용)
    defaultColWidth?: number
    // 행 key 필드명 또는 함수
    rowKey?: string | ((row: any, index: number) => Key)
    // 정렬 활성화(전역 기본). 각 컬럼별로 sortable 지정 가능
    sortable?: boolean
    // 초기 정렬 키/순서
    defaultSortKey?: Key | null
    defaultSortOrder?: 'asc' | 'desc'
  }>(),
  {
    columns: () => [],
    rows: () => [],
    stickyHeader: true,
    stickyFirstColumn: false,
    stickyColumns: () => [],
    defaultColWidth: 160,
    sortable: false,
    defaultSortKey: null,
    defaultSortOrder: 'asc',
  }
)

const viewportStyle = computed(() => {
  if (!props.maxHeight) return undefined
  const v = typeof props.maxHeight === 'number' ? `${props.maxHeight}px` : props.maxHeight
  // expose height only via CSS var; actual rule lives in SCSS
  return { '--table-max-height': v } as any
})

// scroll-aware dim effects
const viewportRef = ref<HTMLElement | null>(null)
const xLeft = ref(false)
const xRight = ref(false)
const yTop = ref(false)

function updateScrollState() {
  const el = viewportRef.value
  if (!el) return
  const { scrollLeft, scrollTop, clientWidth, clientHeight, scrollWidth, scrollHeight } = el
  xLeft.value = scrollLeft > 0
  xRight.value = Math.ceil(scrollLeft + clientWidth) < scrollWidth
  yTop.value = scrollTop > 0
}

onMounted(() => {
  const el = viewportRef.value
  if (!el) return
  const handler = () => updateScrollState()
  el.addEventListener('scroll', handler, { passive: true })
  // initial measure
  nextTick(updateScrollState)
  // save for cleanup
  ;(el as any)._tableScrollHandler = handler
})

onBeforeUnmount(() => {
  const el = viewportRef.value as any
  if (el && el._tableScrollHandler) {
    el.removeEventListener('scroll', el._tableScrollHandler)
    delete el._tableScrollHandler
  }
})

const containerClasses = computed(() => ({
  'is-x-left': xLeft.value,
  'is-x-right': xRight.value,
  'is-y': yTop.value,
}))

// sorting state
const sortKey = ref<Key | null>(props.defaultSortKey)
const sortOrder = ref<'asc' | 'desc'>(props.defaultSortOrder)

const stickyKeySet = computed(() => {
  const set = new Set<Key>()
  if (props.stickyFirstColumn && props.columns[0]) set.add(props.columns[0].key)
  for (const k of props.stickyColumns) set.add(k)
  for (const c of props.columns) if (c.sticky) set.add(c.key)
  return set
})

// width px number for left offset calc
function widthToPxNum(w: number | string | undefined): number | undefined {
  if (w == null) return undefined
  if (typeof w === 'number') return w
  const m = String(w).match(/^(\d+)(px)?$/)
  if (m) return Number(m[1])
  return undefined
}

const normalizedColumns = computed(() => {
  return props.columns.map((c) => ({
    key: c.key,
    header: c.header ?? String(c.key),
    width: c.width,
    align: c.align ?? 'left',
    sticky: c.sticky ?? stickyKeySet.value.has(c.key),
    sortable: c.sortable ?? props.sortable ?? false,
    sortAccessor: c.sortAccessor,
    formatter: c.formatter,
  }))
})

// precompute sticky left offsets
const stickyLeftByKey = computed<Record<string, string>>(() => {
  const res: Record<string, string> = {}
  let acc = 0
  for (const col of normalizedColumns.value) {
    if (col.sticky) {
      res[String(col.key)] = acc + 'px'
      const w = widthToPxNum(col.width) ?? props.defaultColWidth
      acc += w
    } else {
      // if not sticky, and width provided but not sticky, do not change acc
    }
  }
  return res
})

function cssWidth(col: ColumnDef) {
  if (col.width == null) return undefined
  return typeof col.width === 'number' ? `${col.width}px` : col.width
}

function thClass(ci: number, col: ColumnDef) {
  return [
    'c-table__th',
    col.align ? `is-${col.align}` : '',
    stickyKeySet.value.has(col.key) ? 'is-sticky' : '',
    col.sortable ? 'is-sortable' : '',
    sortKey.value === col.key ? 'is-sorted' : '',
    sortKey.value === col.key ? `is-sorted-${sortOrder.value}` : '',
  ]
}
function tdClass(ci: number, col: ColumnDef) {
  return [
    'c-table__td',
    col.align ? `is-${col.align}` : '',
    stickyKeySet.value.has(col.key) ? 'is-sticky' : '',
  ]
}
function thStyle(ci: number, col: ColumnDef) {
  const style: Record<string, string> = {}
  const w = cssWidth(col)
  if (w) style.width = w
  if (stickyKeySet.value.has(col.key)) style.left = stickyLeftByKey.value[String(col.key)]
  return style
}
function tdStyle(ci: number, col: ColumnDef) {
  const style: Record<string, string> = {}
  if (stickyKeySet.value.has(col.key)) style.left = stickyLeftByKey.value[String(col.key)]
  return style
}

function colStyle(col: ColumnDef) {
  const style: Record<string, string> = {}
  const w = cssWidth(col)
  if (w) style.width = w
  return style
}

function getRowKey(row: any, index: number): Key {
  if (!props.rowKey) return index
  if (typeof props.rowKey === 'string') return row[props.rowKey]
  return props.rowKey(row, index)
}

function formatCell(value: any, col: ColumnDef) {
  return col.formatter ? col.formatter(value, value) : value
}

function headerClick(col: any) {
  if (!col.sortable) return
  const key = col.key
  if (sortKey.value === key) {
    sortOrder.value = sortOrder.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortKey.value = key
    sortOrder.value = 'asc'
  }
}

function sortIndicatorOrder(col: any) {
  if (sortKey.value !== col.key) return 'none'
  return sortOrder.value
}

function compare(a: any, b: any): number {
  if (a == null && b == null) return 0
  if (a == null) return -1
  if (b == null) return 1
  if (typeof a === 'number' && typeof b === 'number') return a - b
  const sa = String(a).toLowerCase()
  const sb = String(b).toLowerCase()
  return sa.localeCompare(sb)
}

const sortedRows = computed(() => {
  if (!sortKey.value) return props.rows
  const key = sortKey.value
  const col = normalizedColumns.value.find((c) => c.key === key)
  if (!col || col.sortable !== true) return props.rows
  const acc = col.sortAccessor
    ? (row: any) => col.sortAccessor!(row)
    : (row: any) => (row as any)[key as any]
  const arr = props.rows.slice()
  arr.sort((ra, rb) => compare(acc(ra), acc(rb)))
  if (sortOrder.value === 'desc') arr.reverse()
  return arr
})
</script>
<style scoped lang="scss">
@use '../assets/scss/components/table' as *;
.visually-hidden { position: absolute; width: 1px; height: 1px; margin: -1px; padding: 0; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0; }
</style>
