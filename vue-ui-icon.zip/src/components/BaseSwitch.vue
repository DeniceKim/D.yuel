<template>
  <label class="c-switch" :class="classes">
    <input
      ref="inputRef"
      class="c-switch__input"
      type="checkbox"
      role="switch"
      :id="id"
      :name="name"
      :checked="isOn"
      :disabled="disabled"
      :aria-checked="isOn"
      @change="onNativeChange"
      @keydown.space.prevent="toggle"
      @keydown.enter.prevent="toggle"
    />
    <span class="c-switch__track" aria-hidden="true">
      <span class="c-switch__thumb" />
    </span>
    <span v-if="$slots.default || label" class="c-switch__label">
      <slot>{{ label }}</slot>
    </span>
  </label>
</template>
<script setup lang="ts">
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: boolean
    disabled?: boolean
    label?: string
    size?: 'sm' | 'md' | 'lg'
    id?: string
    name?: string
  }>(),
  {
    modelValue: false,
    disabled: false,
    size: 'md',
  }
)

const emit = defineEmits<{
  (e: 'update:modelValue', v: boolean): void
  (e: 'change', v: boolean): void
}>()

const inputRef = ref<HTMLInputElement | null>(null)
const isOn = computed(() => !!props.modelValue)
const classes = computed(() => ({
  'is-on': isOn.value,
  'is-disabled': props.disabled,
  'is-sm': props.size === 'sm',
  'is-lg': props.size === 'lg',
}))

function toggle() {
  if (props.disabled) return
  const next = !isOn.value
  emit('update:modelValue', next)
  emit('change', next)
}

function onNativeChange(e: Event) {
  if (props.disabled) return
  const target = e.target as HTMLInputElement
  const next = !!target.checked
  emit('update:modelValue', next)
  emit('change', next)
}

defineExpose({ focus: () => inputRef.value?.focus() })
</script>
<style scoped lang="scss">
@use '../assets/scss/components/switch' as *;
</style>
