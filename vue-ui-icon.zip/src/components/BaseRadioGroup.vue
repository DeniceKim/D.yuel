<template>
  <div class="c-radio-group" role="radiogroup" :aria-label="ariaLabel">
    <BaseRadio
      v-for="opt in options"
      :key="String(opt.value)"
      :model-value="modelValue"
      :value="opt.value"
      :disabled="disabled || !!opt.disabled"
      :variant="variant"
      :name="name"
      @update:modelValue="onSelect"
    >
      <span>{{ opt.label }}</span>
    </BaseRadio>
  </div>
</template>
<script setup lang="ts">
import BaseRadio from './BaseRadio.vue'

type Key = string | number | boolean
interface Option { label: string; value: Key; disabled?: boolean }

const props = withDefaults(
  defineProps<{ options: Option[]; modelValue: Key | null; disabled?: boolean; variant?: 'default' | 'box'; name?: string; ariaLabel?: string }>(),
  { options: () => [], disabled: false, variant: 'default' }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: Key | null): void; (e: 'change', v: Key | null): void }>()

function onSelect(v: Key) {
  emit('update:modelValue', v)
  emit('change', v)
}
</script>
<style scoped>
.c-radio-group { display: flex; gap: 12px; flex-wrap: wrap; }
</style>

