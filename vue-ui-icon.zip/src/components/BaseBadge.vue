<template>
  <div class="c-badge">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/badge' as *;
</style>
