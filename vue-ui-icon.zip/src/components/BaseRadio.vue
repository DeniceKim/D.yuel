<template>
  <label class="c-radio" :class="classes">
    <input
      class="c-radio__input"
      type="radio"
      :id="id"
      :name="name"
      :checked="checked"
      :disabled="disabled"
      :aria-checked="checked"
      @change="onChange"
    />
    <span class="c-radio__control" aria-hidden="true" />
    <span v-if="$slots.default || label" class="c-radio__label"><slot>{{ label }}</slot></span>
  </label>
</template>
<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: any
    value?: any
    disabled?: boolean
    label?: string
    id?: string
    name?: string
    variant?: 'default' | 'box'
  }>(),
  { disabled: false, variant: 'default' }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: any): void; (e: 'change', v: any): void }>()

const checked = computed(() => props.modelValue === props.value)
const classes = computed(() => ({ 'is-checked': checked.value, 'is-disabled': props.disabled, 'is-box': props.variant === 'box' }))

function onChange() {
  if (props.disabled) return
  emit('update:modelValue', props.value)
  emit('change', props.value)
}
</script>
<style scoped lang="scss">
@use '../assets/scss/components/radio' as *;
</style>
