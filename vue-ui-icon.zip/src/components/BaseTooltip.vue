<template>
  <div class="c-tooltip">
    <slot />
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/tooltip' as *;
</style>
