<template>
  <div class="c-tabs" :class="[variantClass, placementClass]">
    <div v-if="scrollable" class="c-tabs__wrap" :data-can-prev="String(canPrev)" :data-can-next="String(canNext)" :data-has-buttons="String(!!navButtons)">
      <button v-if="navButtons" class="c-tabs__scroll-btn is-left" type="button" :disabled="!canPrev" aria-label="이전 탭" @click="goPrevTab">‹</button>
      <div class="c-tabs__scroll" ref="scrollRef">
        <div class="c-tabs__nav" :class="navClass" role="tablist" ref="navRef" :style="indicatorVars">
          <span v-if="props.variant==='line-move'" class="c-tabs__indicator" aria-hidden="true"></span>
          <span v-if="props.variant==='segment-move'" class="c-tabs__highlight" aria-hidden="true"></span>
          <button
            v-for="it in items"
            :key="String(it.key)"
            class="c-tabs__btn"
            role="tab"
            type="button"
            :aria-selected="String(activeKey === it.key)"
            :aria-controls="panelId(it.key)"
            :id="tabId(it.key)"
            :tabindex="activeKey === it.key ? 0 : -1"
            :disabled="!!it.disabled"
            :ref="(el:any)=> setBtnRef(el, it.key)"
            @click="onSelect(it.key)"
          >
            <slot :name="`title-${String(it.key)}`" :item="it">{{ it.title }}</slot>
          </button>
        </div>
      </div>
      <button v-if="navButtons" class="c-tabs__scroll-btn is-right" type="button" :disabled="!canNext" aria-label="다음 탭" @click="goNextTab">›</button>
    </div>
    <div v-else class="c-tabs__nav" :class="navClass" role="tablist" ref="navRef" :style="indicatorVars">
      <span v-if="props.variant==='line-move'" class="c-tabs__indicator" aria-hidden="true"></span>
      <span v-if="props.variant==='segment-move'" class="c-tabs__highlight" aria-hidden="true"></span>
      <button
        v-for="it in items"
        :key="String(it.key)"
        class="c-tabs__btn"
        role="tab"
        type="button"
        :aria-selected="String(activeKey === it.key)"
        :aria-controls="panelId(it.key)"
        :id="tabId(it.key)"
        :tabindex="activeKey === it.key ? 0 : -1"
        :disabled="!!it.disabled"
        :ref="(el:any)=> setBtnRef(el, it.key)"
        @click="onSelect(it.key)"
      >
        <slot :name="`title-${String(it.key)}`" :item="it">{{ it.title }}</slot>
      </button>
    </div>
    <div class="c-tabs__panels">
      <section
        v-for="it in items"
        :key="String(it.key)"
        class="c-tabs__panel"
        role="tabpanel"
        :id="panelId(it.key)"
        :aria-labelledby="tabId(it.key)"
        :aria-hidden="String(activeKey !== it.key)"
      >
        <slot :name="`panel-${String(it.key)}`" :item="it">
          <div style="color: var(--text-secondary, #475467); font-size: 0.875rem">No content</div>
        </slot>
      </section>
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed, ref, watch, onMounted, onBeforeUnmount } from 'vue'

type Key = string | number
interface TabItem { key: Key; title: string; disabled?: boolean }

const props = withDefaults(
  defineProps<{
    items: TabItem[]
    modelValue?: Key | null
    variant?: 'underline' | 'pills' | 'bar' | 'card' | 'segment' | 'line-move' | 'segment-move'
    justified?: boolean
    align?: 'start' | 'center' | 'end'
    placement?: 'top' | 'bottom'
    scrollable?: boolean
    centerActive?: boolean
    navButtons?: boolean
  }>(),
  { items: () => [], modelValue: null, variant: 'underline', justified: false, align: 'start', placement: 'top', scrollable: false, centerActive: true, navButtons: true }
)
const emit = defineEmits<{ (e: 'update:modelValue', v: Key): void; (e: 'change', v: Key): void }>()

// controlled vs uncontrolled
const isControlled = computed(() => props.modelValue != null)
const innerActive = ref<Key | null>(props.modelValue ?? (props.items[0]?.key ?? null) as any)

// keep inner in sync if parent controls value
watch(
  () => props.modelValue,
  (v) => { if (v != null) innerActive.value = v },
)
// update inner when items change (ensure valid key)
watch(
  () => props.items,
  (list) => {
    if (isControlled.value) return
    const first = list[0]?.key
    if (first != null && innerActive.value == null) innerActive.value = first
  },
  { deep: true }
)

const activeKey = computed<Key>(() => (props.modelValue != null ? (props.modelValue as Key) : ((innerActive.value ?? props.items[0]?.key) as Key)))

function onSelect(k: Key) {
  if (k === activeKey.value) return
  emit('update:modelValue', k)
  emit('change', k)
  if (!isControlled.value) innerActive.value = k
}

function panelId(k: Key) { return `tabs-panel-${String(k)}` }
function tabId(k: Key) { return `tabs-tab-${String(k)}` }

const variantClass = computed(() =>
  props.variant === 'pills' ? 'c-tabs--pills'
  : props.variant === 'bar' ? 'c-tabs--bar'
  : props.variant === 'card' ? 'c-tabs--card'
  : props.variant === 'segment' ? 'c-tabs--segment'
  : props.variant === 'line-move' ? 'c-tabs--line-move'
  : props.variant === 'segment-move' ? 'c-tabs--segment-move'
  : 'c-tabs--underline'
)
const placementClass = computed(() => props.placement === 'bottom' ? 'is-bottom' : '')
const navClass = computed(() => ({
  'is-justified': !!props.justified,
  'is-center': props.align === 'center',
  'is-end': props.align === 'end',
}))

// Moving indicator measurements
const navRef = ref<HTMLElement | null>(null)
const scrollRef = ref<HTMLElement | null>(null)
// non-reactive map to avoid recursive updates during render
const btnRefs: Record<string, HTMLElement | null> = {}
function setBtnRef(el: HTMLElement | null, key: Key) {
  btnRefs[String(key)] = el
}
const indicatorVars = ref<Record<string, string>>({ '--indicator-x': '0px', '--indicator-w': '0px' })
function updateIndicator() {
  const nav = navRef.value
  const current = btnRefs[String(activeKey.value)]
  if (!nav || !current) return
  const nr = nav.getBoundingClientRect()
  const br = current.getBoundingClientRect()
  const x = br.left - nr.left
  const w = br.width
  indicatorVars.value = {
    '--indicator-x': `${Math.max(0, Math.round(x))}px`,
    '--indicator-w': `${Math.max(0, Math.round(w))}px`,
  }
}
// update indicator when active key or items change
// handled below together with centering
onMounted(() => {
  updateIndicator()
  window.addEventListener('resize', updateIndicator, { passive: true })
})
onBeforeUnmount(() => {
  window.removeEventListener('resize', updateIndicator)
})

// Center active tab when scrollable
function centerActiveIfNeeded() {
  if (!props.scrollable || !props.centerActive) return
  const vp = scrollRef.value
  const nav = navRef.value
  const btn = btnRefs[String(activeKey.value)]
  if (!vp || !nav || !btn) return
  const vpRect = vp.getBoundingClientRect()
  const btnRect = btn.getBoundingClientRect()
  const currentLeft = vp.scrollLeft
  const btnCenterX = (btnRect.left + btnRect.width / 2) - vpRect.left
  const targetLeft = currentLeft + (btnCenterX - vpRect.width / 2)
  const maxScroll = nav.scrollWidth - vp.clientWidth
  const next = Math.max(0, Math.min(maxScroll, Math.round(targetLeft)))
  vp.scrollTo({ left: next, behavior: 'smooth' })
}
watch(activeKey, () => { queueMicrotask(() => { updateIndicator(); centerActiveIfNeeded() }) })
watch(() => props.items, () => { queueMicrotask(centerActiveIfNeeded) }, { deep: true })
onMounted(() => { centerActiveIfNeeded() })

// Prev/Next logic (skip disabled)
const activeIndex = computed(() => props.items.findIndex((it) => it.key === activeKey.value))
function findPrevIndex(from: number): number {
  for (let i = from - 1; i >= 0; i--) if (!props.items[i]?.disabled) return i
  return -1
}
function findNextIndex(from: number): number {
  for (let i = from + 1; i < props.items.length; i++) if (!props.items[i]?.disabled) return i
  return -1
}
const canPrev = computed(() => findPrevIndex(activeIndex.value) !== -1)
const canNext = computed(() => findNextIndex(activeIndex.value) !== -1)
function goPrevTab() {
  const idx = findPrevIndex(activeIndex.value)
  if (idx !== -1) onSelect(props.items[idx].key)
}
function goNextTab() {
  const idx = findNextIndex(activeIndex.value)
  if (idx !== -1) onSelect(props.items[idx].key)
}
</script>
<style scoped lang="scss">
@use '../assets/scss/components/tabs' as *;
</style>
