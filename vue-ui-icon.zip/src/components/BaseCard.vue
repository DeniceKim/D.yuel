<template>
  <div class="c-card">
    <div class="c-card__header">
      <slot name="header" />
    </div>
    <div class="c-card__body">
      <slot />
    </div>
    <div class="c-card__footer">
      <slot name="footer" />
    </div>
  </div>
</template>
<style scoped lang="scss">
@use '../assets/scss/components/card' as *;
</style>
