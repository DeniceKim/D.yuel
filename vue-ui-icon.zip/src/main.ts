// src/main.ts
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import '@/assets/scss/index.scss'

import { initTheme } from '@/utils/theme'
import {
  detectEnvironment,
  initializeScrollEvents,
  // (선택) 필요 시 활성화
  // initializeTextareaFocusHandler,
  // scrollToTopAction,
} from '@/utils/commonUtils'

// ① 테마 초기화
initTheme()
// ② 환경 감지 (html class 추가)
detectEnvironment()

// ③ 스크롤 이벤트 초기화
//    반환된 cleanup을 HMR 시점에 해제하여 중복 리스너 방지
const cleanupScroll = initializeScrollEvents({
  // headerSelector: '.l-header',        // <- 커스텀 헤더 선택자 필요 시 지정
  // headerShadowClass: 'is-shadow',     // <- 커스텀 그림자 클래스 필요 시 지정
})

// (선택) textarea 포커스 시 상단 이동(iOS 키패드 대응)
// const cleanupTextarea = initializeTextareaFocusHandler(20, '.l-header')

// (선택) Top 버튼 및 Floating 버튼 관리
// scrollToTopAction()

// ④ 앱 마운트
createApp(App).use(createPinia()).use(router).mount('#app')

// --- 개발(HMR) 환경에서 이벤트 중복 방지 정리 ---
// Vite HMR로 모듈이 교체될 때 리스너 해제
if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    cleanupScroll?.()
    // cleanupTextarea?.()
  })
}
