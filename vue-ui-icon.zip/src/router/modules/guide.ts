import type { RouteRecordRaw } from 'vue-router'
import { demoChildRoutes } from './demo'

export const guideRoutes: RouteRecordRaw = {
  path: '/guide',
  component: () => import('@/layouts/GuideLayout.vue'),
  children: [
    {
      path: '',
      component: () => import('@/pages/guide/IndexPage.vue'),
      name: 'guide',
      meta: { title: '가이드' },
    },
    ...demoChildRoutes,
  ],
}
