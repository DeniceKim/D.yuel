import type { RouteRecordRaw } from 'vue-router'
export const errorRoutes: RouteRecordRaw = {
  path: '/:pathMatch(.*)*',
  component: () => import('@/pages/ErrorPage.vue'),
  name: 'not-found',
  meta: { title: '404' },
}
