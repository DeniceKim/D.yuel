import type { RouteRecordRaw } from 'vue-router'

export const mainRoutes: RouteRecordRaw = {
  path: '/',
  component: () => import('@/layouts/MainLayout.vue'),
  children: [
    {
      path: '',
      component: () => import('@/pages/main/IndexPage.vue'),
      name: 'home',
      meta: { title: '홈' },
    },
    {
      path: '',
      component: () => import('@/pages/finance/IndexPage.vue'),
      name: 'finance',
      meta: { title: '금융' },
    },
    {
      path: '상품',
      component: () => import('@/pages/product/IndexPage.vue'),
      name: 'product',
      meta: { title: '상품' },
    },
    {
      path: '혜택',
      component: () => import('@/pages/benefit/IndexPage.vue'),
      name: 'benefit',
      meta: { title: '혜택' },
    },
    {
      path: '전체메뉴',
      component: () => import('@/pages/menu/IndexPage.vue'),
      name: 'menu',
      meta: { title: '전체메뉴' },
    },
  ],
}
