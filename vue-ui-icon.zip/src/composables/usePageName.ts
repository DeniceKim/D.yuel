// 현재 경로 → "폴더-파일" 문자열로 변환
import { computed } from 'vue'
import { useRoute } from 'vue-router'

function folderFileFromPath(pathname: string) {
  const segs = pathname.split('/').filter(Boolean)
  if (segs.length >= 2) {
    const file = segs[segs.length - 1]
    const folder = segs[segs.length - 2]
    return `${folder}-${file}`
  }
  return segs[0] ?? 'index'
}

export function usePageName() {
  const route = useRoute()
  const pageName = computed(() => {
    // vite-plugin-pages 확장: meta.fileName이 있으면 우선
    const metaName = route.meta?.fileName as string | undefined
    return metaName && metaName.length > 0
      ? metaName
      : folderFileFromPath(route.path)
  })
  return { pageName }
}
