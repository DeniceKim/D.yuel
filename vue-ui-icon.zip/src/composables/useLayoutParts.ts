import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useDrawer } from '@/composables/useDrawer'
import { usePageName } from '@/composables/usePageName'

export function useLayoutParts() {
  const route = useRoute()
  const { pageName } = usePageName()

  // meta 기반 표시 여부 (기본 true)
  const showNavbar = computed(() => (route.meta?.navbar ?? true) as boolean)
  const showTabbar = computed(() => (route.meta?.tabbar ?? true) as boolean)
  const showDrawer = computed(() => (route.meta?.drawer ?? true) as boolean)

  // data-layout 값 (기본 'main')
  const layoutId = computed(() => (route.meta?.layoutId as string) || 'main')

  // 드로어 제어 (Drawer 미사용이면 no-op)
  const { drawerOpen, openMenu: rawOpenMenu, closeMenu, goBack } = useDrawer('#app')
  const openMenu = () => { if (showDrawer.value) rawOpenMenu() }

  return {
    showNavbar, showTabbar, showDrawer,
    layoutId, pageName,
    drawerOpen, openMenu, closeMenu, goBack,
  }
}
