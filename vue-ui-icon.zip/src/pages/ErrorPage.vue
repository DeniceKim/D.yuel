<route lang="yaml">
meta:
  title: 404
  layout: PageLayout # 필요 시 다른 레이아웃으로 교체 가능
</route>

<template>
  <h1>페이지를 찾을 수 없습니다</h1>
  <p>요청하신 주소가 올바르지 않거나, 이동되었을 수 있습니다.</p>
  <router-link to="/" class="c-btn">홈으로 이동</router-link>
</template>
