<route lang="yaml">
meta:
  title: 소개
  layout: PageLayout
</route>

<template>
  <h2>소개</h2>
</template>
