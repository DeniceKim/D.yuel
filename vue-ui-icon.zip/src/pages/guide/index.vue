<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <section class="top__noti gap__x">
    <h2>가이드 Main</h2>
    <p>좌측 사이드바 또는 아래 링크에서 컴포넌트 데모를 확인하세요.</p>
    <router-link to="/guide/demo/button">Demo 버튼</router-link>
  </section>
</template>
