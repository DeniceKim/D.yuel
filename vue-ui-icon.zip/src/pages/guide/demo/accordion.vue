<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Accordion</h2>

  <h3>1) 기본: 단일 열림 + 첫 항목 자동 열기</h3>
  <BaseAccordion ref="accRef" :items="simpleItems" open-first @change="onChange('basic', $event)" />
  <div style="margin: 8px 0; display: flex; gap: 8px; flex-wrap: wrap">
    <button class="c-btn c-btn__primary" @click="accRef?.open(2)">open(2)</button>
    <button class="c-btn c-btn__primary" @click="accRef?.close(2)">close(2)</button>
    <button class="c-btn c-btn__primary" @click="accRef?.toggle(3)">toggle(3)</button>
    <button class="c-btn c-btn__primary" @click="logOpen()">getOpenIds()</button>
  </div>
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>&lt;BaseAccordion :items="items" open-first /&gt;</code> · 프로그래매틱 제어: <code>ref.open(id)</code>, <code>ref.close(id)</code>, <code>ref.toggle(id)</code>, <code>ref.getOpenIds()</code>
  </p>

  <hr />

  <h3>2) 다중 열림 + 초기 지정 ID 열기</h3>
  <BaseAccordion
    :items="simpleItems"
    multiple
    :initial-open-ids="[2, 3]"
    @change="onChange('multi', $event)"
  />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>multiple</code> 사용 시 한 레벨 내 여러 항목 동시 열림 · 처음 열 항목은 <code>:initial-open-ids="[... ]"</code>
  </p>

  <hr />

  <h3>3) 중첩(무한 뎁스) + 모든 레벨 첫 항목 열기</h3>
  <BaseAccordion :items="nestedItems" open-first-all-levels @change="onChange('nested', $event)" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>open-first-all-levels</code>로 모든 레벨에서 첫 항목 자동 열기
  </p>

  <hr />

  <h3>4) 커스텀 슬롯: header/body</h3>
  <BaseAccordion :items="nestedItems" :initial-open-ids="[10]" @change="onChange('slots', $event)">
    <template #header="{ item, isOpen }">
      <strong>{{ isOpen ? '▼' : '▶' }} {{ item.label }}</strong>
    </template>
    <template #default="{ item }">
      <div style="padding: 6px 0">내용: {{ item.content || '—' }}</div>
    </template>
  </BaseAccordion>
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>#header="{ item, isOpen }"</code>, <code>default="{ item, isOpen }"</code> 슬롯 제공
  </p>

  <hr />

  <h3>5) 커스텀 키 매핑</h3>
  <BaseAccordion
    :items="customKeyItems"
    id-key="key"
    label-key="title"
    content-key="desc"
    children-key="nodes"
    open-first
    @change="onChange('keys', $event)"
  />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: 백엔드 스키마에 맞게 <code>id-key</code>, <code>label-key</code>, <code>content-key</code>, <code>children-key</code> 재정의
  </p>

  <div style="margin-top: 16px; font-size: 12px; color: var(--color-dim, #666)">
    마지막 변경 이벤트: {{ lastEventStr }}
  </div>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>Props</h4>
    <BaseTable :columns="apiColsProps" :rows="apiRowsProps" sticky-first-column />

    <h4 style="margin-top:16px">Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />

    <h4 style="margin-top:16px">Slots</h4>
    <BaseTable :columns="apiColsSlots" :rows="apiRowsSlots" sticky-first-column />

    <h4 style="margin-top:16px">Methods (ref)</h4>
    <BaseTable :columns="apiColsMethods" :rows="apiRowsMethods" sticky-first-column />
  </section>
</template>
<script setup lang="ts">
import BaseAccordion from '@/components/BaseAccordion.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref, computed } from 'vue'

type Key = string | number

const simpleItems = [
  { id: 1, label: 'Item 1', content: '첫 번째 내용' },
  { id: 2, label: 'Item 2', content: '두 번째 내용' },
  { id: 3, label: 'Item 3', content: '세 번째 내용' },
]

const nestedItems = [
  {
    id: 10,
    label: 'Parent A',
    content: '부모 A 내용',
    children: [
      { id: 11, label: 'Child A-1', content: '자식 A-1 내용' },
      {
        id: 12,
        label: 'Child A-2',
        content: '자식 A-2 내용',
        children: [
          { id: 121, label: 'Grand A-2-1', content: '손자 A-2-1 내용' },
          { id: 122, label: 'Grand A-2-2', content: '손자 A-2-2 내용' },
        ],
      },
    ],
  },
  {
    id: 20,
    label: 'Parent B',
    content: '부모 B 내용',
    children: [{ id: 21, label: 'Child B-1', content: '자식 B-1 내용' }],
  },
]

// 커스텀 키 구조 예시
const customKeyItems = [
  {
    key: 'x1',
    title: '섹션 X1',
    desc: '설명 X1',
    nodes: [
      { key: 'x1-1', title: '하위 X1-1', desc: '내용 X1-1' },
      { key: 'x1-2', title: '하위 X1-2', desc: '내용 X1-2' },
    ],
  },
  { key: 'x2', title: '섹션 X2', desc: '설명 X2' },
]

const lastEvent = ref<null | { id: Key; open: boolean; level: number }>(null)
const lastEventStr = computed(() =>
  lastEvent.value ? JSON.stringify(lastEvent.value) : '—'
)

function onChange(tag: string, e: { id: Key; open: boolean; item: any; level: number }) {
  lastEvent.value = { id: e.id, open: e.open, level: e.level }
  // 필요 시 console 로깅
  // console.log(`[${tag}] change`, e)
}

// programmatic API demo
const accRef = ref<InstanceType<typeof BaseAccordion> | null>(null)
function logOpen() {
  // eslint-disable-next-line no-console
  console.log('openIds:', accRef.value?.getOpenIds())
}

// API Reference tables (use BaseTable)
const apiColsProps = [
  { key: 'name', header: 'Prop', width: 160, sticky: true },
  { key: 'type', header: 'Type', width: 180 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'items', type: 'Array', default: '[]', desc: '렌더링할 데이터 배열' },
  { name: 'multiple', type: 'boolean', default: 'false', desc: '동일 레벨에서 다중 열림' },
  { name: 'open-first', type: 'boolean', default: 'false', desc: '로드시 현재 레벨 첫 항목 열기' },
  { name: 'open-first-all-levels', type: 'boolean', default: 'false', desc: '모든 레벨에서 첫 항목 자동 열기' },
  { name: 'initial-open-ids', type: 'Array<Key>', default: '[]', desc: '지정 ID로 초기 열림' },
  { name: 'id-key', type: 'string', default: `'id'`, desc: 'ID 필드 키명' },
  { name: 'label-key', type: 'string', default: `'label'`, desc: '라벨 필드 키명' },
  { name: 'content-key', type: 'string', default: `'content'`, desc: '본문 필드 키명' },
  { name: 'children-key', type: 'string', default: `'children'`, desc: '자식 배열 키명' },
  { name: 'disabled-key', type: 'string', default: `'disabled'`, desc: '비활성 여부 키명' },
]

const apiColsEvents = [
  { key: 'name', header: 'Event', width: 160, sticky: true },
  { key: 'payload', header: 'Payload', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsEvents = [
  { name: 'change', payload: '{ id, open, item, level }', desc: '항목 토글 시 발생' },
]

const apiColsSlots = [
  { key: 'name', header: 'Slot', width: 160, sticky: true },
  { key: 'props', header: 'Props', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsSlots = [
  { name: 'header', props: '{ item, isOpen }', desc: '헤더 영역 커스텀' },
  { name: 'default', props: '{ item, isOpen }', desc: '본문 영역 커스텀' },
]

const apiColsMethods = [
  { key: 'name', header: 'Method', width: 160, sticky: true },
  { key: 'sig', header: 'Signature', width: 200 },
  { key: 'desc', header: 'Description' },
]
const apiRowsMethods = [
  { name: 'open', sig: '(id: Key)', desc: '현재 레벨에서 ID 열기' },
  { name: 'close', sig: '(id: Key)', desc: '현재 레벨에서 ID 닫기' },
  { name: 'toggle', sig: '(id: Key)', desc: '열림/닫힘 토글' },
  { name: 'openAll', sig: '()', desc: 'multiple=true일 때 현재 레벨 전부 열기' },
  { name: 'closeAll', sig: '()', desc: '현재 레벨 전부 닫기' },
  { name: 'getOpenIds', sig: '(): Key[]', desc: '열린 ID 배열 반환' },
]
</script>
