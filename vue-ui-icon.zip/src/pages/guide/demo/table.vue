<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide
  navbar: true
  tabbar: false
  drawer: true
</route>

<template>
  <h2>Table</h2>

  <h3>1) 기본 테이블</h3>
  <BaseTable :columns="colsBasic" :rows="rowsBasic" caption="기본 테이블" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>&lt;BaseTable :columns="cols" :rows="rows" /&gt;</code> · 각 컬럼은 <code>{ key, header?, width?, align? }</code>
  </p>

  <hr />

  <h3>2) 헤더 고정 + 스크롤 높이</h3>
  <BaseTable :columns="colsBasic" :rows="rowsLong" :max-height="320" caption="헤더 고정" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>max-height</code> 지정 시 <code>thead</code>가 sticky 됩니다.
  </p>

  <hr />

  <h3>3) 첫 컬럼 고정</h3>
  <BaseTable :columns="colsSticky" :rows="rowsLong" sticky-first-column :max-height="280" caption="첫 컬럼 고정" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>sticky-first-column</code> 또는 컬럼 정의에서 <code>sticky: true</code>
  </p>

  <hr />

  <h3>4) 특정 컬럼들 고정</h3>
  <BaseTable :columns="colsSticky" :rows="rowsLong" :sticky-columns="['name','amount']" :max-height="280" caption="여러 컬럼 고정" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>:sticky-columns="['name','amount']"</code>로 상황에 맞게 지정
  </p>

  <hr />

  <h3>5) 커스텀 셀 슬롯</h3>
  <BaseTable :columns="colsSticky" :rows="rowsBasic" caption="커스텀 셀">
    <template #cell-amount="{ value }">{{ formatCurrency(value) }}</template>
    <template #cell-date="{ value }"><time :datetime="value">{{ value }}</time></template>
  </BaseTable>
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    셀 슬롯: <code>#cell-KEY</code> · 헤더 슬롯: <code>#header</code>
  </p>

  <hr />

  <h3>6) 빈 상태</h3>
  <BaseTable :columns="colsBasic" :rows="[]" caption="빈 상태">
    <template #empty>표시할 데이터가 없습니다.</template>
  </BaseTable>

  <hr />

  <h3>7) 정렬</h3>
  <BaseTable :columns="colsSortable" :rows="rowsLong" :sortable="true" caption="정렬" />
  <p style="font-size: 12px; color: var(--color-dim, #666)">
    사용법: <code>:sortable</code> 전역 활성화 또는 컬럼에 <code>sortable: true</code>. 초기 정렬은 <code>default-sort-key</code>/<code>default-sort-order</code>
  </p>
  <BaseTable :columns="colsSortable" :rows="rowsLong" :sortable="true" default-sort-key="amount" default-sort-order="desc" caption="초기 정렬(금액 내림차순)" />

  <h3>API Reference</h3>
  <section>
    <h4>Props</h4>
    <BaseTable :columns="apiColsProps" :rows="apiRowsProps" sticky-first-column />

    <h4 style="margin-top:16px">ColumnDef</h4>
    <BaseTable :columns="apiColsColdef" :rows="apiRowsColdef" sticky-first-column />

    <h4 style="margin-top:16px">Slots</h4>
    <BaseTable :columns="apiColsSlots" :rows="apiRowsSlots" sticky-first-column />
  </section>
</template>

<script setup lang="ts">
import BaseTable from '@/components/BaseTable.vue'

type Key = string | number

const colsBasic: Array<{ key: Key; header: string; width?: number; align?: 'left' | 'center' | 'right' }> = [
  { key: 'date', header: '일자', width: 120 },
  { key: 'name', header: '이름', width: 160 },
  { key: 'amount', header: '금액', align: 'right', width: 120 },
]

const colsSticky: Array<{ key: Key; header: string; width?: number; align?: 'left' | 'center' | 'right'; sticky?: boolean }> = [
  { key: 'date', header: '일자', width: 120, sticky: true },
  { key: 'name', header: '이름', width: 200 },
  { key: 'desc', header: '내용', width: 260 },
  { key: 'amount', header: '금액', align: 'right', width: 140 },
]

const colsSortable: Array<{ key: Key; header: string; width?: number; align?: 'left' | 'center' | 'right'; sortable?: boolean }> = [
  { key: 'date', header: '일자', width: 120, sortable: true },
  { key: 'name', header: '이름', width: 200, sortable: true },
  { key: 'amount', header: '금액', align: 'right', width: 140, sortable: true },
]

const rowsBasic = [
  { date: '2025-08-01', name: '홍길동', desc: '입금', amount: 1200000 },
  { date: '2025-08-02', name: '김철수', desc: '출금', amount: -250000 },
  { date: '2025-08-03', name: '이영희', desc: '송금', amount: 385000 },
]

const rowsLong = Array.from({ length: 30 }).map((_, i) => ({
  date: `2025-08-${String((i % 30) + 1).padStart(2, '0')}`,
  name: `사용자 ${i + 1}`,
  desc: i % 3 === 0 ? '입금' : i % 3 === 1 ? '출금' : '송금',
  amount: (i % 2 === 0 ? 1 : -1) * (10000 + i * 3210),
}))

function formatCurrency(v: number) {
  try {
    return new Intl.NumberFormat('ko-KR').format(v) + '원'
  } catch {
    return String(v)
  }
}

// API tables using BaseTable
const apiColsProps = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'columns', type: 'Array<ColumnDef>', default: '[]', desc: '컬럼 정의 배열' },
  { name: 'rows', type: 'any[]', default: '[]', desc: '표시할 데이터' },
  { name: 'caption', type: 'string', default: '-', desc: '접근성용 캡션(시각 숨김)' },
  { name: 'maxHeight', type: 'number | string', default: '-', desc: '뷰포트 최대 높이(px/문자열). 지정 시 헤더 sticky' },
  { name: 'stickyHeader', type: 'boolean', default: 'true', desc: '헤더 sticky 토글' },
  { name: 'stickyFirstColumn', type: 'boolean', default: 'false', desc: '첫 번째 컬럼 sticky' },
  { name: 'stickyColumns', type: 'Key[]', default: '[]', desc: '고정할 컬럼 key 목록' },
  { name: 'defaultColWidth', type: 'number', default: '160', desc: '고정 컬럼 left 계산 시 기본 너비(px)' },
  { name: 'rowKey', type: "string | (row,i)=>Key", default: '-', desc: '행 식별 키' },
  { name: 'sortable', type: 'boolean', default: 'false', desc: '헤더 클릭 정렬 활성화(컬럼별 sortable로 제어 가능)' },
  { name: 'defaultSortKey', type: 'Key', default: 'null', desc: '초기 정렬 컬럼 키' },
  { name: 'defaultSortOrder', type: "'asc'|'desc'", default: "'asc'", desc: '초기 정렬 순서' },
]

const apiColsColdef = [
  { key: 'field', header: 'Field', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'desc', header: 'Description' },
]
const apiRowsColdef = [
  { field: 'key', type: 'Key', desc: '열 키(행 데이터 접근)' },
  { field: 'header', type: 'string', desc: '헤더 텍스트' },
  { field: 'width', type: 'number|string', desc: '열 너비(px 숫자 또는 CSS)' },
  { field: 'align', type: "'left'|'center'|'right'", desc: '정렬' },
  { field: 'sticky', type: 'boolean', desc: '해당 열만 sticky 지정' },
  { field: 'sortable', type: 'boolean', desc: '해당 컬럼 정렬 허용' },
  { field: 'sortAccessor', type: '(row)=>any', desc: '정렬 기준값 추출 함수' },
  { field: 'formatter', type: '(val,row)=>any', desc: '셀 값 포매터' },
]

const apiColsSlots = [
  { key: 'name', header: 'Slot', width: 180, sticky: true },
  { key: 'props', header: 'Props', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsSlots = [
  { name: 'header', props: '{ column }', desc: '헤더 셀 커스텀' },
  { name: 'cell-KEY', props: '{ row, column, value }', desc: '지정 열의 본문 셀 커스텀' },
  { name: 'empty', props: '-', desc: '빈 상태 표시' },
]
</script>
