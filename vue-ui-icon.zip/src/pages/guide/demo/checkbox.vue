<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Checkbox</h2>

  <h3>1) 기본</h3>
  <BaseCheckbox v-model="c1">약관 동의</BaseCheckbox>

  <hr />

  <h3>2) 박스형</h3>
  <BaseCheckbox v-model="c2" variant="box">선택 옵션</BaseCheckbox>

  <hr />

  <h3>3) 그룹형 (여러 유형)</h3>
  <p>기본 그룹</p>
  <BaseCheckboxGroup v-model="g1" :options="opts" />

  <p style="margin-top:8px">박스형 그룹</p>
  <BaseCheckboxGroup v-model="g2" :options="opts" variant="box" />

  <p style="margin-top:8px">일부 비활성</p>
  <BaseCheckboxGroup v-model="g3" :options="optsDisabled" />

  <div style="margin-top: 8px; font-size:12px; color: var(--color-dim,#666)">선택: {{ g1 }}</div>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>BaseCheckbox Props</h4>
    <BaseTable :columns="apiColsCommon" :rows="apiRowsCheckboxProps" sticky-first-column />

    <h4 style="margin-top:16px">BaseCheckbox Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsCheckboxEvents" sticky-first-column />

    <h4 style="margin-top:16px">BaseCheckboxGroup Props</h4>
    <BaseTable :columns="apiColsCommon" :rows="apiRowsCheckboxGroupProps" sticky-first-column />

    <h4 style="margin-top:16px">BaseCheckboxGroup Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsCheckboxGroupEvents" sticky-first-column />
  </section>
</template>
<script setup lang="ts">
import BaseCheckbox from '@/components/BaseCheckbox.vue'
import BaseCheckboxGroup from '@/components/BaseCheckboxGroup.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const c1 = ref(false)
const c2 = ref(true)
const g1 = ref<(string|number|boolean)[]>(['b'])
const g2 = ref<(string|number|boolean)[]>([])
const g3 = ref<(string|number|boolean)[]>([])

const opts = [
  { label: '옵션 A', value: 'a' },
  { label: '옵션 B', value: 'b' },
  { label: '옵션 C', value: 'c' },
]
const optsDisabled = [
  { label: '옵션 A', value: 'a' },
  { label: '옵션 B(비활성)', value: 'b', disabled: true },
  { label: '옵션 C', value: 'c' },
]

// API tables
const apiColsCommon = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 220 },
  { key: 'desc', header: 'Description' },
]
const apiRowsCheckboxProps = [
  { name: 'modelValue', type: 'boolean', default: 'false', desc: '체크 상태 (v-model)' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '비활성' },
  { name: 'label', type: 'string', default: '-', desc: '라벨 텍스트 (슬롯 우선)' },
  { name: 'id', type: 'string', default: '-', desc: 'input id' },
  { name: 'name', type: 'string', default: '-', desc: 'input name' },
  { name: 'variant', type: "'default'|'box'", default: 'default', desc: '표시 형태' },
]
const apiRowsCheckboxEvents = [
  { name: 'update:modelValue', payload: 'boolean', desc: '상태 변경(v-model 동기화)' },
  { name: 'change', payload: 'boolean', desc: '상태 변경 알림' },
]
const apiRowsCheckboxGroupProps = [
  { name: 'options', type: 'Array<{label,value,disabled?}>', default: '[]', desc: '옵션 목록' },
  { name: 'modelValue', type: 'Key[]', default: '[]', desc: '선택된 값 배열 (v-model)' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '그룹 전체 비활성' },
  { name: 'variant', type: "'default'|'box'", default: 'default', desc: '표시 형태' },
  { name: 'ariaLabel', type: 'string', default: '-', desc: '접근성 그룹 라벨 (role=group)' },
]
const apiRowsCheckboxGroupEvents = [
  { name: 'update:modelValue', payload: 'Key[]', desc: '선택 변경(v-model 동기화)' },
  { name: 'change', payload: 'Key[]', desc: '선택 변경 알림' },
]
</script>
