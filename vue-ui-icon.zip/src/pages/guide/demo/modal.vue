<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Modal</h2>
  <BaseButton @click="open = true"> Open Modal </BaseButton>
  <BaseModal v-model="open">
    <p>모달 내용</p>
    <template #footer
      ><BaseButton class="c-btn--ghost" @click="open = false"> 닫기 </BaseButton></template
    >
  </BaseModal>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import BaseModal from '@/components/BaseModal.vue'
import BaseButton from '@/components/BaseButton.vue'
const open = ref(false)
</script>
