<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Swiper – All Options Showcase</h2>

  <!-- 0. 기본(슬라이드, bullets, autoplay) -->
  <h3>0) 기본 (slide + bullets + autoplay)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="{ delay: 2200, pauseOnInteraction: true }"
    pagination
    pagination-type="bullets"
    navigation
    controls
    keyboard
    :initial-slide="0"
    aria-label="기본 캐러셀"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: 기본값(autoplay, pagination, navigation) 조합. <code>:autoplay</code>는 <code>{ delay, pauseOnInteraction }</code> 객체 또는 <code>false</code></p>

  <!-- 1. 네비게이션만 (재생/정지 숨김) -->
  <h3 style="margin-top: 40px">1) 네비게이션만 (controls=false, autoplay=false)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="false"
    navigation
    :controls="false"
    pagination
    aria-label="네비게이션만"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>:autoplay="false"</code>, <code>:controls="false"</code>로 재생/일시정지 버튼 숨김</p>

  <!-- 2. 페이징 타입: fraction -->
  <h3 style="margin-top: 40px">2) Pagination: fraction</h3>
  <SwiperCarousel
    :slides="demoSlides"
    pagination
    pagination-type="fraction"
    navigation
    :slides-per-view="2"
    :space-between="12"
    aria-label="프랙션 페이지네이션"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>pagination</code> + <code>pagination-type="fraction"</code>, <code>:slides-per-view</code>, <code>:space-between</code></p>

  <!-- 3. 페이징 타입: progressbar (첫 슬라이드부터 채움) -->
  <h3 style="margin-top: 40px">3) Pagination: progressbar</h3>
  <SwiperCarousel
    :slides="tallSlides"
    pagination
    pagination-type="progressbar"
    navigation
    :slides-per-view="1"
    :space-between="8"
    aria-label="프로그레스바 페이지네이션"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>pagination-type="progressbar"</code> — 첫 슬라이드부터 채움</p>

  <!-- 4. 여러 장 보기 + 간격 + 가운데 정렬 -->
  <h3 style="margin-top: 40px">4) 여러 장 보기 + 간격 + 가운데 정렬</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :slides-per-view="3"
    :space-between="16"
    centered
    navigation
    pagination
    aria-label="여러장/간격/센터"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>:slides-per-view</code> + <code>:space-between</code> + <code>centered</code></p>

  <!-- 5. Breakpoints (반응형) -->
  <h3 style="margin-top: 40px">5) Breakpoints (반응형)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :breakpoints="{
      480: { slidesPerView: 2, spaceBetween: 10 },
      768: { slidesPerView: 3, spaceBetween: 14 },
      1024: { slidesPerView: 4, spaceBetween: 16 },
    }"
    pagination
    navigation
    aria-label="반응형 브레이크포인트"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>:breakpoints</code> 객체로 구간별 <code>slidesPerView</code>/<code>spaceBetween</code> 지정</p>

  <!-- 6. Free mode (자유 스크럽) -->
  <h3 style="margin-top: 40px">6) Free Mode</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :free-mode="true"
    :slides-per-view="2"
    :space-between="12"
    navigation
    pagination
    aria-label="프리모드"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>:free-mode</code> 활성화로 스크럽 자유 이동</p>

  <!-- 7. 키보드 이동 + 초기 인덱스 -->
  <h3 style="margin-top: 40px">7) Keyboard + Initial Slide</h3>
  <SwiperCarousel
    :slides="demoSlides"
    keyboard
    navigation
    pagination
    :initial-slide="2"
    aria-label="키보드/초기슬라이드"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>keyboard</code>, <code>:initial-slide</code></p>

  <!-- 8. 터치 비활성(접근성/스크롤 존중) -->
  <h3 style="margin-top: 40px">8) 터치 이동 비활성 (allowTouchMove=false)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :allow-touch-move="false"
    navigation
    pagination
    aria-label="터치 비활성"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>:allow-touch-move="false"</code>로 터치 스와이프 비활성</p>

  <!-- 9. Fade – 부드러운 전환 -->
  <h3 style="margin-top: 40px">9) Fade – 부드러운 전환 (smooth)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    effect="fade"
    fade-mode="smooth"
    :autoplay="{ delay: 2500 }"
    :controls="true"
    pagination
    aria-label="페이드 스무스"
    style="--fade-ease: ease-in-out; --fade-speed: 400ms"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>effect="fade"</code> + <code>fade-mode</code>(smooth/instant), <code>--fade-ease</code>/<code>--fade-speed</code> CSS 변수로 전환 제어</p>

  <!-- 10. Fade – 즉시 표시(전환 없음) -->
  <h3 style="margin-top: 40px">10) Fade – 즉시 표시 (instant)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    effect="fade"
    fade-mode="instant"
    :autoplay="false"
    :controls="true"
    pagination
    aria-label="페이드 인스턴트"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>effect="fade"</code> + <code>fade-mode="instant"</code></p>

  <!-- 11. Autoplay + 접근성: 일시정지 버튼 강제 노출 -->
  <h3 style="margin-top: 40px">11) Autoplay + 접근성 (항상 Pause 노출)</h3>
  <SwiperCarousel
    :slides="demoSlides"
    :autoplay="{ delay: 1800 }"
    :require-pause-for-autoplay="true"
    :controls="false"
    pagination
    navigation
    aria-label="접근성 자동재생"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: 자동재생 시 <code>:require-pause-for-autoplay</code>로 일시정지 버튼 항상 노출</p>

  <!-- 12. 모든 기능 조합 가변 테스트 -->
  <h3 style="margin-top: 40px">12) 모든 기능 조합 (stress)</h3>
  <SwiperCarousel
    :slides="mixedHeightSlides"
    :slides-per-view="2"
    :space-between="12"
    :breakpoints="{
      600: { slidesPerView: 2, spaceBetween: 12 },
      900: { slidesPerView: 3, spaceBetween: 16 },
    }"
    centered
    navigation
    pagination
    pagination-type="bullets"
    keyboard
    :free-mode="false"
    :autoplay="{ delay: 2200, pauseOnInteraction: true }"
    :require-pause-for-autoplay="true"
    :initial-slide="1"
    aria-label="풀옵션 콤보"
    style="--swiper-gap: 12px; --swiper-speed: 350ms"
  />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: 다양한 옵션 조합 + <code>--swiper-gap</code>, <code>--swiper-speed</code> 변수로 미세 튜닝</p>

  <!-- 13. 스타일 변수 커스텀(도트/라운드/속도) -->
  <h3 style="margin-top: 40px">13) 전역 변수 커스텀 (로컬 인스턴스만)</h3>
  <div
    style="
      --swiper-dot-size: 12px;
      --swiper-dot-color: #94a3b8;
      --swiper-dot-active: #ef4444;
      --swiper-radius: 16px;
      --swiper-speed: 500ms;
    "
  >
    <SwiperCarousel
      :slides="demoSlides"
      navigation
      pagination
      aria-label="스타일 변수 커스텀 인스턴스"
    />
  </div>

  <hr />

  <h3>API Reference</h3>
  <h4>Props</h4>
  <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />
  <h4 style="margin-top:16px">Slots</h4>
  <BaseTable :columns="apiColsSlots" :rows="apiRowsSlots" sticky-first-column />
</template>

<script setup lang="ts">
import SwiperCarousel from '@/components/SwiperCarousel.vue'
import BaseTable from '@/components/BaseTable.vue'

// 데모용 데이터
const demoSlides = Array.from({ length: 7 }, (_, i) => ({
  title: `Slide ${i + 1}`,
  desc: '기본 데모 카드',
}))

// 높이가 제각각인 슬라이드 (fade 높이 관찰 확인)
const mixedHeightSlides = [
  { title: 'A', desc: '짧은 텍스트' },
  { title: 'B', desc: '중간 길이 텍스트\n줄바꿈 포함' },
  {
    title: 'C',
    desc: '아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트 아주 긴 텍스트',
  },
  { title: 'D', desc: '이미지/콘텐츠가 더 길다고 가정' },
  { title: 'E', desc: '끝' },
]

// progressbar 테스트용 (조금 더 높은 카드)
const tallSlides = Array.from({ length: 5 }, (_, i) => ({
  title: `Tall ${i + 1}`,
  desc: '높은 카드',
}))

const apiCols = [
  { key: 'name', header: 'Prop', width: 200, sticky: true },
  { key: 'type', header: 'Type', width: 240 },
  { key: 'default', header: 'Default', width: 140 },
  { key: 'desc', header: 'Description' },
]
const apiColsSlots = [
  { key: 'name', header: 'Slot', width: 200, sticky: true },
  { key: 'props', header: 'Props', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'slides', type: 'any[]', default: '[]', desc: '슬라이드 데이터 배열' },
  { name: 'slidesPerView', type: 'number', default: '1', desc: '한 화면에 보이는 슬라이드 수' },
  { name: 'spaceBetween', type: 'number', default: '8', desc: '슬라이드 간 간격(px)' },
  { name: 'centered', type: 'boolean', default: 'false', desc: '활성 슬라이드 가운데 정렬' },
  { name: 'speed', type: 'number', default: '300', desc: '전환 속도(ms)' },
  { name: 'pagination', type: 'boolean', default: 'true', desc: '페이지네이션 사용' },
  { name: 'paginationType', type: "'bullets'|'fraction'|'progressbar'", default: "'bullets'", desc: '페이지네이션 유형' },
  { name: 'navigation', type: 'boolean', default: 'true', desc: '이전/다음 버튼' },
  { name: 'controls', type: 'boolean', default: 'true', desc: '재생/일시정지 버튼' },
  { name: 'keyboard', type: 'boolean', default: 'true', desc: '키보드 화살표 이동' },
  { name: 'freeMode', type: 'boolean', default: 'false', desc: '자유 스크럽' },
  { name: 'allowTouchMove', type: 'boolean', default: 'true', desc: '터치/드래그 이동 허용' },
  { name: 'initialSlide', type: 'number', default: '0', desc: '초기 인덱스' },
  { name: 'breakpoints', type: 'Record<number,{slidesPerView?,spaceBetween?}>', default: '{}', desc: '반응형 설정' },
  { name: 'autoplay', type: 'boolean | { delay?: number; pauseOnInteraction?: boolean }', default: 'false', desc: '자동재생 설정' },
  { name: 'ariaLabel', type: 'string', default: '"이미지 캐러셀"', desc: '접근성 라벨' },
  { name: 'pauseOnMouseEnter', type: 'boolean', default: 'true', desc: '마우스 진입 시 자동재생 일시정지' },
  { name: 'effect', type: "'slide'|'fade'", default: "'slide'", desc: '전환 효과' },
  { name: 'fadeMode', type: "'smooth'|'instant'", default: "'smooth'", desc: '페이드 모드' },
  { name: 'requirePauseForAutoplay', type: 'boolean', default: 'true', desc: '자동재생 시 일시정지 버튼 강제 노출' },
]
const apiRowsSlots = [
  { name: 'slide', props: '{ item, index }', desc: '각 슬라이드를 커스텀 렌더' },
]
</script>

<style lang="scss" scoped>
</style>
