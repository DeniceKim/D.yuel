<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Navbar</h2>
  <BaseNavbar />

  <hr />

  <h3>유형</h3>
  <div style="display:grid; gap:16px">
    <div>
      <div style="font-size:12px;color:var(--color-dim,#666); margin-bottom:6px">1) 기본</div>
      <div style="border:1px solid var(--border-secondary); border-radius:12px; overflow:hidden">
        <BaseNavbar title="기본 Navbar" />
      </div>
    </div>
    <div>
      <div style="font-size:12px;color:var(--color-dim,#666); margin-bottom:6px">2) 뒤로가기 표시</div>
      <div style="border:1px solid var(--border-secondary); border-radius:12px; overflow:hidden">
        <BaseNavbar title="뒤로가기" :show-back="true" @back="onBack" />
      </div>
    </div>
    <div>
      <div style="font-size:12px;color:var(--color-dim,#666); margin-bottom:6px">3) 긴 타이틀(말줄임)</div>
      <div style="border:1px solid var(--border-secondary); border-radius:12px; overflow:hidden">
        <BaseNavbar :show-back="true" title="아주아주 긴 페이지 제목으로 말줄임 처리 확인용 샘플 타이틀입니다" />
      </div>
    </div>
    <div>
      <div style="font-size:12px;color:var(--color-dim,#666); margin-bottom:6px">4) 이벤트 핸들링</div>
      <div style="border:1px solid var(--border-secondary); border-radius:12px; overflow:hidden; margin-bottom:4px">
        <BaseNavbar title="이벤트 데모" :show-back="true" @back="onBack" @open-menu="onOpenMenu" />
      </div>
      <div style="font-size:12px;color:var(--color-dim,#666)">최근 이벤트: {{ lastEvt || '-' }}</div>
    </div>
  </div>

  <hr />

  <h3>API Reference</h3>
  <h4>Props</h4>
  <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />
  <h4 style="margin-top:16px">Events</h4>
  <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />
</template>
<script setup lang="ts">
import BaseNavbar from '@/components/BaseNavbar.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const apiCols = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 220 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'title', type: 'string', default: '"Bank App"', desc: '헤더 제목' },
  { name: 'showBack', type: 'boolean', default: 'false', desc: '뒤로가기 버튼 표시' },
]
const apiRowsEvents = [
  { name: 'back', payload: '-', desc: '뒤로가기 클릭' },
  { name: 'open-menu', payload: '-', desc: '메뉴 버튼 클릭' },
]

const lastEvt = ref('')
function onBack() { lastEvt.value = 'back' }
function onOpenMenu() { lastEvt.value = 'open-menu' }
</script>
