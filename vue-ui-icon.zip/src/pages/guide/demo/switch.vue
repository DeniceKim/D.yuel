<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Switch</h2>

  <h3>1) 기본</h3>
  <BaseSwitch v-model="v1">알림 설정</BaseSwitch>

  <hr />

  <h3>2) 크기</h3>
  <div style="display:flex; gap: 12px; align-items: center; flex-wrap: wrap">
    <BaseSwitch v-model="v2" size="sm">작게</BaseSwitch>
    <BaseSwitch v-model="v3" size="md">보통</BaseSwitch>
    <BaseSwitch v-model="v4" size="lg">크게</BaseSwitch>
  </div>

  <hr />

  <h3>3) 비활성</h3>
  <BaseSwitch v-model="v5" :disabled="true">비활성</BaseSwitch>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>Props</h4>
    <BaseTable :columns="apiColsProps" :rows="apiRowsProps" sticky-first-column />

    <h4 style="margin-top:16px">Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />
  </section>
</template>
<script setup lang="ts">
import BaseSwitch from '@/components/BaseSwitch.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const v1 = ref(false)
const v2 = ref(false)
const v3 = ref(true)
const v4 = ref(false)
const v5 = ref(true)

const apiColsProps = [
  { key: 'name', header: 'Prop', width: 160, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 140 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'modelValue', type: 'boolean', default: 'false', desc: '스위치 상태 (v-model)' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '비활성' },
  { name: 'label', type: 'string', default: '-', desc: '라벨 텍스트 (슬롯이 우선)' },
  { name: 'size', type: "'sm'|'md'|'lg'", default: 'md', desc: '크기' },
  { name: 'id', type: 'string', default: '-', desc: 'input id' },
  { name: 'name', type: 'string', default: '-', desc: 'input name' },
]

const apiColsEvents = [
  { key: 'name', header: 'Event', width: 160, sticky: true },
  { key: 'payload', header: 'Payload', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsEvents = [
  { name: 'update:modelValue', payload: 'boolean', desc: '상태 변경(v-model 동기화)' },
  { name: 'change', payload: 'boolean', desc: '상태 변경 알림' },
]
</script>
