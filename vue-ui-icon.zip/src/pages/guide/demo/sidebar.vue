<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Sidebar</h2>

  <h3>1) 기본 (내장 데모 링크)</h3>
  <BaseSidebar />

  <hr />

  <h3>2) 섹션 데이터 + 접기/펼치기</h3>
  <div style="display:flex; gap:12px; align-items:center; margin-bottom:8px">
    <BaseButton size="sm" @click="collapsed = !collapsed">Toggle</BaseButton>
    <span style="font-size:12px; color: var(--color-dim,#666)">collapsed: {{ collapsed }}</span>
  </div>
  <div style="border:1px solid var(--border-primary,#d0d5dd); display:grid; grid-template-columns: 280px 1fr; min-height: 200px">
    <BaseSidebar v-model="collapsed" :sections="sections" :width="280" :collapsed-width="64" />
    <div style="padding:12px">Content area</div>
  </div>

  <hr />

  <h3>3) 오버레이 모드</h3>
  <div style="display:flex; gap:12px; align-items:center; margin-bottom:8px">
    <BaseButton size="sm" @click="overlayOpen = true">Open Overlay Sidebar</BaseButton>
  </div>
  <BaseSidebar v-if="overlayOpen" v-model="overlayOpen" :sections="sections" overlay :width="260" :collapsed-width="64">
    <template #footer>
      <div style="font-size:12px; color: var(--color-dim,#666)">Footer area</div>
    </template>
  </BaseSidebar>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>Props</h4>
    <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />

    <h4 style="margin-top:16px">Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />

    <h4 style="margin-top:16px">Slots</h4>
    <BaseTable :columns="apiColsSlots" :rows="apiRowsSlots" sticky-first-column />
  </section>
</template>
<script setup lang="ts">
import BaseSidebar from '@/components/BaseSidebar.vue'
import BaseButton from '@/components/BaseButton.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const collapsed = ref(false)
const overlayOpen = ref(false)

const sections = [
  {
    title: 'Pages',
    items: [
      { label: '홈', to: '/' },
      { label: '가이드', to: '/guide' },
      { label: '외부 링크', href: 'https://example.com' },
    ],
  },
  {
    title: 'Components',
    items: [
      { label: 'Accordion', to: '/guide/demo/accordion' },
      { label: 'Table', to: '/guide/demo/table' },
      { label: 'Input', to: '/guide/demo/input' },
    ],
  },
]

const apiCols = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 240 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiColsSlots = [
  { key: 'name', header: 'Slot', width: 180, sticky: true },
  { key: 'desc', header: 'Description' },
]

const apiRowsProps = [
  { name: 'sections', type: 'Array<{title?:string; items:{label; to?; href?; icon?}[]}>', default: '[]', desc: '렌더링할 섹션/항목 데이터' },
  { name: 'collapsible', type: 'boolean', default: 'true', desc: '헤더 토글 버튼 표시' },
  { name: 'modelValue', type: 'boolean', default: 'false', desc: '접힘 상태(v-model)' },
  { name: 'width', type: 'number|string', default: '240', desc: '펼침 너비(px or CSS)' },
  { name: 'collapsedWidth', type: 'number|string', default: '56', desc: '접힘 너비(px or CSS)' },
  { name: 'overlay', type: 'boolean', default: 'false', desc: '오버레이 모드(고정+백드롭)' },
  { name: 'ariaLabel', type: 'string', default: "'사이드바'", desc: '접근성 레이블' },
]
const apiRowsEvents = [
  { name: 'update:modelValue', payload: 'boolean', desc: '접힘 상태 변경(v-model 동기화)' },
  { name: 'toggle', payload: 'boolean', desc: '접힘 상태 변경 알림' },
]
const apiRowsSlots = [
  { name: 'header', desc: '헤더 전체 커스텀(토글/타이틀 포함)' },
  { name: 'title', desc: '기본 타이틀 영역만 교체' },
  { name: 'footer', desc: '하단 푸터 영역' },
]
</script>
