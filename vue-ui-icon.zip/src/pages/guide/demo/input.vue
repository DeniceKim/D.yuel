<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide
  navbar: true
  tabbar: false
  drawer: true
</route>

<template>
  <h2>Input</h2>

  <h3>1) 기본</h3>
  <BaseInput v-model="v1" label="이름" placeholder="이름을 입력" />

  <hr />

  <h3>2) 프리픽스/서픽스/클리어</h3>
  <BaseInput v-model="v2" placeholder="금액" clearable>
    <template #prefix>₩</template>
    <template #suffix>KRW</template>
  </BaseInput>

  <hr />

  <h3>3) 크기/상태</h3>
  <div style="display:flex; gap:12px; flex-wrap:wrap">
    <BaseInput v-model="v3" size="sm" placeholder="작게" />
    <BaseInput v-model="v4" size="md" placeholder="보통" />
    <BaseInput v-model="v5" size="lg" placeholder="크게" />
    <BaseInput v-model="v6" :disabled="true" placeholder="비활성" />
    <BaseInput v-model="v7" :invalid="true" placeholder="오류" />
  </div>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>Props</h4>
    <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />

    <h4 style="margin-top:16px">Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />
  </section>
</template>

<script setup lang="ts">
import BaseInput from '@/components/BaseInput.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const v1 = ref('')
const v2 = ref('10000')
const v3 = ref('')
const v4 = ref('')
const v5 = ref('')
const v6 = ref('')
const v7 = ref('')

const apiCols = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 240 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'modelValue', type: 'string|number|null', default: "''", desc: '입력값 (v-model)' },
  { name: 'type', type: 'string', default: 'text', desc: 'input type' },
  { name: 'placeholder', type: 'string', default: '-', desc: 'placeholder' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '비활성' },
  { name: 'readonly', type: 'boolean', default: 'false', desc: '읽기전용' },
  { name: 'invalid', type: 'boolean', default: 'false', desc: '오류 상태' },
  { name: 'label', type: 'string', default: '-', desc: '라벨 텍스트' },
  { name: 'hint', type: 'string', default: '-', desc: '하단 힌트 텍스트' },
  { name: 'id', type: 'string', default: '-', desc: 'input id' },
  { name: 'name', type: 'string', default: '-', desc: 'input name' },
  { name: 'describedby', type: 'string', default: '-', desc: 'aria-describedby 연결 id' },
  { name: 'size', type: "'sm'|'md'|'lg'", default: 'md', desc: '크기' },
  { name: 'clearable', type: 'boolean', default: 'false', desc: '클리어 버튼 표시' },
]
const apiRowsEvents = [
  { name: 'update:modelValue', payload: 'any', desc: '입력 시 발생(v-model 동기화)' },
  { name: 'change', payload: 'any', desc: 'change 발생 시' },
  { name: 'clear', payload: '-', desc: '클리어 버튼 클릭' },
]
</script>

