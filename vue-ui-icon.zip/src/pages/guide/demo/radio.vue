<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide
  navbar: true
  tabbar: false
  drawer: true
</route>

<template>
  <h2>Radio</h2>

  <h3>1) 기본</h3>
  <BaseRadio v-model="r1" name="demo1" :value="'a'">A</BaseRadio>
  <BaseRadio v-model="r1" name="demo1" :value="'b'">B</BaseRadio>

  <hr />

  <h3>2) 박스형</h3>
  <BaseRadio v-model="r2" name="demo2" :value="'x'" variant="box">X</BaseRadio>
  <BaseRadio v-model="r2" name="demo2" :value="'y'" variant="box">Y</BaseRadio>

  <hr />

  <h3>3) 그룹형 (여러 유형)</h3>
  <p>기본 그룹</p>
  <BaseRadioGroup v-model="rg1" :options="rOpts" name="group1" />

  <p style="margin-top:8px">박스형 그룹</p>
  <BaseRadioGroup v-model="rg2" :options="rOpts" name="group2" variant="box" />

  <p style="margin-top:8px">일부 비활성</p>
  <BaseRadioGroup v-model="rg3" :options="rOptsDisabled" name="group3" />

  <div style="margin-top: 8px; font-size:12px; color: var(--color-dim,#666)">선택: {{ rg1 }}</div>

  <hr />

  <h3>API Reference</h3>
  <section>
    <h4>BaseRadio Props</h4>
    <BaseTable :columns="apiColsCommon" :rows="apiRowsRadioProps" sticky-first-column />

    <h4 style="margin-top:16px">BaseRadio Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsRadioEvents" sticky-first-column />

    <h4 style="margin-top:16px">BaseRadioGroup Props</h4>
    <BaseTable :columns="apiColsCommon" :rows="apiRowsRadioGroupProps" sticky-first-column />

    <h4 style="margin-top:16px">BaseRadioGroup Events</h4>
    <BaseTable :columns="apiColsEvents" :rows="apiRowsRadioGroupEvents" sticky-first-column />
  </section>
</template>

<script setup lang="ts">
import BaseRadio from '@/components/BaseRadio.vue'
import BaseRadioGroup from '@/components/BaseRadioGroup.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const r1 = ref('a')
const r2 = ref('x')

const rg1 = ref('b')
const rg2 = ref('')
const rg3 = ref('')

const rOpts = [
  { label: '옵션 A', value: 'a' },
  { label: '옵션 B', value: 'b' },
  { label: '옵션 C', value: 'c' },
]
const rOptsDisabled = [
  { label: '옵션 A', value: 'a' },
  { label: '옵션 B(비활성)', value: 'b', disabled: true },
  { label: '옵션 C', value: 'c' },
]

// API tables
const apiColsCommon = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 220 },
  { key: 'desc', header: 'Description' },
]
const apiRowsRadioProps = [
  { name: 'modelValue', type: 'any', default: '-', desc: '선택된 값 (v-model)' },
  { name: 'value', type: 'any', default: '-', desc: '라디오의 값' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '비활성' },
  { name: 'label', type: 'string', default: '-', desc: '라벨 텍스트 (슬롯 우선)' },
  { name: 'id', type: 'string', default: '-', desc: 'input id' },
  { name: 'name', type: 'string', default: '-', desc: 'input name (그룹화에 사용)' },
  { name: 'variant', type: "'default'|'box'", default: 'default', desc: '표시 형태' },
]
const apiRowsRadioEvents = [
  { name: 'update:modelValue', payload: 'any', desc: '선택 변경(v-model 동기화)' },
  { name: 'change', payload: 'any', desc: '선택 변경 알림' },
]
const apiRowsRadioGroupProps = [
  { name: 'options', type: 'Array<{label,value,disabled?}>', default: '[]', desc: '옵션 목록' },
  { name: 'modelValue', type: 'Key|null', default: 'null', desc: '선택된 값 (v-model)' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '그룹 전체 비활성' },
  { name: 'variant', type: "'default'|'box'", default: 'default', desc: '표시 형태' },
  { name: 'name', type: 'string', default: '-', desc: '내부 라디오 name 전달' },
  { name: 'ariaLabel', type: 'string', default: '-', desc: '접근성 그룹 라벨 (role=radiogroup)' },
]
const apiRowsRadioGroupEvents = [
  { name: 'update:modelValue', payload: 'Key|null', desc: '선택 변경(v-model 동기화)' },
  { name: 'change', payload: 'Key|null', desc: '선택 변경 알림' },
]
</script>
