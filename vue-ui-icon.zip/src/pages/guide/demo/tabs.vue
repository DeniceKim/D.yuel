<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Tabs</h2>

  <h3>1) 기본(underline)</h3>
  <BaseTabs :items="items" v-model="active1">
    <template #panel-home>홈 패널 내용</template>
    <template #panel-profile>프로필 패널 내용</template>
    <template #panel-contact>문의 패널 내용</template>
  </BaseTabs>
  <p style="font-size:12px;color:var(--color-dim,#666)">
    사용법: <code>:items</code>로 탭 정의, <code>v-model</code>로 활성 탭 동기화, <code>#panel-KEY</code> 슬롯으로 패널 렌더
  </p>

  <hr />

  <h3>2) Pills + 가운데 정렬</h3>
  <BaseTabs :items="items" variant="pills" align="center" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>variant="pills"</code>, <code>align="center"</code></p>

  <hr />

  <h3>3) Justified + 하단 배치</h3>
  <BaseTabs :items="items" justified placement="bottom" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>justified</code>, <code>placement="bottom"</code></p>

  <hr />

  <h3>4) Bar (두꺼운 인디케이터)</h3>
  <BaseTabs :items="items" variant="bar" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>variant="bar"</code></p>

  <hr />

  <h3>5) Card</h3>
  <BaseTabs :items="items" variant="card" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>variant="card"</code></p>

  <hr />

  <h3>6) Line Move (인디케이터 이동)</h3>
  <BaseTabs :items="items" variant="line-move" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>variant="line-move"</code> — 활성 탭 하단 라인이 슬라이드 이동</p>

  <hr />

  <h3>7) Segment Move (배경 이동)</h3>
  <BaseTabs :items="items" variant="segment-move" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>variant="segment-move"</code> — 활성 탭 배경이 슬라이드 이동</p>

  <hr />

  <h3>8) 균등 분할 + Line Move</h3>
  <BaseTabs :items="items" justified variant="line-move" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>justified</code> + <code>variant="line-move"</code></p>

  <hr />

  <h3>9) 균등 분할 + Segment Move</h3>
  <BaseTabs :items="items" justified variant="segment-move" />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>justified</code> + <code>variant="segment-move"</code></p>

  <hr />

  <h3>10) 많은 탭(가로 스크롤) + 가운데 정렬</h3>
  <BaseTabs :items="itemsLong" variant="line-move" scrollable center-active />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>scrollable</code>로 가로 스크롤, <code>center-active</code>로 활성 탭을 가운데 정렬</p>

  <h3 style="margin-top: 16px">11) 스크롤 + 좌/우 버튼 + 다양한 길이</h3>
  <BaseTabs :items="itemsMixed" variant="segment-move" scrollable center-active nav-buttons />
  <p style="font-size:12px;color:var(--color-dim,#666)">사용법: <code>nav-buttons</code>로 좌/우 버튼 표시. 첫/마지막 탭에서 각 버튼 비활성 처리</p>

  <h3>API Reference</h3>
  <h4>Props</h4>
  <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />
  <h4 style="margin-top:16px">Events</h4>
  <BaseTable :columns="apiColsEvents" :rows="apiRowsEvents" sticky-first-column />
  <h4 style="margin-top:16px">Slots</h4>
  <BaseTable :columns="apiColsSlots" :rows="apiRowsSlots" sticky-first-column />
</template>
<script setup lang="ts">
import BaseTabs from '@/components/BaseTabs.vue'
import BaseTable from '@/components/BaseTable.vue'
import { ref } from 'vue'

const items = [
  { key: 'home', title: 'Home' },
  { key: 'profile', title: 'Profile' },
  { key: 'contact', title: 'Contact' },
]
const active1 = ref('home')

const itemsLong = Array.from({ length: 12 }).map((_, i) => ({ key: `k${i+1}`, title: `Menu ${i+1}` }))
const itemsMixed = [
  { key: 'a', title: 'Home' },
  { key: 'b', title: 'Very Very Long Menu Name' },
  { key: 'c', title: 'Profile' },
  { key: 'd', title: 'Messages' },
  { key: 'e', title: 'Settings' },
  { key: 'f', title: 'Another Long Long Title To Test' },
  { key: 'g', title: 'Contact' },
]

const apiCols = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiColsEvents = [
  { key: 'name', header: 'Event', width: 180, sticky: true },
  { key: 'payload', header: 'Payload', width: 220 },
  { key: 'desc', header: 'Description' },
]
const apiColsSlots = [
  { key: 'name', header: 'Slot', width: 180, sticky: true },
  { key: 'props', header: 'Props', width: 240 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'items', type: 'Array<{ key: Key; title: string; disabled?: boolean }>', default: '[]', desc: '탭 항목 목록' },
  { name: 'modelValue', type: 'Key | null', default: '첫 항목', desc: '활성 탭 키(v-model)' },
  { name: 'variant', type: "'underline'|'pills'", default: 'underline', desc: '탭 스타일' },
  { name: 'align', type: "'start'|'center'|'end'", default: 'start', desc: '탭 버튼 정렬' },
  { name: 'justified', type: 'boolean', default: 'false', desc: '버튼 가로폭 균등 분배' },
  { name: 'placement', type: "'top'|'bottom'", default: 'top', desc: '탭 내비게이션 위치' },
  { name: 'scrollable', type: 'boolean', default: 'false', desc: '탭 버튼이 넘치면 가로 스크롤 허용' },
  { name: 'centerActive', type: 'boolean', default: 'true', desc: '활성 탭을 가로 스크롤 영역 가운데로 이동' },
  { name: 'navButtons', type: 'boolean', default: 'true', desc: '스크롤 가능한 탭에서 좌/우 이동 버튼 표시' },
]
const apiRowsEvents = [
  { name: 'update:modelValue', payload: 'Key', desc: '활성 탭 변경(v-model)' },
  { name: 'change', payload: 'Key', desc: '사용자 액션으로 탭 변경' },
]
const apiRowsSlots = [
  { name: 'panel-KEY', props: '{ item }', desc: 'KEY 탭의 패널 콘텐츠' },
  { name: 'title-KEY', props: '{ item }', desc: 'KEY 탭의 제목 콘텐츠 커스텀' },
]
</script>
