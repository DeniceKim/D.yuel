<route lang="yaml">
meta:
  title: 가이드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>Button</h2>
  

  <h3>1) 타입 + Variant</h3>
  <div v-for="v in variants as Array<'solid'|'ghost'|'dashed'|'text'>" :key="v" style="margin-bottom:8px">
    <div style="font-size:12px; color:var(--color-dim,#666); margin-bottom:4px">variant: {{ v }}</div>
    <div style="display:flex; gap:8px; flex-wrap:wrap">
      <BaseButton v-for="t in types as Array<'default'|'primary'|'info'|'success'|'warning'|'error'>" :key="t+v" :type="t" :variant="v">{{ t }}</BaseButton>
    </div>
  </div>

  <hr />

  <h3>2) 크기/Block/Round/Circle/Loading</h3>
  <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center">
    <BaseButton size="sm">Small</BaseButton>
    <BaseButton size="md">Medium</BaseButton>
    <BaseButton size="lg">Large</BaseButton>
    <BaseButton round>Round</BaseButton>
    <BaseButton circle aria-label="circle"><template #prefix>★</template></BaseButton>
    <BaseButton :loading="true">Loading</BaseButton>
  </div>
  <div style="margin-top:8px">
    <BaseButton block>Block Button</BaseButton>
  </div>

  <hr />

  <h3>3) Prefix/Suffix/Link</h3>
  <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center">
    <BaseButton><template #prefix>★</template>Prefixed</BaseButton>
    <BaseButton>Suffixed<template #suffix>→</template></BaseButton>
    <BaseButton href="https://example.com" target="_blank" rel="noopener">Link</BaseButton>
  </div>

  <hr />

  <h3>4) Button Group</h3>
  <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-start">
    <div>
      <div style="font-size:12px; color:var(--color-dim,#666); margin-bottom:4px">기본 그룹</div>
      <BaseButtonGroup>
        <BaseButton type="primary">Left</BaseButton>
        <BaseButton type="primary">Middle</BaseButton>
        <BaseButton type="primary">Right</BaseButton>
      </BaseButtonGroup>
    </div>
    <div>
      <div style="font-size:12px; color:var(--color-dim,#666); margin-bottom:4px">혼합 타입</div>
      <BaseButtonGroup>
        <BaseButton type="default" variant="ghost">Default</BaseButton>
        <BaseButton type="success">Success</BaseButton>
        <BaseButton type="warning">Warn</BaseButton>
        <BaseButton type="error">Error</BaseButton>
      </BaseButtonGroup>
    </div>
    <div>
      <div style="font-size:12px; color:var(--color-dim,#666); margin-bottom:4px">세로 그룹</div>
      <BaseButtonGroup vertical>
        <BaseButton>Top</BaseButton>
        <BaseButton>Middle</BaseButton>
        <BaseButton>Bottom</BaseButton>
      </BaseButtonGroup>
    </div>
    <div style="min-width:260px">
      <div style="font-size:12px; color:var(--color-dim,#666); margin-bottom:4px">가로 꽉 채우기</div>
      <BaseButtonGroup justified>
        <BaseButton>Left</BaseButton>
        <BaseButton>Center</BaseButton>
        <BaseButton>Right</BaseButton>
      </BaseButtonGroup>
    </div>
  </div>

  <hr />

  <h3>API Reference</h3>
  <h4>BaseButton</h4>
  <BaseTable :columns="apiCols" :rows="apiRowsProps" sticky-first-column />
  <h4 style="margin-top:16px">BaseButtonGroup</h4>
  <BaseTable :columns="apiCols" :rows="apiRowsGroup" sticky-first-column />

</template>
<script setup lang="ts">
import BaseButton from '@/components/BaseButton.vue'
import BaseButtonGroup from '@/components/BaseButtonGroup.vue'
import BaseTable from '@/components/BaseTable.vue'

const types = ['default','primary','secondary','info','success','warning','error']
const variants = ['solid','ghost','dashed','text']

const apiCols = [
  { key: 'name', header: 'Prop', width: 180, sticky: true },
  { key: 'type', header: 'Type', width: 220 },
  { key: 'default', header: 'Default', width: 160 },
  { key: 'desc', header: 'Description' },
]
const apiRowsProps = [
  { name: 'type', type: "'default'|'primary'|'info'|'success'|'warning'|'error'", default: 'default', desc: '버튼 색상 타입' },
  { name: 'variant', type: "'solid'|'ghost'|'dashed'|'text'", default: 'solid', desc: '버튼 외형' },
  { name: 'size', type: "'sm'|'md'|'lg'", default: 'md', desc: '크기' },
  { name: 'block', type: 'boolean', default: 'false', desc: '가로 전체 넓이' },
  { name: 'round', type: 'boolean', default: 'false', desc: '라운드(필)' },
  { name: 'circle', type: 'boolean', default: 'false', desc: '정원(아이콘 버튼)' },
  { name: 'strong', type: 'boolean', default: 'false', desc: '강조(폰트 굵기)' },
  { name: 'loading', type: 'boolean', default: 'false', desc: '로딩 스피너 표시 및 비활성' },
  { name: 'nativeType', type: "'button'|'submit'|'reset'", default: 'button', desc: '네이티브 타입' },
  { name: 'disabled', type: 'boolean', default: 'false', desc: '비활성' },
  { name: 'href', type: 'string', default: '-', desc: '링크 버튼으로 렌더' },
  { name: 'target', type: 'string', default: '-', desc: '링크 target' },
  { name: 'rel', type: 'string', default: '-', desc: '링크 rel' },
]
const apiRowsGroup = [
  { name: 'vertical', type: 'boolean', default: 'false', desc: '세로 방향 그룹' },
  { name: 'justified', type: 'boolean', default: 'false', desc: '가로 공간을 균등 분배해 꽉 채움' },
  { name: 'ariaLabel', type: 'string', default: '-', desc: '접근성용 그룹 라벨' },
]
</script>
