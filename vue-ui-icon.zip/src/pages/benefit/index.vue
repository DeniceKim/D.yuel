<route lang="yaml">
meta:
  title: 혜택
  layout: BenefitsLayout
  layoutId: benefits       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: true        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <section class="top__noti gap__x">
    <h2>혜택 Main</h2>
    <p>혜택 메인 페이지입니다.</p>
  </section>
</template>
