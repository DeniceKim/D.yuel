<route lang="yaml">
meta:
  title: 대시보드
  layout: GuideLayout
  layoutId: guide       # data-layout 값
  navbar: true         # 헤더 (true:사용 | false:미사용)
  tabbar: false        # 탭바 (true:사용 | false:미사용)
  drawer: true         # 드로어 (true:사용 | false:미사용)
</route>

<template>
  <h2>대시보드</h2>
  <div style="display: grid; gap: 12px; grid-template-columns: repeat(2, minmax(0, 1fr))">
    <BaseCard><template #header> 입출금 </template>이번 달 지출 ￦1,230,000</BaseCard>
    <BaseCard><template #header> 예적금 </template>총 ￦12,345,678</BaseCard>
    <BaseCard><template #header> 카드 청구 </template>D-5 · ￦456,700</BaseCard>
    <BaseCard><template #header> 포인트 </template>23,450p</BaseCard>
  </div>
</template>
<script setup lang="ts">
import BaseCard from '@/components/BaseCard.vue'
</script>
